/*******************************************************************************
* File Name: Band_BCD.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Band_BCD_ALIASES_H) /* Pins Band_BCD_ALIASES_H */
#define CY_PINS_Band_BCD_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define Band_BCD_0			(Band_BCD__0__PC)
#define Band_BCD_0_INTR	((uint16)((uint16)0x0001u << Band_BCD__0__SHIFT))

#define Band_BCD_1			(Band_BCD__1__PC)
#define Band_BCD_1_INTR	((uint16)((uint16)0x0001u << Band_BCD__1__SHIFT))

#define Band_BCD_2			(Band_BCD__2__PC)
#define Band_BCD_2_INTR	((uint16)((uint16)0x0001u << Band_BCD__2__SHIFT))

#define Band_BCD_3			(Band_BCD__3__PC)
#define Band_BCD_3_INTR	((uint16)((uint16)0x0001u << Band_BCD__3__SHIFT))

#define Band_BCD_4			(Band_BCD__4__PC)
#define Band_BCD_4_INTR	((uint16)((uint16)0x0001u << Band_BCD__4__SHIFT))

#define Band_BCD_5			(Band_BCD__5__PC)
#define Band_BCD_5_INTR	((uint16)((uint16)0x0001u << Band_BCD__5__SHIFT))

#define Band_BCD_INTR_ALL	 ((uint16)(Band_BCD_0_INTR| Band_BCD_1_INTR| Band_BCD_2_INTR| Band_BCD_3_INTR| Band_BCD_4_INTR| Band_BCD_5_INTR))

#endif /* End Pins Band_BCD_ALIASES_H */


/* [] END OF FILE */
