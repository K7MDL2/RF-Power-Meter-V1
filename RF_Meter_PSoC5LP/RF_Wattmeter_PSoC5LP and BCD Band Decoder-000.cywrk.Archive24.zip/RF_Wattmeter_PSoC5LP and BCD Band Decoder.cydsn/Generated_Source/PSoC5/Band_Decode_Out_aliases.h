/*******************************************************************************
* File Name: Band_Decode_Out.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Band_Decode_Out_ALIASES_H) /* Pins Band_Decode_Out_ALIASES_H */
#define CY_PINS_Band_Decode_Out_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define Band_Decode_Out_0			(Band_Decode_Out__0__PC)
#define Band_Decode_Out_0_INTR	((uint16)((uint16)0x0001u << Band_Decode_Out__0__SHIFT))

#define Band_Decode_Out_1			(Band_Decode_Out__1__PC)
#define Band_Decode_Out_1_INTR	((uint16)((uint16)0x0001u << Band_Decode_Out__1__SHIFT))

#define Band_Decode_Out_2			(Band_Decode_Out__2__PC)
#define Band_Decode_Out_2_INTR	((uint16)((uint16)0x0001u << Band_Decode_Out__2__SHIFT))

#define Band_Decode_Out_3			(Band_Decode_Out__3__PC)
#define Band_Decode_Out_3_INTR	((uint16)((uint16)0x0001u << Band_Decode_Out__3__SHIFT))

#define Band_Decode_Out_4			(Band_Decode_Out__4__PC)
#define Band_Decode_Out_4_INTR	((uint16)((uint16)0x0001u << Band_Decode_Out__4__SHIFT))

#define Band_Decode_Out_5			(Band_Decode_Out__5__PC)
#define Band_Decode_Out_5_INTR	((uint16)((uint16)0x0001u << Band_Decode_Out__5__SHIFT))

#define Band_Decode_Out_INTR_ALL	 ((uint16)(Band_Decode_Out_0_INTR| Band_Decode_Out_1_INTR| Band_Decode_Out_2_INTR| Band_Decode_Out_3_INTR| Band_Decode_Out_4_INTR| Band_Decode_Out_5_INTR))

#endif /* End Pins Band_Decode_Out_ALIASES_H */


/* [] END OF FILE */
