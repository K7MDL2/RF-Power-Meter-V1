/*******************************************************************************
* File Name: Aux1Out.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Aux1Out_H) /* Pins Aux1Out_H */
#define CY_PINS_Aux1Out_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Aux1Out_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Aux1Out__PORT == 15 && ((Aux1Out__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Aux1Out_Write(uint8 value);
void    Aux1Out_SetDriveMode(uint8 mode);
uint8   Aux1Out_ReadDataReg(void);
uint8   Aux1Out_Read(void);
void    Aux1Out_SetInterruptMode(uint16 position, uint16 mode);
uint8   Aux1Out_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Aux1Out_SetDriveMode() function.
     *  @{
     */
        #define Aux1Out_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Aux1Out_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Aux1Out_DM_RES_UP          PIN_DM_RES_UP
        #define Aux1Out_DM_RES_DWN         PIN_DM_RES_DWN
        #define Aux1Out_DM_OD_LO           PIN_DM_OD_LO
        #define Aux1Out_DM_OD_HI           PIN_DM_OD_HI
        #define Aux1Out_DM_STRONG          PIN_DM_STRONG
        #define Aux1Out_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Aux1Out_MASK               Aux1Out__MASK
#define Aux1Out_SHIFT              Aux1Out__SHIFT
#define Aux1Out_WIDTH              4u

/* Interrupt constants */
#if defined(Aux1Out__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Aux1Out_SetInterruptMode() function.
     *  @{
     */
        #define Aux1Out_INTR_NONE      (uint16)(0x0000u)
        #define Aux1Out_INTR_RISING    (uint16)(0x0001u)
        #define Aux1Out_INTR_FALLING   (uint16)(0x0002u)
        #define Aux1Out_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Aux1Out_INTR_MASK      (0x01u) 
#endif /* (Aux1Out__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Aux1Out_PS                     (* (reg8 *) Aux1Out__PS)
/* Data Register */
#define Aux1Out_DR                     (* (reg8 *) Aux1Out__DR)
/* Port Number */
#define Aux1Out_PRT_NUM                (* (reg8 *) Aux1Out__PRT) 
/* Connect to Analog Globals */                                                  
#define Aux1Out_AG                     (* (reg8 *) Aux1Out__AG)                       
/* Analog MUX bux enable */
#define Aux1Out_AMUX                   (* (reg8 *) Aux1Out__AMUX) 
/* Bidirectional Enable */                                                        
#define Aux1Out_BIE                    (* (reg8 *) Aux1Out__BIE)
/* Bit-mask for Aliased Register Access */
#define Aux1Out_BIT_MASK               (* (reg8 *) Aux1Out__BIT_MASK)
/* Bypass Enable */
#define Aux1Out_BYP                    (* (reg8 *) Aux1Out__BYP)
/* Port wide control signals */                                                   
#define Aux1Out_CTL                    (* (reg8 *) Aux1Out__CTL)
/* Drive Modes */
#define Aux1Out_DM0                    (* (reg8 *) Aux1Out__DM0) 
#define Aux1Out_DM1                    (* (reg8 *) Aux1Out__DM1)
#define Aux1Out_DM2                    (* (reg8 *) Aux1Out__DM2) 
/* Input Buffer Disable Override */
#define Aux1Out_INP_DIS                (* (reg8 *) Aux1Out__INP_DIS)
/* LCD Common or Segment Drive */
#define Aux1Out_LCD_COM_SEG            (* (reg8 *) Aux1Out__LCD_COM_SEG)
/* Enable Segment LCD */
#define Aux1Out_LCD_EN                 (* (reg8 *) Aux1Out__LCD_EN)
/* Slew Rate Control */
#define Aux1Out_SLW                    (* (reg8 *) Aux1Out__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Aux1Out_PRTDSI__CAPS_SEL       (* (reg8 *) Aux1Out__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Aux1Out_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Aux1Out__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Aux1Out_PRTDSI__OE_SEL0        (* (reg8 *) Aux1Out__PRTDSI__OE_SEL0) 
#define Aux1Out_PRTDSI__OE_SEL1        (* (reg8 *) Aux1Out__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Aux1Out_PRTDSI__OUT_SEL0       (* (reg8 *) Aux1Out__PRTDSI__OUT_SEL0) 
#define Aux1Out_PRTDSI__OUT_SEL1       (* (reg8 *) Aux1Out__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Aux1Out_PRTDSI__SYNC_OUT       (* (reg8 *) Aux1Out__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Aux1Out__SIO_CFG)
    #define Aux1Out_SIO_HYST_EN        (* (reg8 *) Aux1Out__SIO_HYST_EN)
    #define Aux1Out_SIO_REG_HIFREQ     (* (reg8 *) Aux1Out__SIO_REG_HIFREQ)
    #define Aux1Out_SIO_CFG            (* (reg8 *) Aux1Out__SIO_CFG)
    #define Aux1Out_SIO_DIFF           (* (reg8 *) Aux1Out__SIO_DIFF)
#endif /* (Aux1Out__SIO_CFG) */

/* Interrupt Registers */
#if defined(Aux1Out__INTSTAT)
    #define Aux1Out_INTSTAT            (* (reg8 *) Aux1Out__INTSTAT)
    #define Aux1Out_SNAP               (* (reg8 *) Aux1Out__SNAP)
    
	#define Aux1Out_0_INTTYPE_REG 		(* (reg8 *) Aux1Out__0__INTTYPE)
	#define Aux1Out_1_INTTYPE_REG 		(* (reg8 *) Aux1Out__1__INTTYPE)
	#define Aux1Out_2_INTTYPE_REG 		(* (reg8 *) Aux1Out__2__INTTYPE)
	#define Aux1Out_3_INTTYPE_REG 		(* (reg8 *) Aux1Out__3__INTTYPE)
#endif /* (Aux1Out__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Aux1Out_H */


/* [] END OF FILE */
