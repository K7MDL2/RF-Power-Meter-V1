/*******************************************************************************
* File Name: Band_BCD.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Band_BCD_H) /* Pins Band_BCD_H */
#define CY_PINS_Band_BCD_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Band_BCD_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Band_BCD__PORT == 15 && ((Band_BCD__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Band_BCD_Write(uint8 value);
void    Band_BCD_SetDriveMode(uint8 mode);
uint8   Band_BCD_ReadDataReg(void);
uint8   Band_BCD_Read(void);
void    Band_BCD_SetInterruptMode(uint16 position, uint16 mode);
uint8   Band_BCD_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Band_BCD_SetDriveMode() function.
     *  @{
     */
        #define Band_BCD_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Band_BCD_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Band_BCD_DM_RES_UP          PIN_DM_RES_UP
        #define Band_BCD_DM_RES_DWN         PIN_DM_RES_DWN
        #define Band_BCD_DM_OD_LO           PIN_DM_OD_LO
        #define Band_BCD_DM_OD_HI           PIN_DM_OD_HI
        #define Band_BCD_DM_STRONG          PIN_DM_STRONG
        #define Band_BCD_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Band_BCD_MASK               Band_BCD__MASK
#define Band_BCD_SHIFT              Band_BCD__SHIFT
#define Band_BCD_WIDTH              6u

/* Interrupt constants */
#if defined(Band_BCD__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Band_BCD_SetInterruptMode() function.
     *  @{
     */
        #define Band_BCD_INTR_NONE      (uint16)(0x0000u)
        #define Band_BCD_INTR_RISING    (uint16)(0x0001u)
        #define Band_BCD_INTR_FALLING   (uint16)(0x0002u)
        #define Band_BCD_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Band_BCD_INTR_MASK      (0x01u) 
#endif /* (Band_BCD__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Band_BCD_PS                     (* (reg8 *) Band_BCD__PS)
/* Data Register */
#define Band_BCD_DR                     (* (reg8 *) Band_BCD__DR)
/* Port Number */
#define Band_BCD_PRT_NUM                (* (reg8 *) Band_BCD__PRT) 
/* Connect to Analog Globals */                                                  
#define Band_BCD_AG                     (* (reg8 *) Band_BCD__AG)                       
/* Analog MUX bux enable */
#define Band_BCD_AMUX                   (* (reg8 *) Band_BCD__AMUX) 
/* Bidirectional Enable */                                                        
#define Band_BCD_BIE                    (* (reg8 *) Band_BCD__BIE)
/* Bit-mask for Aliased Register Access */
#define Band_BCD_BIT_MASK               (* (reg8 *) Band_BCD__BIT_MASK)
/* Bypass Enable */
#define Band_BCD_BYP                    (* (reg8 *) Band_BCD__BYP)
/* Port wide control signals */                                                   
#define Band_BCD_CTL                    (* (reg8 *) Band_BCD__CTL)
/* Drive Modes */
#define Band_BCD_DM0                    (* (reg8 *) Band_BCD__DM0) 
#define Band_BCD_DM1                    (* (reg8 *) Band_BCD__DM1)
#define Band_BCD_DM2                    (* (reg8 *) Band_BCD__DM2) 
/* Input Buffer Disable Override */
#define Band_BCD_INP_DIS                (* (reg8 *) Band_BCD__INP_DIS)
/* LCD Common or Segment Drive */
#define Band_BCD_LCD_COM_SEG            (* (reg8 *) Band_BCD__LCD_COM_SEG)
/* Enable Segment LCD */
#define Band_BCD_LCD_EN                 (* (reg8 *) Band_BCD__LCD_EN)
/* Slew Rate Control */
#define Band_BCD_SLW                    (* (reg8 *) Band_BCD__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Band_BCD_PRTDSI__CAPS_SEL       (* (reg8 *) Band_BCD__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Band_BCD_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Band_BCD__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Band_BCD_PRTDSI__OE_SEL0        (* (reg8 *) Band_BCD__PRTDSI__OE_SEL0) 
#define Band_BCD_PRTDSI__OE_SEL1        (* (reg8 *) Band_BCD__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Band_BCD_PRTDSI__OUT_SEL0       (* (reg8 *) Band_BCD__PRTDSI__OUT_SEL0) 
#define Band_BCD_PRTDSI__OUT_SEL1       (* (reg8 *) Band_BCD__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Band_BCD_PRTDSI__SYNC_OUT       (* (reg8 *) Band_BCD__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Band_BCD__SIO_CFG)
    #define Band_BCD_SIO_HYST_EN        (* (reg8 *) Band_BCD__SIO_HYST_EN)
    #define Band_BCD_SIO_REG_HIFREQ     (* (reg8 *) Band_BCD__SIO_REG_HIFREQ)
    #define Band_BCD_SIO_CFG            (* (reg8 *) Band_BCD__SIO_CFG)
    #define Band_BCD_SIO_DIFF           (* (reg8 *) Band_BCD__SIO_DIFF)
#endif /* (Band_BCD__SIO_CFG) */

/* Interrupt Registers */
#if defined(Band_BCD__INTSTAT)
    #define Band_BCD_INTSTAT            (* (reg8 *) Band_BCD__INTSTAT)
    #define Band_BCD_SNAP               (* (reg8 *) Band_BCD__SNAP)
    
	#define Band_BCD_0_INTTYPE_REG 		(* (reg8 *) Band_BCD__0__INTTYPE)
	#define Band_BCD_1_INTTYPE_REG 		(* (reg8 *) Band_BCD__1__INTTYPE)
	#define Band_BCD_2_INTTYPE_REG 		(* (reg8 *) Band_BCD__2__INTTYPE)
	#define Band_BCD_3_INTTYPE_REG 		(* (reg8 *) Band_BCD__3__INTTYPE)
	#define Band_BCD_4_INTTYPE_REG 		(* (reg8 *) Band_BCD__4__INTTYPE)
	#define Band_BCD_5_INTTYPE_REG 		(* (reg8 *) Band_BCD__5__INTTYPE)
#endif /* (Band_BCD__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Band_BCD_H */


/* [] END OF FILE */
