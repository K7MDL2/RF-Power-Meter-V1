/* ========================================
 *
 * Copyright K7MDL, 2020
 * All Rights Reserved
 * Distribution allowed per MIT License
 *
 * ========================================
*/
/*  TODO:
    Vendor ID – This is a 16-bit number used to uniquely identify USB devices belonging to a 
    specific vendor/manufacturer to a USB host. Vendor IDs are assigned by the USB Implementers 
    Forum (USB-IF). The following link in the USB-IF webpage explains the method to obtain a
    vendor ID for your company:      
    http://www.usb.org/developers/vendor/ 
    Note Vendor ID 0x4B4 is a Cypress-only VID and may be used for development purposes only. 
    Products cannot be released using this VID; you must obtain your own VID. 
*/
    
/*
 *
 * RF Wattmeter_PSoc5LP by K7MDL 6/9/2020   - Remote (Headless) Edition for PSoc5LP 
 * 
 * 6/9/2020 -   Major work on setting up main and 2 config pages for the Nextion
 *              Created workaround for buffer overflow on a pointer to a char string passed between functions in separate files.  
 *              Pointer was at correct start but debugger only showed 1 byte in string. Found in 2 places, NexText and Serial cmd send sections
 *              In use the strcpy never saw a NULL byte and copyed the string endlessly until there was no more memory left.
 *              Added more EEPROM stored items for max current, temp, HV DC and 14VDC since larger displays like the desktop and Nextion can 
 *              configure and display them, alerting with color changes.
 *              For the Nextion created slider based coupler cal and max setpoints controls and event handling
 *              The Nextion handles most all the UI work for fast updates, minimal CPU interaction required.
 *              Do need to be careful about changing a band's coupling cal numbers while the band could change under it.
 *              It would result in saving the wrong set of numbers to the new current coupling cal table.
                3rd page was added to configure alarm setpoints for HV DC, 14 VDC, Temp and Current, also can manually set band and Meter ID.  
                Use the Save Config buttons on each config page to commit change to EEPROM.  
                Changes will stick if a band change occurs, otherwise need to manually save when done (design choice).
                Expanded NUM_SETS to 11 bands to add HF, previously combined with 50MHz.  Some radios band decoders will not differentiate between
                50MHz and HF using 4 BCD lines. If a 5th is used (like the K3 DIGOUT1).  
                Remapped the command table to run from 240 to 250.  
                Moved the dump cal table command to 252. Changed the button logic in the Python app to match.
                Added #ifdef around all Nextion and all SSD1306O_LED display code.
                This allows for cleanly adding new display types and sizes or no display and not carry the extra code baggage.
                Some displays may reuse parts like different sizes Nextion or sizes of OLED with a slight controller change.
                Updated EEPROM to save the setpoints. meterID and band info with Save Config button and remote reset to defaults.
                Can edit one band at a time by changing bands manually on 3rd page or remotely.
                Added 100 second hardware interrupt driven timer to control display update rates and serial output rates.
                
 * 6/6/2020 -   0.96" OLED up and running.  Nextion 2.4" LCD graphihcs screen up and running. 
 *              Reassigned IO pins to match the available poins on a KitProg board
 *              Made a Bootloader for the KitProg board and using it on a proto board to driv the OLED ont eh back of a front panel of a RF amplifier
 *              Both use the identical code except the Kitprog has the bootloader component on it.  No code changes required.
 *
 * 6/1/2020 -   Added timeout to USB write to remove hang when USB is down.  
 *              Now operates when the USB is disconnected which is useful when a display is attached for local data display
 *              Set up OLED formatting function for Fwd Power, Reflected power, and SWR and placeholders for temp and current.
 *
 * 5/31/2020 -  Added SSD1306 display controller code to support OLED display test on I2C bus.   Fixed EEPRONM read problem.  
 *              Changing a cal value now updates for use immediately.
 *
 * 5/27/2020 -  Headless port from Arduino Nano to PSoC5LP CY8CKIT-059 dev module now fully working.
                EEPROM work much differently and using USB serial port.
 *
 * 5/10/2020 -  Headless Nano CPU version. 
 *              Stripped out physical button tests.  
 *              Removed rest of M5/ESP32 dependencies,
 *              Using standard Arduino functions (vs original M5Stack/esp32).  
 *              Added CPU reset and default EEPROM commands. 
 *              Trying out read_vcc() to measure VCC folowing each AD read to increase accuracy since
 *                  the Default is bus power (from USB or external).  Internal Vref is too low at 1.1V to use
 *                  Without adding an external voltage divider.
 *
 * 5/8/2020 - Added Remote commands to support dumping the cal table and writing to individual coupling
 *    factor cal values and saving to EEPROM.  Switch from a one byte command to a string with similar structure
 *    as the power level out.  Changed sequence number to msg_type fo future expansion and to help validate the 
 *    incoming message better from random data/noise/CPU status messages.
 *    There is still some screen drawing mostly in the cal area yet to be removed.  Considering leaving the digital
 *    values screen writing in for adaption to a 2x16/4x20 LCD or small graphics OLED embedded in an RFampifier as
 *    the main meter with SWR shutdowna nd other feature (including remote monitoring).
 *    One concern for getting Wi-Fi to work is the possibility the ESP32 in the M5stack I am using may take over ADC2 pins 
 *    which would be a problem.  Also the internal noise coudl be improved using an external I2C connected A/D.
 *
 Has user edited Calibration sets. Have 10 "bands" for frequency correction used with values that can be edited via the UI ---

 In this code example I use a RLC .05-1000MHz coupler and created 10 cal bands toi cover 50M to 10G.
 A value for each dual directional coupler port combines the coupler facxtor, added attenuators, and any cal correction fudge factor.
 The values are edited via the device UI and stored in EEPROM.
*/
#include <project.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include "RF_Wattmeter.h"

//#define RESET_EEPROM

void setup(void) {

#ifdef SSD1306_OLED
    I2COLED_Start(); 
    display_init(DISPLAY_ADDRESS); // This line will initialize your display using the address you specified before.
    //gfx_setRotation(1);
    display_clear();    
    display_update();
#endif
    
    UART1_Start();   // intended for Nextion but leaving defined for other uses
    
    CyGlobalIntEnable; /* Enable global interrupts. */    
   
    /* Enable the Interrupt component connected to Timer interrupt */
    Timer_X00ms_ISR_StartEx(Timer_X00ms_InterruptHandler);
    Timer_X00ms_Start();
    
    /* Start USBFS operation with 5-V operation. */
    Serial_USB_Start(Serial_USB_DEVICE, Serial_USB_5V_OPERATION);  
    write_Cal_Table_from_Default();  // Copy default values into memory in case EEPROM not yet initialized
    ADC_RF_Power_Start();
    ADC_RF_Power_AMux_Start();
    ADC_RF_Power_StartConvert();

    EEPROM_Start(); /*  Start the EEPROM storage System             */
    CyDelay(7);     /* wait at least 5ms to power up EEPROM       */
   
    /*   initialize EEPROM storage if not done before - will overwrite default memory table values from EEPROM if EEPROM was written to before */    
    
    #ifdef RESET_EEPROM
    EE_PGM_Failed = EEPROM_Init(EE_SAVE_YES);
    #else 
    EE_PGM_Failed = EEPROM_Init(0);
    #endif
    Cal_Table();   // Load current Band values from Table

    // initialize all the readings to 0:  Used to smooth AD values
        for (int thisReading = 0; thisReading < NUMREADINGS; thisReading++) {
        readings_Fwd[thisReading] = 0;
        readings_Ref[thisReading] = 0;
    }
        
    // ensure the band index is in proper range in case of bad input or memory operation
    if (CouplerSetNum < 0)   // constrin newBand
        CouplerSetNum = 0;   // something wrong if you end up here
    if (CouplerSetNum >= NUM_SETS)
        CouplerSetNum = NUM_SETS-1; // something wrong if you end up here
    
#ifdef NEXTION
    // Set up objects to monitor touch controls from Nextion Display
    CreateNexObject(savecfg_button, page1_ID, savecfg_button_ID, "savecfg_button");
    CreateNexObject(fwd_cal, page1_ID, fwd_cal_ID, "fwd_cal");
    CreateNexObject(ref_cal, page1_ID, ref_cal_ID, "ref_cal");
    CreateNexObject(fwd_cal_num, page1_ID, fwd_cal_num_ID, "fwd_cal_num");  // slider
    CreateNexObject(ref_cal_num, page1_ID, ref_cal_num_ID, "ref_cal_num");  // slider
    CreateNexObject(f_att_minus, page1_ID, f_att_minus_ID, "f_att_minus");
    CreateNexObject(f_att_plus, page1_ID, f_att_plus_ID, "f_att_plus");
    CreateNexObject(r_att_minus, page1_ID, r_att_minus_ID, "r_att_minus");
    CreateNexObject(r_att_plus, page1_ID, r_att_plus_ID, "r_att_plus");
    CreateNexObject(toConfig, page0_ID, toConfig_ID, "toConfig");
    CreateNexObject(toSet1, page1_ID, toSet1_ID, "toSet1");
    CreateNexObject(toPwrGraph, page2_ID, toPwrGraph_ID, "toPwrGraph");
    CreateNexObject(toMain, page3_ID, toMain_ID, "toMain");
    CreateNexObject(Main, page0_ID, Main_ID, "Main");
    CreateNexObject(Coupler, page1_ID, Coupler_ID, "Coupler");
    CreateNexObject(Set1, page2_ID, Set1_ID, "Set1");
    CreateNexObject(PwrGraph, page3_ID,PwrGraph_ID, "PwrGraph");
    CreateNexObject(FactoryRst1, page1_ID, FactoryRst1_ID, "FactoryRst1");
    CreateNexObject(FactoryRst2, page1_ID, FactoryRst2_ID, "FactoryRst2");
    CreateNexObject(Set1_Bandvar,page2_ID,Set1_Bandvar_ID,"Set1.Bandvar");
    CreateNexObject(hv_adj,page2_ID,hv_adj_ID,"hv_adj");  // slider
    CreateNexObject(v14_adj,page2_ID,v14_adj_ID,"v14_adj"); // slider
    CreateNexObject(curr_adj,page2_ID,curr_adj_ID,"curr_adj"); // slider
    CreateNexObject(temp_adj,page2_ID,temp_adj_ID,"temp_adj"); // slider
    CreateNexObject(hv_max,page2_ID,hv_max_ID,"hv_max");  
    CreateNexObject(v14_max,page2_ID,v14_max_ID,"v14_max"); 
    CreateNexObject(curr_max,page2_ID,curr_max_ID,"curr_max"); 
    CreateNexObject(temp_max,page2_ID,temp_max_ID,"temp_max");
    CreateNexObject(meterID,page2_ID,meterID_ID,"meterID"); 
    CreateNexObject(meterID_adj,page2_ID,meterID_adj_ID,"meterID_adj"); // slider
    CreateNexObject(band_set,page2_ID,band_set_ID,"band_set"); 
    CreateNexObject(band_set_adj,page2_ID,band_set_adj_ID,"band_set_adj"); // slider
    CreateNexObject(band_cal,page1_ID,band_cal_ID,"band_cal"); 
    CreateNexObject(fPwrGraph,page3_ID,fPwrGraph_ID,"fPwrGraph"); 
    CreateNexObject(fPwr_scale,page3_ID,fPwr_scale_ID,"fPwr_scale"); 
    CreateNexObject(fscale,page3_ID,fscale_ID,"fscale"); 
    CreateNexObject(rscale,page3_ID,rscale_ID,"rscale"); 
    CreateNexObject(fPwrNum,page3_ID,fPwrNum_ID,"fPwrNum"); 
    CreateNexObject(rPwrNum,page3_ID,rPwrNum_ID,"rPwrNum"); 
    CreateNexObject(swrNum,page3_ID,swrNum_ID,"swrNum");
    CreateNexObject(Graph_Timer,page3_ID,Graph_Timer_ID,"Graph_Timer");
    
    // Set up Callback mappings
    NexTouch_attachPop(&savecfg_button, savecfg_button_pop_Callback, 0);
    NexTouch_attachPush(&savecfg_button, savecfg_button_push_Callback, 0);
    NexTouch_attachPop(&fwd_cal, fwd_cal_pop_Callback, 0);
    NexTouch_attachPop(&ref_cal, ref_cal_pop_Callback, 0);
    NexTouch_attachPop(&toMain, toMain_push_Callback, 0);
    NexTouch_attachPop(&toConfig, toConfig_pop_Callback, 0);
    NexTouch_attachPop(&toSet1, Set1_Callback, 0); 
    NexTouch_attachPop(&f_att_minus, f_att_minus_pop_Callback, 0);
    NexTouch_attachPop(&f_att_plus, f_att_plus_pop_Callback, 0);
    NexTouch_attachPop(&r_att_minus, r_att_minus_pop_Callback, 0);
    NexTouch_attachPop(&r_att_plus, r_att_plus_pop_Callback, 0);
    NexTouch_attachPop(&FactoryRst1, FactoryRst1_pop_Callback, 0);
    NexTouch_attachPop(&FactoryRst2, FactoryRst2_pop_Callback, 0);
    NexTouch_attachPop(&meterID_adj, meterID_adj_pop_Callback, 0);
    NexTouch_attachPop(&band_set_adj, band_set_adj_pop_Callback, 0);
    NexTouch_attachPop(&hv_adj, hv_adj_pop_Callback, 0);
    NexTouch_attachPop(&v14_adj, v14_adj_pop_Callback, 0);
    NexTouch_attachPop(&curr_adj, curr_adj_pop_Callback, 0);
    NexTouch_attachPop(&temp_adj, temp_adj_pop_Callback, 0);
    
    // Ensure we are on Page 0 in cas we start and the diaplsy is already running such as during dev and test
    nexInit();
    NexPage_show(&Main);
    strcpy(cmd,Band_Cal_Table[CouplerSetNum].BandName);
    NexText_setText(&Set1_Bandvar);    // Update Nextion display for new values
    NexSlider_setMaxval(&band_set_adj, (uint32_t) NUM_SETS);  // Ensure the control know the same num bands the host does.
    Set1_Callback(0);  // initialize our setpoints and meter id so it does not get read back as 0 values later.
    UART1_ClearRxBuffer();
    NexPage_show(&Main);
    NexNumber_setValue(&Graph_Timer, 500);   // 300msec for graph update rate.  300 set in display, can override here.
    Nextion_Switch_Write(0);   // Switches the Nextion dis;lay serial port between teh CPU and the USB converter (For diplay uploads via USB)
                                // 0 = CPU, 1 = USB converter
#endif // end Nextion setup section 
    
    // Flash some lights to show we are a go
    LED_Write(1);
    LED_1_Write(1);
    CyDelay(1000);
    LED_Write(0);
    LED_1_Write(0);
}

int main(void)
{   
    setup();
    
    while (1) {
        // Listen for remote computer commands                
        serial_usb_read();  // festch latest data in buffer                                      
        if (rx_count!=0)
            get_remote_cmd();       // scan buffer for command strings
            
        if (Button_A == YES) {   // Do a press and hold to display reflected power on analog meter. 
            Button_A = NO; //reset flag
            if (op_mode != PWR) {
                // coming from some other op_mode, redraw the screen for PWR op_mode
                op_mode = PWR;  
            }                  
            // Save to EEPROM             
            EE_Save_State();            
        }
        if (Button_B == YES) {      // Select Cal Band
            ++CouplerSetNum;   // increment for manual button pushes
            if (CouplerSetNum > NUM_SETS) 
                CouplerSetNum = 0;
            if (Button_B == YES)
            {
                if (NewBand < 0)   // constrin newBand
                    NewBand = 0;   // something wrong if you end up here
                if (NewBand >= NUM_SETS)
                    NewBand = NUM_SETS-1; // something wrong if you end up here
            CouplerSetNum = NewBand;    // set to commanded band.  If a Button B remote cmd, NewBand wil lbe incremented before here                
            Button_B = NO; //reset flag
            Cal_Table();           
            EE_Save_State();
#ifdef NEXTION
            strcpy(cmd,Band_Cal_Table[CouplerSetNum].BandName);
            NexText_setText(&Set1_Bandvar);    // Update Nextion display for new values            
            toConfig_pop_Callback(0);  // when onteh COnfig pages will update them
            Set1_Callback(0);                       
#endif
            }
        }
        if (Button_C == YES) {
            Button_C = NO; //reset flag
            if (op_mode != SWR)  {
                op_mode = SWR;
                //save_config_EEPROM();
                EE_Save_State();
            }
        } 
        adRead(); //get and calculate power + SWR values and display them        
        
#ifdef SSD1306_OLED
        // Process OLED Display if used
        OLED();  // Update display for all params
#endif 
        
#ifdef NEXTION
        // Process Nextion Display events
        UART1interrupt();   // not really an interrupt but does get a char from the UART FIFO
        nexLoop(nex_listen_list);  // Process Nextion Display          
        update_Nextion();
#endif
        
        CyDelay(20);
    }
}

#ifdef NEXTION
    
void hv_adj_pop_Callback(void *ptr)
{
    uint32_t number;    
    ptr += 1; // get rid of compiler error about unused ptr    
    NexSlider_getValue(&hv_adj, &number);
    // Change meter ID with this info
    set_hv_max = number;
    set_hv_max /= 10.0;
}     
void v14_adj_pop_Callback(void *ptr)
{
    uint32_t number;
    ptr += 1; // get rid of compiler error about unused ptr    
    NexSlider_getValue(&v14_adj, &number);
    // Change meter ID with this info
    set_v14_max = number;
    set_v14_max /= 10.0;
}  
void curr_adj_pop_Callback(void *ptr)
{
    uint32_t number;    
    ptr += 1; // get rid of compiler error about unused ptr    
    NexSlider_getValue(&curr_adj, &number);
    // Change meter ID with this info
    set_curr_max = number;
    set_curr_max /= 10;
}  
void temp_adj_pop_Callback(void *ptr)
{
    uint32_t number;    
    ptr += 1; // get rid of compiler error about unused ptr    
    NexSlider_getValue(&temp_adj, &number);
    // Change meter ID with this info
    set_temp_max = (uint8_t)number;
}  
  
void band_set_adj_pop_Callback(void *ptr)
{
    uint32_t number;    
    ptr += 1; // get rid of compiler error about unused ptr    
    NexSlider_getValue(&band_set_adj, &number); 
    NewBand = (uint8_t) number;   // get inout for new band from Set1 page
    Button_B = YES; // set flag for main loop to process band change request.  
    // If there is a connection to radio (via serial or wireless) then it will override this at each update.                                                               
}

void meterID_adj_pop_Callback(void *ptr)
{
    uint32_t number;    
    ptr += 1; // get rid of compiler error about unused ptr    
    NexSlider_getValue(&meterID, &number);
    // Change meter ID with this info
    METERID = number;
}   
    
void FactoryRst1_pop_Callback(void *ptr)
{    
    ptr += 1; // get rid of compiler error about unused ptr    
    // Sequenctionally pressing thse adn Rst2 hotspot areas is the same as 2 button reset of M5Stack or remote commands 193+195
    Reset_Flag = 1;
}

void FactoryRst2_pop_Callback(void *ptr)
{
    ptr += 1; // get rid of compiler error about unused ptr
    if (Reset_Flag == 1) 
        reset_EEPROM();
        CyDelay(1000);
        toConfig_pop_Callback(0);
        update_Nextion();
    Reset_Flag = 0;
}

void savecfg_button_push_Callback(void *ptr)
{    
    ptr += 1; // get rid of compiler error about unused ptr
    //NexButton_setText(&savecfg_button, "Saving");
    LED_Write(0);
    LED_1_Write(0);
    CyDelay(200);
    LED_Write(1);
    LED_1_Write(1);
    
    EE_Save_State();  // push the button to commit the cal changes - Watch LED to see how long the EEPROM really takes.
    // There is 2 seconds total delay on the Nextion save config button to allow time for the CPU to finish loaded.
    
    LED_Write(0);    // write to both ports for KitProg and Main Board onboard LEDs
    LED_1_Write(0);
}

void savecfg_button_pop_Callback(void *ptr)
{   
    ptr += 1; // get rid of compiler error about unused ptr
    //NexButton_setText(&savecfg_button, "Saved Config");
    LED_Write(1);    // write to both ports for KitProg and Main Board onboard LEDs
    LED_1_Write(1);
}

void fwd_cal_pop_Callback(void *ptr) // Slider for Fwd Coupler Cal Value
{      
    ptr += 1; // get rid of compiler error about unused ptr   
    // Read value of slider sent in event and set in Cal table then echo it back to textbox
    NexSlider_getValue(&fwd_cal, &rcv_num); ;
    Band_Cal_Table[CouplerSetNum].Cpl_Fwd = rcv_num;
    sprintf(cmd, "%.1fdB%c", Band_Cal_Table[CouplerSetNum].Cpl_Fwd, '\0');  // Update lable with decimal value text
    NexText_setText(&fwd_cal_num);    
    Cal_Table();
}

void ref_cal_pop_Callback(void *ptr) // Slider for Ref Coupler Cal Value
{
    ptr += 1; // get rid of compiler error about unused ptr
    // Read value of slider sent in event and set in Cal table then echo it back to textbox
    NexSlider_getValue(&ref_cal, &rcv_num);            
    Band_Cal_Table[CouplerSetNum].Cpl_Ref = rcv_num;    
    sprintf(cmd, "%.1fdB%c", Band_Cal_Table[CouplerSetNum].Cpl_Ref, '\0');  // Update lable with decimal value text
    NexText_setText(&ref_cal_num);    
    Cal_Table();
}

void f_att_minus_pop_Callback(void *ptr) // fine tune slider by 0.1dB
{
    ptr += 1; // get rid of compiler error about unused ptr
    Band_Cal_Table[CouplerSetNum].Cpl_Fwd -= 0.1;
    sprintf(cmd, "%.1fdB%c", Band_Cal_Table[CouplerSetNum].Cpl_Fwd, '\0');  // Update lable with decimal value text
    NexText_setText(&fwd_cal_num);     
    Cal_Table();
}

void f_att_plus_pop_Callback(void *ptr)
{    
    ptr += 1; // get rid of compiler error about unused ptr          
    Band_Cal_Table[CouplerSetNum].Cpl_Fwd += 0.1;    
    sprintf(cmd, "%.1fdB%c", Band_Cal_Table[CouplerSetNum].Cpl_Fwd, '\0');  // Update lable with decimal value text
    NexText_setText(&fwd_cal_num);    
    Cal_Table();
}

void r_att_minus_pop_Callback(void *ptr)
{      
    ptr += 1; // get rid of compiler error about unused ptr    
    Band_Cal_Table[CouplerSetNum].Cpl_Ref -= 0.1;
    sprintf(cmd, "%.1fdB%c", Band_Cal_Table[CouplerSetNum].Cpl_Ref, '\0');  // Update lable with decimal value text
    NexText_setText(&ref_cal_num); 
    Cal_Table();
}

void r_att_plus_pop_Callback(void *ptr)
{
    ptr += 1; // get rid of compiler error about unused ptr   
    Band_Cal_Table[CouplerSetNum].Cpl_Ref += 0.1;    
    sprintf(cmd, "%.1fdB%c", Band_Cal_Table[CouplerSetNum].Cpl_Ref, '\0');  // Update lable with decimal value text
    NexText_setText(&ref_cal_num); 
    Cal_Table();
}

void toMain_push_Callback(void *ptr)
{
    ptr += 1; // get rid of compiler error about unused ptr
    pg = 0;   // flag Update function to only update when page is active 
    //NexPage_show(&page0);
}

void toConfig_pop_Callback(void *ptr)   // Got event to change to Config Page from somewhere
{
    uint8_t number;
    uint8_t ret1;    
    ptr += 1; // get rid of compiler error about unused ptr
    
    // Update the sliders to current values. SLider callbacks wil update after here.
    strcpy(cmd, "sendme");
    sendCommand(cmd);
    ret1 = recvPageNumber(&number);    
    if ( ret1 == 0 || number != 1)  // ensure we are on the correct page
    {
        //NexPage_show(&Coupler);
        ret1 = recvPageNumber(&number);
    }
    if (ret1 && number == 1)  // ensure we are on the correct page)
    {
        pg = 1;   // flag Update function to only update when page is active
        
        rcv_num = (uint32_t)(Band_Cal_Table[CouplerSetNum].Cpl_Fwd);
        NexSlider_setValue(&fwd_cal, rcv_num);  // Update slider knob position  0-100
         
        snprintf(cmd, 21, "%.1fdB%c", Band_Cal_Table[CouplerSetNum].Cpl_Fwd, '\0');  // Update label with decimal value text
        NexText_setText(&fwd_cal_num);
      
        // Initialize the sliders to the current band value for Reflected
        rcv_num = Band_Cal_Table[CouplerSetNum].Cpl_Ref;
        NexSlider_setValue(&ref_cal, rcv_num);
        
        snprintf(cmd, 20, "%.1fdB%c", Band_Cal_Table[CouplerSetNum].Cpl_Ref, '\0');  // Update label with decimal value text
        NexText_setText(&ref_cal_num);       
    }
}

/*
 *      Setpoints page on graphics display where alarm levels for things like voltage and temp are set.  
 *      These are globals so in theory do nto have to be on teh page to write to them
 *      Includes the unused *ptr so this can be used as a callback function if needed.
*/
void Set1_Callback(void *ptr)
{   
    //NexPage_show(&Set1);
    CyDelay(25);
    ptr += 1; // get rid of compiler error about unused ptr
    // The XYZ_max fields are considered the source for the slider to get its initial data from through the     
    //    the display's "Setpoints" page (page2) preinitialization section. After that the slider sends changes real time to the display
    //    not bothering the CPU until movement stops when an event is sent to the CPU where the slider callback will 
    //    get the XYZ_max value and store it in EEPROM.
    // For xfloat type object in Nextion, multiply the float x10 to get an integer it can use with teh slider
    // The display will format it with decimal point according to its config (num places to left and right of decimal point)
    NexSlider_setValue(&hv_adj, (uint16_t) (set_hv_max*10));
    NexNumber_setValue(&hv_max, (uint16_t) (set_hv_max*10));

    NexSlider_setValue(&v14_adj, (uint16_t) (set_v14_max*10));
    NexNumber_setValue(&v14_max, (uint16_t) (set_v14_max*10));

    NexSlider_setValue(&curr_adj, (uint16_t) (set_curr_max*10));
    NexNumber_setValue(&curr_max, (uint16_t) (set_curr_max*10));

    NexSlider_setValue(&temp_adj, (uint16_t) set_temp_max);
    NexNumber_setValue(&temp_max, (uint16_t) set_temp_max);
   
    NexSlider_setValue(&meterID_adj, METERID);
    NexNumber_setValue(&meterID, (uint16_t) METERID);
    
    // fix up initial position of slider knob for Band Slider
    NexSlider_setValue(&band_set_adj, CouplerSetNum);
    strcpy(cmd, Band_Cal_Table[CouplerSetNum].BandName);
    NexText_setText(&band_set);    
    strcpy(cmd, Band_Cal_Table[CouplerSetNum].BandName);
    NexText_setText(&band_cal);    
}

uint8_t update_Nextion()
{
    uint8_t number;
    float value;
    //uint16_t value1;
    //uint32_t number32;
  
    if (Timer_X00ms_InterruptCnt == Timer_X00ms_Last)
        return 0;   // skip out until greater than 100ms since our last visit here
    Timer_X00ms_Last_Nex = Timer_X00ms_InterruptCnt;
    strcpy(cmd, "sendme");
    sendCommand(cmd);
    if (!recvPageNumber(&number))
        return 0;
    if (number == 0) // only send this group of data while on page 0 every 250 ms at most
    { 
        if (pg != 0)
        {
            pg = 0; // set flag for page 0 change           
        }
        // only send these Page 0 commands if we are on page 0 else we will get invalid data return messages
        // Update float fields on display        
        if (FwdPwr > 9999.99)
            sprintf(cmd, "fwdpwr.txt=\"OVER\"");
        else if (FwdPwr > 999.99)
            sprintf(cmd, "fwdpwr.txt=\"%.0fW\"", FwdPwr);
        else
            sprintf(cmd, "fwdpwr.txt=\"%.1fW\"", FwdPwr);
        //NexText_setText(FwdPwr, cmd);   // create objects to uses the library commands
        sendCommand(cmd);
        if (RefPwr > 999.99)
            sprintf(cmd, "refpwr.txt=\"OVER\"");
        else if (RefPwr > 99.9)
            sprintf(cmd, "refpwr.txt=\"%.0fW\"", RefPwr);
        else
            sprintf(cmd, "refpwr.txt=\"%.1fW\"", RefPwr);
        sendCommand(cmd);
        
        sprintf(cmd, "FdBm.txt=\"%.2fdBm\"", Fwd_dBm);
        sendCommand(cmd);
        
        sprintf(cmd, "RdBm.txt=\"%.2fdBm\"", Ref_dBm);
        sendCommand(cmd);        
        
        value = SWRVal;
        if (value > 99.9)      // Display Overrange
        {
            sprintf(cmd, "SWR.txt=\"%s\"", "OVR");
            sendCommand(cmd);
            sprintf(cmd, "SWR.pco=63488");   // Red Text
            sendCommand(cmd);
        }
        else if (value > 2.0)      // Display Overrange
        {
            sprintf(cmd, "SWR.txt=\"%.1f\"", value);
            sendCommand(cmd);
            sprintf(cmd, "SWR.pco=63488");   // Red Text
            sendCommand(cmd);
        }
        else if (value < 0.1)    // Display greyed out NA
        {
            sprintf(cmd, "SWR.txt=\"%s\"", "NA");
            sendCommand(cmd);
            sprintf(cmd, "SWR.pco=50712");   // Flip value to grey
            sendCommand(cmd);
        }   
        else   // Display normal value
        {
            sprintf(cmd, "SWR.txt=\"%.1f\"", value);
            sendCommand(cmd);
            sprintf(cmd, "SWR.pco=65504");   // Flip value to normal yellow    
            sendCommand(cmd);  
        }    

        value = Input_hv_DC_Read();   // convert to full ADC read function - this is temp for now.

        value = 26.9;  // use for testing only then comment out or delete        
        //set_hv_max = 28.5;   // test value  Need to store in EEPROM
        
        if (value > set_hv_max)       
        {
            sprintf(cmd, "hv.pco=63488");   // Flip value to Red for high alert            
            sendCommand(cmd);        
        }
        else
        {
            sprintf(cmd, "hv.pco=2016");   // Flip value to normal yellow
            sendCommand(cmd);
        }
        sprintf(cmd, "hv.txt=\"%.1fV\"", value);
        sendCommand(cmd); 
        
        value = Input_14DC_Read();
        //set_v14_max = 14.8;  // test assignment
        value = 13.6;   // test assignment
        if (value > set_v14_max)
        {
            sprintf(cmd, "v14.pco=63488");   // Flip value to Red for high alert            
            sendCommand(cmd);
        }
        else
        {
            sprintf(cmd, "v14.pco=2016");   // Flip value to normal Yellow #65504                  
            sendCommand(cmd);
        }
        sprintf(cmd, "v14.txt=\"%.1fV\"", value);        
        sendCommand(cmd);
           
        value = Input_curr_Sensor_Read();
        //set_curr_max = 10;  // test assignment
        value = 11.2;
        if (value > set_curr_max)
        {        
            sprintf(cmd, "curr.pco=63488");   // Flip value to Red for high alert            
            sendCommand(cmd); 
        } 
        else
        {
            sprintf(cmd, "curr.pco=2016");   // Flip value to normal Yellow #65504                  
            sendCommand(cmd); 
        }
        sprintf(cmd, "curr.txt=\"%.1fA\"", value);
        sendCommand(cmd); 
        
        value = TempVal;
        //set_temp_max = 132;  // test assignment
        //value = 121.6;  // test value
        if (value > set_temp_max)
        {        
            sprintf(cmd, "temp.pco=63488");   // Flip value to Red for high alert            
            sendCommand(cmd); 
        } 
        else
        {
            sprintf(cmd, "temp.pco=2016");   // Flip value to normal Yellow #65504                  
            sendCommand(cmd); 
        }
        sprintf(cmd, "temp.txt=\"%.1fF\"", value);
        sendCommand(cmd); 

        /*
        if (!strcmp(Band_Cal_Table[CouplerSetNum].BandName,"222MHz"))
        {
            sprintf(cmd, "band.pco=2047");   // Flip value to normal cyan 2047
            sendCommand(cmd);
            sprintf(cmd, "band.bco=832");   // Flip value to normal cyan 2047
            sendCommand(cmd);
            sprintf(cmd, "band.txt=\"%s\"", "ONLINE");
            sendCommand(cmd);
        }
        else
        {
        */
        sprintf(cmd, "band.pco=65535");   // Flip value white
        sendCommand(cmd);            
        sprintf(cmd, "band.bco=20");   // Flip value to dark blue = background
        sendCommand(cmd);
        sprintf(cmd, "band.txt=\"%s\"", Band_Cal_Table[CouplerSetNum].BandName);
        sendCommand(cmd);            
        //}
        strcpy(cmd,Band_Cal_Table[CouplerSetNum].BandName);
        NexText_setText(&Set1_Bandvar);             
        
        return 1;
    }
    else if (number == 3) // only send this group of data while on page 0 every 250 ms at most
    {   // Page 3 is the Graphing page
        // Post up power and SWR values.  Display will read the values on a timer and update teh graph.  
        // It will also read the scale and cap the values to the scale max and scale the graph with its own math        
        
        if (FwdPwr > 1999.9)        
        {                                 
            NexNumber_setValue(&fPwrNum,1999); 
        }
        else
            NexNumber_setValue(&fPwrNum,FwdPwr);
            
        if (RefPwr > 999.9)        
        {   // graphing only accepts integer betwen 0 and 255. using 1000W max                    
            NexNumber_setValue(&rPwrNum,999); 
        }
        else
            NexNumber_setValue(&rPwrNum,RefPwr);             
                   
        // Just post up the value, the display will handle the math and graphing in a timer
        NexNumber_setValue(&swrNum,SWRVal*10); // uses xfloat so mult by 10 to shift decimal point      
    }    
    else if (number == 1)  // on the Config Page #1
    {   
        // should not be here.
        return 0;
    }
    return 1;
}
#endif  // end Nextion section

#ifdef SSD1306_OLED
/*                    
    TPrint to to 128x64 OLED graphics screen.  SSD1306 I2C type.
*/        
void OLED(void)
{ 
    char s[24];     
        
    display_clear();    
    gfx_drawRect( 0, 17, 127, 47, WHITE);
    
    // Top row is Yellow with Power in Watts, size 2 font
    gfx_setTextColor(WHITE);
    snprintf(s, 12, "  %*.1fW%c", 6, FwdPwr, '\0');
    gfx_setTextSize(2);    
    gfx_setCursor(4,0);
    gfx_println(s);
    
    //sprintf(s,"  Fwd    Ref    SWR");    
    gfx_setTextSize(1);    
    gfx_setCursor(16,20);
    gfx_println("Fwd");
    gfx_setCursor(58,20);
    gfx_println("Ref");
    gfx_setCursor(95,20);
    gfx_println("SWR");
    
    if (FwdPwr <= 0.1)
        sprintf(s, " %*.1f%*.1f%*s%c", 5, 0.0, 7, 0.0, 5, "NA", '\0'); 
    else
        sprintf(s, " %*.1f%*.1f%*.1f%c", 5, Fwd_dBm, 7, Ref_dBm, 6, SWRVal, '\0');    
    gfx_setTextSize(1);
    gfx_setCursor(1,30);
    gfx_println(s);
    
    sprintf(s,"Temp:%*dF%c", 3, 113, '\0');   // fake it for now
    gfx_setTextSize(1);
    gfx_setCursor(5,49);
    gfx_println(s);
    
    sprintf(s,"Curr:%*.1f%c", 4, 9.6, '\0');   // fake it for now
    gfx_setTextSize(1);
    gfx_setCursor(68,49);
    gfx_println(s);
    
    display_update();    // NOTE: You should remember to update the display in order to see the results on the oled. 
}
#endif // end SSD1306_OLED section

/*******************************************************************************
* Function Name: serial_usb_read
********************************************************************************
*
* Summary:
*  The main function performs the following actions:
*   1. Waits until VBUS becomes valid and starts the USBFS component which is
*      enumerated as virtual Com port.
*   2. Waits until the device is enumerated by the host.
*   3. Waits for data coming from the hyper terminal and sends it back.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
uint16 serial_usb_read(void)
{
    if (0u != Serial_USB_IsConfigurationChanged())    /* Host can send double SET_INTERFACE request. */
    {
        if (0u != Serial_USB_GetConfiguration())         /* Initialize IN endpoints when device is configured. */
        {            
            Serial_USB_CDC_Init(); /* Enumeration is done, enable OUT endpoint to receive data from host. */
        }
    }
    
    rx_count = 0;    
    if (0u != Serial_USB_GetConfiguration())      /* Service USB CDC when device is configured. */
    {        
        if (0u != Serial_USB_DataIsReady()) /* Check for input data from host. */
        {   
            rx_count = Serial_USB_GetAll(rx_buffer);    /* Read received data and re-enable OUT endpoint. */     
        }   
        if (rx_count != 0){         // initially p1 = p2.  parser will move p1 up to p2 and when they are equal, buffer is empty, parser will reset p1 and p2 back to start of sData
            memcpy(pSdata2 , rx_buffer, rx_count);   // append the new buffer data to current end marked by pointer 2
            pSdata2 += (rx_count);   // Update the end pointer position. The function processing chars wil lupdate teh p1 and p2 pointers
            //*(pSdata2) = '\0';
            rx_count = pSdata2 - pSdata1;  // update count for total unread chars.
        }
    }
    return rx_count;
}

/*******************************************************************************
* Function Name: serial_usb_write
********************************************************************************
*
* Summary:
*  The main function performs the following actions:
*   1. send 1 character ou thte usb virtual comm port.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void serial_usb_write(void)
{   
    uint32_t exit_Count;
    #define EXIT_CTR 2500
    
    tx_count = strlen((char *) tx_buffer);
    
    if (0u != tx_count)
    {
        exit_Count = 0;
        /* Wait until component is ready to send data to host. */
        while (0u == Serial_USB_CDCIsReady() && exit_Count < EXIT_CTR) 
        {
            ++exit_Count; 
            if (exit_Count > EXIT_CTR - 2)  // emergency escape plan to prevent a hang
                return;
        }
        Serial_USB_PutData(tx_buffer, tx_count);         /* Send data back to host. */

        /* If the last sent packet is exactly the maximum packet 
        *  size, it is followed by a zero-length packet to assure
        *  that the end of the segment is properly identified by 
        *  the terminal.
        */
        if (Serial_USB_BUFFER_SIZE == tx_count)
        {
            exit_Count = 0;
            
            while (0u == Serial_USB_CDCIsReady() && exit_Count < EXIT_CTR)            /* Wait until component is ready to send data to PC. */
            {
                ++exit_Count; 
                if (exit_Count > EXIT_CTR - 2)  // emergency escape plan to prevent a hang
                    return;
            }
            Serial_USB_PutData(NULL, 0u);            /* Send zero-length packet to PC. */
        }
    }
}

void adRead(void)   // A/D converter read function.  Normalize the AD output to 100%.
{
    float32 a;
    float32 b;
    uint16 c;
    float32 tmp;
    uint32 ad_counts;

    // Throttle the time the CPU spends here.   Offset the timing os teh data acquired is just before it is sent out
    if (Timer_X00ms_InterruptCnt == Timer_X00ms_Last_AD)   // will use our own timestamp.
        return;   // skip out until greater than 100ms since our last visit here
    Timer_X00ms_Last_AD = Timer_X00ms_InterruptCnt;  // time stamp our visit here.  Do not want to come back too soon.
    
#ifdef DETECTOR_TEMP_CONNECTED
    // Read detector temperature (If connected)
    AMux_RF_Power_FastSelect(MUX_TEMP);  // 2 is mux port connected to the temperature IO pin.
    CyDelayUs(5);
    ad_counts = ADC_RF_Power_Read32();
    tmp = ADC_RF_Power_CountsTo_Volts(ad_counts);      // store the detector temp reading for cal optimization if desired.  For now jsut display it on the screen
    tmp -= 1.36;   // ADL5519 is 4.48mV/C at 27C which is typically 1.36VDC.  Convert to F.  
    tmp /= 0.00448;   // mV/C
    tmp += 27;   //1.36V at 27C (80.6F)
    tmp *= 9;
    tmp /= 5;    // convert to F
    tmp += 32;    
    TempVal = tmp;
    
#endif    

    // Get Reflected Power     
    total_Ref -= readings_Ref[readIndex_Ref];// subtract the last reading:    
    c = 1; // read from the sensor:
    a = 0;
    for (int i = 0; i < c; ++i)  {
        // ADC_RF_Power_SetGain(1);  // can be used to tweak in the ADC                
        AMux_RF_Power_FastSelect(MUX_REF);
        CyDelayUs(5);        
        ad_counts = ADC_RF_Power_Read32();                
        RefVal = ADC_RF_Power_CountsTo_Volts(ad_counts);
        a += RefVal;
    }
    a /= c; // calculate the average then use result in a running average
    readings_Ref[readIndex_Ref] = a;   // get from the latest average above and track in this runnign average
    total_Ref += readings_Ref[readIndex_Ref];// add the reading to the total:
    readIndex_Ref += 1;       // advance to the next position in the array:
    if (readIndex_Ref >= NUMREADINGS) { // if we're at the end of the array...        
        readIndex_Ref = 0;// ...wrap around to the beginning:
    }
    // caclulate dB value for digital display section
    b = total_Ref / NUMREADINGS;// calculate the average:        
    b -= Offset_R;   // adjust to 0V reference point
    b /= Slope_R;   // will be negative for detectors like AD8318
    b += CouplingFactor_Ref;
    b += 0.0; // fudge factor for frequency independent factors like cabling
    
    Ref_dBm = b;
    // 0dBm is max. = 1W fullscale on 1W scale.
    RefPwr = pow(10.0,(b-30.0)/10.0);    // convert to linear value for meter using 1KW @ 0dBm as reference 
    if (RefPwr > 999.9) 
        RefPwr = 999.9999;

    // subtract the last reading for Fwd Power
    total_Fwd -= readings_Fwd[readIndex_Fwd];
    // read from the sensor:
    c = 1;   // short term smaples that feed into running average
    a = 0;
    for (int i = 0; i < c; ++i) {                   
        // ADC_RF_Power_SetGain(1);  // can be used to tweak in the ADC
        AMux_RF_Power_FastSelect(MUX_FWD);  
        CyDelayUs(5);
        ad_counts = ADC_RF_Power_Read32();        
        FwdVal = ADC_RF_Power_CountsTo_Volts(ad_counts);    
        a += FwdVal;
    }
    a /= c; // calculate the average then use result in a running average
    readings_Fwd[readIndex_Fwd] = a;   // get from the latest average above and track in this runnign average
    total_Fwd += readings_Fwd[readIndex_Fwd];    // add the reading to the total: 
    readIndex_Fwd += 1;     // advance to the next position in the array:
    if (readIndex_Fwd >= NUMREADINGS) {     // if we're at the end of the array...      
        readIndex_Fwd = 0;  // ...wrap around to the beginning:
    }     
    b = total_Fwd / NUMREADINGS;    // calculate the average:
    // caclulate dB value for digital display section
    b -= Offset_F;   // adjusts to 0V reference point - calculated during cal
    b /= Slope_F;   // will be negative for detectors like AD8318 - calculated during cal
    b += CouplingFactor_Fwd;
    b += 0.0; // Fudge factor for frequency independent factors like cabling
    Fwd_dBm = b;    // Now have calibrated Forward Value in dBm.
    // 0dBm is max. = 1W fullscale on 1W scale for example
    FwdPwr =  pow(10.0,(b-30.0)/10.0);    // convert to linear value for meter using 1KW @ 0dBm as reference. Multiply by scale value.
    if (FwdPwr > 9999.9)
        FwdPwr = 9999.9999;
    
    tmp = sqrt(RefPwr/FwdPwr);
    SWRVal = ((1 + tmp) / (1 - tmp));  // now have SWR in range of 1.0 to infinity.  
    if (RefPwr <= 0.2 || FwdPwr <= 0.2)
        SWRVal = 0;   // remove misleading SWR numbers when input are floating around in RX mode.
    if (SWRVal > 9.9)
        SWRVal = 10;
    
    SWR_Serial_Val = SWRVal;
    FwdPwr_last = FwdPwr;  // update memory to minimize screen update and flicker on digital number
    sendSerialData();   // send this data to the serial port for remote monitoring
}

/*
 *   Send out dBm, Watts, and SWR values to data channel - serial, WiFi, or Bluetooth
*/
void sendSerialData()
{
    if (Timer_X00ms_InterruptCnt != Timer_X00ms_Last)
    {
        Timer_X00ms_Last_USB = Timer_X00ms_InterruptCnt;       
        sprintf((char *) tx_buffer,"%d,%s,%s,%.2f,%.2f,%.1f,%.1f,%.1f\r\n%c", METERID, "170", Band_Cal_Table[CouplerSetNum].BandName, Fwd_dBm, Ref_dBm, FwdPwr, RefPwr, SWR_Serial_Val, '\0');       
        serial_usb_write();   
    }
}

void get_remote_cmd()
{
    uint8 cmd1;
    float32 cmd2;
    uint8 cmd_str_len;
    uint8 i = 0; 
    uint8 j = 0;
    char cmd_str[BUF_LEN] = {};
    
    
    if (rx_count !=0) {
        pSdata = strchr(pSdata1, '\n');   // find string terminator position
        if (pSdata) { 
            *pSdata = '\0';
            cmd_str_len = pSdata - pSdata1;
            strncpy(cmd_str, pSdata1, cmd_str_len);   // copy chars between p1 and the terminator
            pSdata1 += (cmd_str_len+1);  // reset ch pointer back to stat of string for char parsing
             
            if (pSdata1 >= pSdata2 || cmd_str_len > BUF_LEN)  // if we have caught up to the end p2 then reset to beginning of buffer position.
                pSdata1 = pSdata2 = sdata; 
        
            if (strlen(sdata) >= BUF_LEN-1) {
                //pSdata = sdata;
                sdata[0] = '\0';
                //printf("BUFFER OVERRRUN\n");
                //Serial_ClearRxBuffer();            
                return;
            }
            // filter out unwanted characters             
            // Now we have a full comma delimited command string - validate and break it down           
            j = 0;
            for (i=0; (sdata[i] != ',') && (i <= cmd_str_len); i++) {
                if (isalnum(sdata[i]))
                    cmd_str[j++] = (sdata[i]);                 
            }
            cmd_str[j] = '\0';  
            printf(" Meter ID  ");
            printf("%s\n",cmd_str);

            if (atoi(cmd_str) == METERID) {
                if (i < cmd_str_len) {
                    j = 0;
                    // Look for Msg_Type now
                    for (i +=1; (sdata[i] != ',') && (i <= cmd_str_len); i++) {   // i+1 to skip over the comma the var 'i' was left pointing at
                        cmd_str[j++] = sdata[i];                 
                    }
                    cmd_str[j] = '\0';
                    printf(" Msg Type:  ");
                    printf("%s",cmd_str);
                  
                    if (atoi(cmd_str) == 120)  {   // Vaidate this message type for commands.  120 = coammand, 170 is data output                              
                        j = 0;
                        if (i < cmd_str_len) {                               
                            for (i += 1; (sdata[i] != ',') && (i <= cmd_str_len); i++) {
                                cmd_str[j++] = sdata[i];
                            }  
                            cmd_str[j] = '\0';
                            printf(" CMD1:  ");
                            printf("%s",cmd_str);
                            cmd1 = atoi(cmd_str);
                        }
                        else 
                            cmd1 = 0;
                        
                        j = 0;
                        if (i < cmd_str_len) {                                                
                            for (i += 1; (sdata[i] != ',') && (i <= cmd_str_len); i++) {
                                cmd_str[j++] = sdata[i];                          
                            }
                            cmd_str[j] = '\0';
                            printf(" CMD2:  ");
                            printf("%s",cmd_str);
                            cmd2 = atof(cmd_str);
                        }
                        else 
                            cmd2 = 0.0;
                  
                        // Now do the commands     
                        // add code to limit variables received to allowed range
                        if (cmd1 == 255) Button_A = YES;   // switch scale - not really useful if you cannot see the meter face, data is not changed
                        if (cmd1 == 254) {
                            Button_B = YES;   // switch bands
                            //CouplerSetNum = constrain(CouplerSetNum, 0, NUM_SETS);  
                            NewBand = CouplerSetNum +1;    // Update Newband to current value.  Will be incrmented in button function                          
                            if (NewBand > NUM_SETS) 
                                NewBand = 0;  // cycle back to lowest band
                        }
                        if (cmd1 == 253) Button_C = YES;   // Switch op_modes betweem SWR and PWR - same as scale, not useful lif you cannot seethe meter face.
                        if (cmd1 == 252) print_cal_table();  //Speed up or slow down the Serial line output info rate
                        if (cmd1 == 251) NULL;  // Not Used yet
                        if (cmd1 == 250) {   // dump current cal table to remote  (Was Scale GUI button)
                            Button_B = YES;
                            NewBand = 10;  
                        }   
                        if (cmd1 == 249) {     // Jump to Band 5.7G
                            Button_B = YES;
                            NewBand = 9;  
                        }
                        if (cmd1 == 248) {     // Jump to Band 3.4G
                            Button_B = YES;
                            NewBand = 8;  
                        }
                        if (cmd1 == 247) {     // Jump to Band 2.3G
                            Button_B = YES;
                            NewBand = 7;  
                        }
                        if (cmd1 == 246) {     // Jump to Band 1296
                            Button_B = YES;
                            NewBand = 6;  
                        }
                        if (cmd1 == 245) {     // Jump to Band 902
                            Button_B = YES;
                            NewBand = 5;  
                        }
                        if (cmd1 == 244) {     // Jump to Band 432
                            Button_B = YES;
                            NewBand = 4;  
                        }
                        if (cmd1 == 243) {     // Jump to Band 222
                            Button_B = YES;
                            NewBand = 3;  
                        }
                        if (cmd1 == 242) {     // Jump to Band 144
                            Button_B = YES;
                            NewBand = 2;  
                        }
                        if (cmd1 == 241) {     // Jump to Band 50
                            Button_B = YES;
                            NewBand = 1;  
                        }
                        if (cmd1 == 240) {     // Jump to Band HF
                            Button_B = YES;
                            NewBand = 0;  
                        }
                        if (cmd1 == 239) {     // Toggle Serial power data outpout.  Other serial functions remain available.
                            toggle_ser_data_output();
                        }
                        if (cmd1 == 193) {    // Set up for potential EEPROM Reset if followed by 5 second press on Button C
                            Reset_Flag = 1;
                            print_Cmd_Progress(1);   // Use when there is a start and stop with delay the remote needs to know about
                        }
                        if (cmd1 == 194) {     // Set Reset EEPROM flag.  Will repopulate after CPU reset
                            if (Reset_Flag == 1) 
                                reset_EEPROM();
                            Reset_Flag = 0;   
                            print_Cmd_Progress(0);
                        }
                        if (cmd1 == 195) {    // Save to EEPROM - Usually following cal changes from Remote meter appp that are not committed yet                          
                            Cal_Table_write();
                            EEPROM_Init_Write();    // save to eeprom on changes.  
                            EEPROM_Init_Read();     // load the values into memory to check them
                            Cal_Table();  // read back to be sure it save correctly                          
                           // Probably use a sw wd to do a software remote reset for PSoC5.
                        }                            
                        // Handle remote command to change stored coupling factor to support headless ops.
                        // TODO: Need to write into EEPROM, either here or by changing bands.                          
                        if (cmd1 >= 100 && cmd1 < 120) {     // Change Fwd coupling factor for Port X
                            int index;
                            index = cmd1 - 100;
                            Band_Cal_Table[index].Cpl_Fwd = cmd2;       // cmd2 is second byte in 2 byte payload.                              
                            EEPROM_Init_Write();    // save to eeprom
                            EEPROM_Init_Read();     // load the values into memory
                            Cal_Table();
                        }
                        if (cmd1 >= 120 && cmd1 < 140) {     // Change Ref coupling factor for Port X
                            int index;
                            index = cmd1 - 120;
                            Band_Cal_Table[index].Cpl_Ref = cmd2;       // cmd2 is second byte in 2 byte payload.                              
                            EEPROM_Init_Write();    // save to eeprom on changes.  
                            EEPROM_Init_Read();     // load the values into memory
                            Cal_Table();
                        }  
                        if (cmd1 >= 140 && cmd1 < 160) {     // Change Ref coupling factor for Port X by + cmd2 value
                            int index;
                            index = cmd1 - 140;
                            Band_Cal_Table[index].Cpl_Ref = Band_Cal_Table[index].Cpl_Ref + cmd2;       // cmd2 is second byte in 2 byte payload.                              
                            EEPROM_Init_Write();    // save to eeprom on changes.  
                            EEPROM_Init_Read();     // load the values into memory
                            Cal_Table();
                        }                                                                                                  
                        if (cmd1 >= 160 && cmd1 < 180) {     // Change Ref coupling factor for Port X by - cmd2 value
                            int index;
                            index = cmd1 - 160;
                            Band_Cal_Table[index].Cpl_Ref = Band_Cal_Table[index].Cpl_Ref - cmd2;       // cmd2 is second byte in 2 byte payload.                              
                            EEPROM_Init_Write();    // save to eeprom on changes.  
                            EEPROM_Init_Read();     // load the values into memory
                            Cal_Table();
                        }
                        if (cmd1 == 96) {     // Jump to Band HF
                           Nextion_Switch_Write(1);    // Switch serial from display to USB UART converter                                                                      
                        }
                        if (cmd1 == 95) {     // Jump to Band HF
                           Nextion_Switch_Write(0);    // Switch serial from display to CPU                                                        
                        }
                        if (cmd1 == 94) {    // This is an attempt at auto cal routine. cmd is target Fwd value.
                            //if higher than cmd 2 decrement, do adread(), check and adj again until a near match.
                            // Challenge might be impossible to get an exact match, so need close enough decision logic.
                            for (i = 0; i< 100; i++)   // put a limit on to ensure we do nto have an endless loop if we cannot get a match within the window
                            {
                                if (FwdPwr > cmd2+4.0 && FwdPwr > 10.0) // Coarse tune
                                {
                                    // decrement 
                                    CouplingFactor_Fwd -= 0.5;
                                    adRead();  // get new values                                
                                    print_Cal_Table_progress(1);
                                }
                                else if (FwdPwr > cmd2+0.1) // coarse tune range
                                {
                                    // decrement 
                                    CouplingFactor_Fwd -= 0.01;
                                    adRead();  // get new values                                
                                    print_Cal_Table_progress(1);
                                }
                                else if (FwdPwr < cmd2-4.0 && FwdPwr > 10.0)
                                {
                                    // increment
                                    CouplingFactor_Fwd += 0.5;
                                    adRead();  // get new values                                
                                    print_Cal_Table_progress(1);
                                }  
                                else if (FwdPwr < cmd2-0.1)
                                {
                                    // increment
                                    CouplingFactor_Fwd += 0.01;
                                    adRead();  // get new values                                
                                    print_Cal_Table_progress(1);
                                }  
                                else    
                                {
                                    i=100;   // exit the loop                                 
                                    // if neither of the above then assume we are close enough and move on using the current value
                                    //Cal_Table();   // update the current band values for adRead to use 
                                    print_Cal_Table_progress(0);
                                    sprintf((char *) tx_buffer,"*** FwdPwr=%.2f   Loop count =%d ***\r\n", FwdPwr, i);   // debug message to Serial USB
                                    serial_usb_write();
                                    Cal_Table_write(); 
                                    //EEPROM_Init_Write();    // save to eeprom
                                    //EEPROM_Init_Read();     // load the values into memory
                                    Cal_Table();  // read it back                                   
                                }  
                                adRead();
                            }
                        }
                        if (cmd1 == 93) {    // This is an alternative auto cal routine changing the attenuation only. cmd is target Ref value.                         
                            for (i = 0; i< 100; i++)   // put a limit on to ensure we do nto have an endless loop if we cannot get a match within the window
                            {
                                if (RefPwr > cmd2+1.0) // Fine tune
                                {
                                    // decrement 
                                    CouplingFactor_Ref -= 0.5;
                                    adRead();  // get new values                                                                   
                                    serial_usb_write();
                                    print_Cal_Table_progress(1);
                                }
                                else if (RefPwr > cmd2+0.1) // coarse tune range
                                {
                                    // decrement 
                                    CouplingFactor_Ref -= 0.01;
                                    adRead();  // get new values                                                                    
                                    serial_usb_write();
                                    print_Cal_Table_progress(1);
                                }
                                else if (RefPwr < cmd2-1.0)
                                {
                                    // increment
                                    CouplingFactor_Ref += 0.5;
                                    adRead();  // get new values                                
                                    serial_usb_write();
                                    print_Cal_Table_progress(1);
                                }  
                                else if (RefPwr < cmd2-0.1)
                                {
                                    // increment
                                    CouplingFactor_Ref += 0.01;
                                    adRead();  // get new values                                
                                    serial_usb_write();
                                    print_Cal_Table_progress(1);
                                }  
                                else    
                                {
                                    i=100;   // exit the loop                                 
                                    // if neither of the above then assume we are close enough and move on using the current value
                                    print_Cal_Table_progress(0);  // end of loop
                                    sprintf((char *) tx_buffer,"*** RefPwr=%.2f   Loop count =%d ***\r\n", RefPwr, i);   // debug message to Serial USB                                    
                                    serial_usb_write();
                                    Cal_Table_write(); 
                                    //EEPROM_Init_Write();    // save to eeprom
                                    //EEPROM_Init_Read();     // load the values into memory
                                    Cal_Table();  // read it back                                    
                                }                               
                            }
                        }
                        if (cmd1 == 92) 
                        {    // Get Slope from user (if needed, normally calculated)
                            Slope_F = cmd2;                            
                        }
                        if (cmd1 == 91) 
                        {    // Get Slope from user (if needed, normally calculated)
                            Slope_R = cmd2;                                           
                        }                                                                                     
                        if (cmd1 == 90) 
                        {    // Get Offset from user (if needed, normally calculated)
                            Offset_F = cmd2;                            
                        }
                        if (cmd1 == 89) 
                        {    // Get Offset from user (if needed, normally calculated)
                            Offset_R = cmd2;                                           
                        }  
                        if (cmd1 == 79) 
                        {    // Get target power level from user in Watts, convert to dBm then measure and save ADC                            
                            Pwr_hi = cmd2;    
                            Pwr_hi = 10 * log10(1000*(Pwr_hi/1));
                            adRead();  // update our high power readings for foprward and reflected power for the current band
                            FwdVal_hi = FwdVal; // save for calc                            
                            RefVal_hi = RefVal;  // save for calc    
                            print_Cal_Table_progress(1);  // end of loop
                        }
                        if (cmd1 == 78) 
                        {    // Get target power level from user in dBm then measure and save ADC                            
                            Pwr_hi = cmd2;                                
                            adRead();  // update our high power readings for foprward and reflected power for the current band
                            FwdVal_hi = FwdVal; // save for calc                            
                            RefVal_hi = RefVal;  // save for calc    
                            print_Cal_Table_progress(1);  // end of loop
                        }
                        if (cmd1 == 77) 
                        {    // Get target power level from user in Watts, convert to dBm then measure and save ADC                            
                            Pwr_lo = cmd2;    
                            Pwr_lo = 10 * log10(1000*(Pwr_lo/1));
                            adRead();  // update our high power readings for foprward and reflected power for the current band
                            FwdVal_lo = FwdVal; // save for calc                            
                            RefVal_lo = RefVal;  // save for calc    
                            print_Cal_Table_progress(1);  // end of loop
                        }
                        if (cmd1 == 76) 
                        {    // Get target power level from user in dBm then measure and save ADC                            
                            Pwr_lo = cmd2;                            
                            adRead();  // update our high power readings for foprward and reflected power for the current band
                            FwdVal_lo = FwdVal; // save for calc                            
                            RefVal_lo = RefVal;  // save for calc    
                            print_Cal_Table_progress(1);  // end of loop
                        }
                        if (cmd1 == 75) // Fwd Direction Calc
                        {   // Use stored values of Hi and lo power for Fwd direction
                            if (Pwr_hi != 0) // ensure we have a valid high power number before calculating.
                            {                      
                                // Calculate Slope and Offset
                                Slope_F = (FwdVal_hi - FwdVal_lo)/(Pwr_hi - Pwr_lo);
                                Offset_F = FwdVal_hi + ((CouplingFactor_Fwd - Pwr_hi) * Slope_F);
                                Cal_Table_write();
                                //EEPROM_Init_Write();    // save to eeprom on changes.  
                                //EEPROM_Init_Read();     // load the values into memory to check them
                                Cal_Table();  // read back to be sure it save correctly                                
                                print_Cal_Table_progress(0);  // end of loop
                            }
                        }
                        if (cmd1 == 74) //Ref Direction Calc
                        {    // Use stored values of Hi and lo power for Ref direction
                            if (Pwr_hi != 0) // ensure we have a valid high power number before calculating.
                            {                             
                                // Calculate Slope and Offset
                                Slope_R = (RefVal_hi - RefVal_lo)/(Pwr_hi - Pwr_lo);
                                Offset_R = RefVal_hi + ((CouplingFactor_Ref - Pwr_hi) * Slope_R);
                                Cal_Table_write();
                                //EEPROM_Init_Write();    // save to eeprom on changes.  
                                //EEPROM_Init_Read();     // load the values into memory to check them
                                Cal_Table();  // read back to be sure it save correctly
                                print_Cal_Table_progress(0);  // end of loop
                            }
                        }
                    } // end of msg_type 120                                      
                } // end of msg_type length check
            } // end of meter ID OK    
        } // end of \n found
    } //end rx_count not 0
} // end get_remote_cmd function

// Copy hard coded cal data to memory
void write_Cal_Table_from_Default()
{
  uint i;
  
  for (i=0;i<NUM_SETS;i++) {
    // Populate initial database scructure in RAM.  Ultimately it needs to be read from EEPROM once initialized
    strcpy(Band_Cal_Table[i].BandName, Band_Cal_Table_Def[i].BandName);
    Band_Cal_Table[i].Cpl_Fwd = Band_Cal_Table_Def[i].Cpl_Fwd;
    Band_Cal_Table[i].Slope_F = Band_Cal_Table_Def[i].Slope_F;
    Band_Cal_Table[i].Offset_F = Band_Cal_Table_Def[i].Offset_F;
    Band_Cal_Table[i].Cpl_Ref = Band_Cal_Table_Def[i].Cpl_Ref;   
    Band_Cal_Table[i].Slope_R = Band_Cal_Table_Def[i].Slope_R;
    Band_Cal_Table[i].Offset_R = Band_Cal_Table_Def[i].Offset_R;
    
    //printf("Copied default data info Band Cal Table");
    set_hv_max = HV_MAX; // reset the setpoints and mterid and band
    set_v14_max = V14_MAX;      
    set_curr_max = CURR_MAX;
    set_temp_max = TEMP_MAX;
    METERID = default_METERID;
    CouplerSetNum = 0;
  }
}

// Mark EEPROM for overwrite
void reset_EEPROM()
{
    if (Reset_Flag ==1) {
        // erase byte 0 to force init process for testing.  Can also use to "factory" reset data     
        set_hv_max = HV_MAX;
        set_v14_max = V14_MAX;
        set_curr_max = CURR_MAX;
        set_temp_max = TEMP_MAX;
        EEPROM_WriteByte(0,EE_STATE_BASE_ADDR);
        write_Cal_Table_from_Default();
        EEPROM_Init(EE_SAVE_YES);
        //printf("Erased Byte 0");
        EEPROM_Init_Read();     // load the values into m
        Cal_Table();
    }
}

// Toggle USB serial output data
void toggle_ser_data_output()
{
     if (EEPROM_ReadByte(EE_STATE_BASE_ADDR+SER_DATA_OUT_OFFSET) != 'Y' || ser_data_out == 1){
        EEPROM_WriteByte(EE_STATE_BASE_ADDR+SER_DATA_OUT_OFFSET, 'Y');
        //printf("Enabled Serial Data Output");
        ser_data_out = 0;
     }
     else { 
        EEPROM_WriteByte(EE_STATE_BASE_ADDR+SER_DATA_OUT_OFFSET , 'N');
        //printf("Disabled Serial Data Output");
     }
}

void Cal_Table()
{
    // Each coupler has unique coupling factor. 
    CouplingFactor_Fwd = Band_Cal_Table[CouplerSetNum].Cpl_Fwd;  // value in dB from coupler specs.  
    CouplingFactor_Ref = Band_Cal_Table[CouplerSetNum].Cpl_Ref;
    Slope_F = Band_Cal_Table[CouplerSetNum].Slope_F;
    Offset_F = Band_Cal_Table[CouplerSetNum].Offset_F;
    Slope_R = Band_Cal_Table[CouplerSetNum].Slope_R;
    Offset_R = Band_Cal_Table[CouplerSetNum].Offset_R;
}
    
void Cal_Table_write(void)
{
    Band_Cal_Table[CouplerSetNum].Cpl_Fwd = CouplingFactor_Fwd;  // value in dB from coupler specs.  
    Band_Cal_Table[CouplerSetNum].Cpl_Ref = CouplingFactor_Ref;    
    Band_Cal_Table[CouplerSetNum].Slope_F = Slope_F;
    Band_Cal_Table[CouplerSetNum].Offset_F = Offset_F;
    Band_Cal_Table[CouplerSetNum].Slope_R = Slope_R;
    Band_Cal_Table[CouplerSetNum].Offset_R = Offset_R;
}

void print_cal_table()
{
    uint8   i;

    // example output format : "101,150,TEXT,55.4,35.4,3.3,2.2"
    // #150 for msg_type field to signal this is data dump, not power levels or other type messages.
    // meterid with msg_type = 150 to signal different data set than the normal output. 120 inbound cmd, 170, power out
    for (i=0; i < NUM_SETS; i++) {        
        sprintf((char *) tx_buffer, "%d,%s,%s,%.1f,%.5f,%.5f,%.1f,%.5f,%.5f\r\n", METERID, "150", Band_Cal_Table[i].BandName, Band_Cal_Table[i].Cpl_Fwd, Band_Cal_Table[i].Slope_F, Band_Cal_Table[i].Offset_F, Band_Cal_Table[i].Cpl_Ref, Band_Cal_Table[i].Slope_R, Band_Cal_Table[i].Offset_R);
        tx_count = strlen((char *) tx_buffer);        
        serial_usb_write();   // Output table text to serial port              
    }
}

/*
Start or end of cal message output to serial port.  1 is start, 0 is end.  Message type is 161 and 160.
 used to adjust dBm levels to match watts target using existing slope and offset.
*/
void print_Cal_Table_progress(uint8_t flag)
{   // uses current Offset and slope
    flag +=160;   // translate to start or end of cal procedure message type.   161 start, 160 end
    // example output format : "101,150,TEXT,55.4,35.4,3.3,2.2"
    // #161/160 for msg_type field to signal this is a cal calculation in progress
    //sprintf((char *) tx_buffer, "%d,%d,%s,%.2f,%.4f,%.2f,%.4f\r\n", METERID, flag, Band_Cal_Table[CouplerSetNum].BandName, CouplingFactor_Fwd, FwdVal, CouplingFactor_Ref, RefVal);        
    sprintf((char *) tx_buffer, "%d,%d,%s,%.5f,%.5f,%.5f,%.5f\r\n", METERID, flag, Band_Cal_Table[CouplerSetNum].BandName, FwdVal_hi, FwdVal_lo, RefVal_hi, RefVal_lo);
    tx_count = strlen((char *) tx_buffer);
    serial_usb_write();   // Output table text to serial port                  
}

/*
Start or end of cal message output to serial port.  1 is start, 0 is end.  Message type is 161 and 160.
 used to adjust dBm levels to match watts target using existing slope and offset.
*/
void print_Cmd_Progress(uint8_t flag)
{   // uses current Offset and slope
    flag +=162;   // translate to start or end of cal procedure message type.   163 start, 162 end
    // example output format : "101,162,TEXT"
    // #163/162 for msg_type field to signal this is data dump, not power levels or other type messages.
    // Send out raw ADC voltage readings
    sprintf((char *) tx_buffer, "%d,%d,%s,%.5f,%.5f,%.5f,%.5f\r\n", METERID, flag, Band_Cal_Table[CouplerSetNum].BandName, FwdVal_hi, FwdVal_lo, RefVal_hi, RefVal_lo);        
    tx_count = strlen((char *) tx_buffer);
    serial_usb_write();   // Output table text to serial port                  
}

/*******************************************************************************
* Function Name: EEPROM_Init
********************************************************************************
* Summary:
*   Called for Initialization, Check Byte 0 != G then copy into EEPROM space the needed variables
*   and the Band_Cal_Table structure. There can be other data in the rest of EEPROM.
*   Variables wil be reset to default after an overwrite.  A master reset menu option may be created to do this via the menu system
*  
*    Test Address 0.
*    Values for Address 0 (EEPROM_Cfg_Status)
*        0x00   Uninitialized or Erased
*        'S'  Initialization Started
*        'G'  Initialization Completed
*   
* Parameters:
*   None
*
* Return:
*   0 for success, 1 for FAIL
*
*******************************************************************************/

uint8_t EEPROM_Init(uint8 ee_save)
{
    /*  If we find a 'G' character at the start of EEPROM then skip initialization to prevent user data overwrite */   
    EE_PGM_Status = EEPROM_ReadByte(EE_STATE_BASE_ADDR);    
    if(((EE_PGM_Failed == NO) && EE_PGM_Status != 'G') || ee_save == EE_SAVE_YES)   /*   EEPROM_Init will set byte 0, 'S' or on success 'G' */
    {  /* start writing or overwriting 
        LCD_Position(TOP,0u);
        LCD_PrintString(" EE Write START ");      
        LCD_Position(BOTTOM,0u);
        LCD_PrintString("                ");      
        */
        CyDelay(1000u);  
        if(EEPROM_Init_Write() != 0)    /*  call EEPROM init function and check for success = 0       */
        {   /* 1st Failure. Update display with code and Retry 1 time                                     
            LCD_Position(TOP,0u);
            LCD_PrintString(" EE Write FAIL! ");              
            LCD_Position(BOTTOM,0u);
            LCD_PrintString("#1 Fail Code:   ");
            LCD_Position(BOTTOM,13u); 
            */
            EE_PGM_Status = EEPROM_ReadByte(EE_STATE_BASE_ADDR);
            if(EE_PGM_Status <48 || EE_PGM_Status != 'G')  /* filter out G to prevent false code, convert any non printable chars */                       
            {   
                //LCD_PutChar(EE_PGM_Status+48);   /*  Should be S for started or 0x00 */
            }
            else 
            {   
                //LCD_PutChar(EE_PGM_Status);   /*  Should be S for started or 0x00 */
            }          
            CyDelay(5000u);   /*  give time to see the screen eror  */
            //LCD_Position(BOTTOM,0u);
            //LCD_PrintString(" Retrying 1 time");
            CyDelay(1000u);   
            if(EEPROM_Init_Write() != 0) /* Now try 1 more time  */
            {   /*  Retry failed also   */
                /*LCD_Position(BOTTOM,0u);
                LCD_PrintString("#2 Fail Code:   ");
                LCD_Position(BOTTOM,13u); */
                EE_PGM_Status = EEPROM_ReadByte(EE_STATE_BASE_ADDR);
                if(EE_PGM_Status <48 || EE_PGM_Status != 'G')  /* filter out G to prevent false code, convert any non printable chars */                       
                {   
                    // LCD_PutChar(EE_PGM_Status+48);   /*  Should be S for started or 0x00 */
                }
                else 
                {   
                    // LCD_PutChar(EE_PGM_Status);   /*  Should be S for started or 0x00 */
                }
                CyDelay(10000u);    
                EE_PGM_Failed = YES;    /* Set a flag to not retry until program is reset.  Continue with defaults */
                return 1;
            }
        }
        #ifdef DEBUG_EEPROM
        LCD_Position(TOP,0u);
        LCD_PrintString(" EE Write Done! ");
        LCD_Position(BOTTOM,0u);
        LCD_PrintString(" Success! C:   ");
        LCD_Position(BOTTOM,12u);
        EE_PGM_Status = EEPROM_ReadByte(EE_STATE_BASE_ADDR);               
        LCD_PutChar(EE_PGM_Status);   /*  Should be 'G' */
        CyDelay(3000u);   
        #endif 
        EE_PGM_Failed = NO;
        return 0;
    }
    if(!EEPROM_Init_Read())
        return 0;   /*   Already has good EEPROM config data or has write attempts have failed 2 times before since reset so skip out  */  
    else return 1;  /*  FAIL   */
}
/*******************************************************************************
* Function Name: EEPROM_Init_Write
********************************************************************************
* Summary:
*   Copy into EEPROM space the needed variables and the Band_Cal_Table data structure.  
*   There can be other data in the rest of EEPROM and this will overwrite it.
*   Variables wil be reset to default after an overwrite.  A master reset menu option may be created to do this
*   Called by EEPROM_Init. After writing is complete check Byte 0 == 'G'.
*
* Parameters:
*   None
*
* Return:
*   0 for success, 1 for FAIL
*
*******************************************************************************/
uint8_t EEPROM_Init_Write(void)
{
    uint8       ee_row;
    uint8_t     c1_array[16]; /* stores 1 row of 16 bytes for eeprom write and reads */
    uint16      j;    
    uint8_t     eepromArray[NUM_SETS * (sizeof Band_Cal_Table)];  // 396 bytes
    //uint8_t     eepromArray[(NUM_SETS*20)];  // 200 is the array size calculated by the sizeOf function below
    uint16      Arr_Size;
    uint8       result;
    char        setpoint_buf[SETPOINT_LEN+1];
       
    EEPROM_UpdateTemperature();   
    /*  write 'S' to byte 0 to indicate we started writing bytes but not finished    */
    if(!EEPROM_ByteWritePos('S', 0, 0))
    {
        /*  Start writing all of our data to EEPROM now.  
            Everything is 1 byte in size so can serially copy each into EEPROM with no size or type conversion required
            Have structs and some variables to do at the end.  Lets start with the Band_Cal_Table structure               
            Begin with our state variables  in row 1, starting with the 3rd byte.  0 == corrupt flag, 1 = reserved, 3 is first data. 
            2 rows in at byte 33 (32 0-31) will start writing rows of Array data.  It is at the end to avoid having to recomputer where the saved data is relative to the start of EEPROM.
        */          
        c1_array[0] = 'S';   /* what we just wrote, will overwrite as a block of 16 bytes) */
        c1_array[EE_RESERVED_BYTE1] = _NULL;
        c1_array[OP_MODE_OFFSET] = op_mode;  
        c1_array[COUPLERSETNUM_OFFSET] = CouplerSetNum;
        c1_array[SER_DATA_OUT_OFFSET] = ser_data_out;                     
        // Need to test effect of leading 0s or not
        sprintf(setpoint_buf, "%*.1f", SETPOINT_LEN, set_hv_max);                            // convert float to 4 byte ascii
        memcpy(&c1_array[HV_MAX_OFFSET],setpoint_buf, SETPOINT_LEN);
        sprintf(setpoint_buf, "%*.1f",SETPOINT_LEN, set_v14_max);                           // convert float to 4 byte ascii
        memcpy(&c1_array[V14_MAX_OFFSET],setpoint_buf, SETPOINT_LEN);                                                       
        c1_array[TEMP_MAX_OFFSET] = set_temp_max;                              // byte 13 of 0-15
        c1_array[METERID_OFFSET] = METERID;                                     // byte 14 of 15
        c1_array[SPARE0_OFFSET] = '\0';                                        // byte 15 of 15  

        // copy row 0 to EEPROM now     
        ee_row = 0;
        Copy_to_EE(ee_row,c1_array,NO);     /* copy 1 row at a time to EEPROM */               
        
        /*  Now for row 2   */
        memcpy(c1_array,Callsign, CALLSIGN_LEN);   /*  7 bytes */      
        // append any other strings like this example:
        //memcpy(&c1_array[CALLSIGN_LEN],Grid_Square, GRIDSQUARE_LEN); /* 9 bytes */
        
        sprintf(setpoint_buf, "%02.1f", set_curr_max);                           // convert float to 4 byte ascii
        memcpy(&c1_array[CURR_MAX_OFFSET-0x0010],setpoint_buf, SETPOINT_LEN);
                                 
        // bytes 11-15 of 0-15  are spare
        
        // Now copy row 1 to EEPROM
        ee_row = 1;
        Copy_to_EE(ee_row,c1_array,NO);     /* copy 1 row at a time to EEPROM */
        
        // Now copy the cal table structure to EEPROM
        Arr_Size = (sizeof Band_Cal_Table);
        memcpy(eepromArray,Band_Cal_Table,Arr_Size);       /*  copy ARR_SIZE bytes back into the Band_Cal_Table structure (if it is not padded)  */                                 
      
        /*   start at 3rd row 1st byte (row 2) 0x0020)   */
        for(j=0; j<(Arr_Size); j++)  /* if we have t bands then we have 14 rows of EEPROM to read - or BANDS = 7 *32bytes, start at byte address  0x0010  */
        {              
            result = EEPROM_WriteByte(eepromArray[j], CAL_TBL_ARR_OFFSET+j);      /*  start at byte 16 and get ARR_SIZE bytes for whole structure */          
            if (result == CYRET_SUCCESS)
                printf("saved byte, result = %d", result);
            else
                printf("failed to save byte, result = %d", result);
        }            
       
        /*If all went OK set first byte to 'G' and return */
        if(EEPROM_ByteWritePos('G', 0, 0) == 0)
        {
            return 0;   // all good, exit
        }
        else
        {
        /*  return fail (1) and leave the S in place */
            return 1;  /* write to EEPROM completed OK but the writing the marker byte failed  */      
        }        
    }
    else
    {
        return 1;   /* failed to write the 'S' so abandon */
    }
}

/*******************************************************************************
* Function Name: Copy_to_EE
********************************************************************************
* Summary:
*   Takes data in an array of 16 bytes and writes it to the row requested by calling functions
*   EEPROM starts at 16 bit zero for these API functions.  We are reserving row 1 for flags to protect overwrite at startup.
    Writing in rows for now.  Callers have to gather up their data into a 16 byte array and pass that in along with the row.

* Parameters:
*   e_row  index to EEPROM row
*
* Return:
*   0 for success, 1 for FAIL
*
*******************************************************************************/
uint8_t Copy_to_EE(uint8 e_row, uint8_t c_array[16], uint8 print)
{
    uint16      j;
    uint8_t     eepromArray[16];   /* copy of data from eeprom to compare with source for validation.  */
    
    /*  Use e_row to specify the data row */
    
    /*  print the result for validation */
    if(print)
    {
        //LCD_Display_Clear();
        
        //sniprintf(LCD_Display_Row1, 17, "%s     ","DataWrite Row:  ");
        //LCD_Display_Update(TOP);
        //LCD_Position(TOP,15u);
        //LCD_PutChar(e_row+64);
        //  
        //sniprintf(LCD_Display_Row2, 17, "%s     ", c_array);
       // LCD_Display_Update(BOTTOM);       
        CyDelay(300);
    }
    if(!EEPROM_Write(c_array,e_row))
    {                      
        if(print)
        {        
            //LCD_Position(BOTTOM,14u);
            //LCD_PrintString("OK");
            CyDelay(300u);  
        }
    }
    else
    {
        if(print)
        {
            /*   error visits here.  */
            //LCD_Position(BOTTOM,9u);
            //LCD_PrintString(" FAIL! ");
            CyDelay(2000u);  
        }
        return 1;
    };            

    /*  Clear bottom status line for next event */
    if(print)
    {
        //LCD_Display_Clear();
        CyDelay(100);    

        /*sniprintf(LCD_Display_Row1, 17, "%s     ","DataWrite Row:  ");
        LCD_Display_Update(TOP);
        LCD_Position(TOP,15u);
        LCD_PutChar(e_row+64);
        LCD_Position(TOP,15u);
        LCD_PutChar(e_row+64); */
    }
    /*  now read it back from EEPROM  and compare to the data written */
    for(j=0; j<16; j++)
    {              
        eepromArray[j] = EEPROM_ReadByte(j+(e_row*16));               
    }
    if(memcmp(eepromArray,c_array,16))
    {
        if(print)
        {
            //LCD_Position(BOTTOM,9u);
            //LCD_PrintString(" FAIL! ");
            CyDelay(2000u);    
        }
        return 1;  
    }
    else    /* verified!  */
    {
        if(print)
        {            
            /* sniprintf(LCD_Display_Row2, 17, "%-9.9s     ", eepromArray);
            LCD_Display_Update(BOTTOM);
            CyDelay(400);
            LCD_Position(BOTTOM,14u);
            LCD_PrintString("OK");  */
            CyDelay(300u);            
        }
    }
        if(print)
        {
            //LCD_Display_Clear();
            CyDelay(800);
        }
    /*  Now read from EEPROM using CYDEV_EE_BASE for absolute address to start of EEPROM
    CYDEV_EEPROM_ROW_SIZE for row size
    CY_DEV_EE_SIZE for size of EEPROM memory space
    
    Look into how EEPROM is mirror for regular read only access and how to map the structure over it.
    Else read it byte at a time or copy the whole thing to a temp structure and proceed normally.  Writes still have to be some byte by byte.
    
    */
    return 0;
}

/*******************************************************************************
* Function Name: EEPROM_Init_Read
********************************************************************************
* Summary:
*   Transfers the master copy of config settings in EEPROM and copies it intop Band_Cal_Table array structure.
*   EEPROM starts at 16 bit zero for these API functions.  We are reserving row1 for flags to protect overwrite at startup.
*
* Parameters:
*   e_row  index to EEPROM row
*
* Return:
*   0 for success, 1 for FAIL
*
*******************************************************************************/
uint8_t EEPROM_Init_Read(void)
{
    uint16      j;  
    uint8_t     eepromArray[sizeof Band_Cal_Table];
    uint16      Arr_Size;
    char        setpoint_buf[SETPOINT_LEN+1];
    
    EE_PGM_Status = EEPROM_ReadByte(EE_STATE_BASE_ADDR);    
    if(EE_PGM_Status != 'G')   /*   EEPROM_Init will set byte 0, 'S' or on success 'G' */
        return 1;
    else
    {
        /* start reading all of our data to EEPROM now.  
            Everything is 1 byte in size so can serially copy each into EEPROM with no size or type conversion required
        */ 
        /* Get 2 rows of 16 bytes as we did to write this originally */
        for(j=0; j<32; j++)
        {              
            eepromArray[j] = EEPROM_ReadByte(j+EE_STATE_BASE_ADDR);             //  address relative to 0x0000
        }  
        // Now extract into each variable
                                                                                // byte 1 of 0-15 is reserved guard space
        op_mode = eepromArray[OP_MODE_OFFSET];                                  // byte 2 of 0-15
        CouplerSetNum = eepromArray[COUPLERSETNUM_OFFSET];                      // byte 3
        ser_data_out = eepromArray[SER_DATA_OUT_OFFSET];                        // byte 4
        memcpy(setpoint_buf,&eepromArray[HV_MAX_OFFSET],SETPOINT_LEN);          // byte 5-8  
        setpoint_buf[SETPOINT_LEN] = '\0';                                      // null terminate string
        set_hv_max = atof(setpoint_buf);                                        // convert ascii to float
        memcpy(setpoint_buf,&eepromArray[V14_MAX_OFFSET],SETPOINT_LEN);         // byte 9-12       
        setpoint_buf[SETPOINT_LEN] = '\0';
        set_v14_max = atof(setpoint_buf);                                       // convert ascii to float              
        set_temp_max = eepromArray[TEMP_MAX_OFFSET];                            // byte 13 of 0-15
        METERID = eepromArray[METERID_OFFSET];                                  // byte 14 of 15
        //xxx = eepromArray[SPARE0_OFFSET];                                     // byte 15 of 15  

        // start row 1
        memcpy(Callsign,&eepromArray[CALLSIGN_OFFSET],CALLSIGN_LEN);            // byte 0-6 -  first 7 bytes of row 1
        memcpy(setpoint_buf,&eepromArray[CURR_MAX_OFFSET],SETPOINT_LEN);        // byte 7-10 of 0-15
        setpoint_buf[SETPOINT_LEN] = '\0';                                      // null terminaite string
        set_curr_max = atof(setpoint_buf);                                      // convert ascii to float 
        //xxx = eepromArray[SPARE1_OFFSET];                                     // byte 11 of 0-15  
        //xxx = eepromArray[SPARE2_OFFSET];                                     // byte 12 of 0-15  
        //xxx = eepromArray[SPARE3_OFFSET];                                     // byte 13 of 0-15                  
        //xxx = eepromArray[SPARE4_OFFSET];                                     // byte 14 of 0-15                  
        //xxx = eepromArray[SPARE5_OFFSET];                                     // byte 15 of 0-15                                 
        /*  Using Arr_Size since it (likely) accurately returns the byte size of the CfgTblArr structure */          
        Arr_Size = (sizeof Band_Cal_Table);
        /*   start at 3rd row 1st byte (row 2) 0x0020)   */
        for(j=0; j<(Arr_Size); j++)  /* if we have t bands then we have 14 rows of EEPROM to read - or BANDS = 7 *32bytes, start at byte address  0x0010  */
        {              
            eepromArray[j] = EEPROM_ReadByte(CAL_TBL_ARR_OFFSET+j);      /*  start at byte 16 and get ARR_SIZE bytes for whole structure */          
        } 
        memcpy(Band_Cal_Table,eepromArray,Arr_Size);       /*  copy ARR_SIZE bytes back into the Band_Cal_Table structure (if it is not padded)  */                                 
        return 1;
    }
    return 0;   /*  Now have restored user state fully.  Be sure to write updates as they happen */
}

/*******************************************************************************
* Function Name: EE_Save_State
********************************************************************************
* Summary:
*   Saves the state variables required to restore last known state after a power off.
*   Saving all state in one function call since there are only a few and time is not critical for us 
*
* Parameters:
*   None
*
* Return:
*   0 = Success
*   1 = FAIL
*
*******************************************************************************/    
uint8_t EE_Save_State(void) 
{    
    /* save state to EEPROM   */
    /* Use these to save the state of these state variables when ever you change them*/ 
    
    /* These are stored in the first and 2nd rows.  Skipping the first byte though */
    //EEPROM_WriteByte(op_mode, EE_STATE_BASE_ADDR+OP_MODE_OFFSET);                
    //EEPROM_WriteByte(CouplerSetNum, EE_STATE_BASE_ADDR+COUPLERSETNUM_OFFSET); 
    //(ser_data_out, EE_STATE_BASE_ADDR+SER_DATA_OUT_OFFSET); 
    
    /* 2nd row variables */
    //for(i=0;i<CALLSIGN_LEN;++i)  /*  offset 16 bytes */
    // {   EEPROM_WriteByte(Callsign[i],EE_STATE_BASE_ADDR+CALLSIGN_OFFSET+i);   /* first 7 bytes of row */
    //}    
    //for(i=0;i<GRIDSQUARE_LEN;++i)  /*  next 9 bytes to finish the 16 byte row */
    //{
    //    EEPROM_WriteByte(Grid_Square[i],EE_STATE_BASE_ADDR+GRIDSQUARE_OFFSET+i); /*  last 9 bytes of block */ 
    //}      
    EEPROM_Init_Write();    // save to eeprom
    EEPROM_Init_Read();     // load the values into memory
    Cal_Table();
    
    return 0;
}

/*******************************************************************************
* Define Interrupt service routine and allocate an vector to the Interrupt
********************************************************************************/
CY_ISR(Timer_X00ms_InterruptHandler)
{
	/* Read Status register in order to clear the sticky Terminal Count (TC) bit 
	 * in the status register. Note that the function is not called, but rather 
	 * the status is read directly.
	 */
   	Timer_X00ms_STATUS;
    
	/* Increment the Counter to indicate the keep track of the number of 
     * interrupts received */
    Timer_X00ms_InterruptCnt++;    
    if(Timer_X00ms_InterruptCnt > 65000) 
        Timer_X00ms_InterruptCnt = 0;  /* roll it over */

}

/* [] END OF FILE */
