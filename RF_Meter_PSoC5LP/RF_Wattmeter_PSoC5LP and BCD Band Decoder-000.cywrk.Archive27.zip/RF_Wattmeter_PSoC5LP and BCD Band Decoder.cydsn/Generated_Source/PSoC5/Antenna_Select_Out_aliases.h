/*******************************************************************************
* File Name: Antenna_Select_Out.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Antenna_Select_Out_ALIASES_H) /* Pins Antenna_Select_Out_ALIASES_H */
#define CY_PINS_Antenna_Select_Out_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define Antenna_Select_Out_0			(Antenna_Select_Out__0__PC)
#define Antenna_Select_Out_0_INTR	((uint16)((uint16)0x0001u << Antenna_Select_Out__0__SHIFT))

#define Antenna_Select_Out_1			(Antenna_Select_Out__1__PC)
#define Antenna_Select_Out_1_INTR	((uint16)((uint16)0x0001u << Antenna_Select_Out__1__SHIFT))

#define Antenna_Select_Out_INTR_ALL	 ((uint16)(Antenna_Select_Out_0_INTR| Antenna_Select_Out_1_INTR))

#endif /* End Pins Antenna_Select_Out_ALIASES_H */


/* [] END OF FILE */
