/*******************************************************************************
* File Name: Aux2Out.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Aux2Out_ALIASES_H) /* Pins Aux2Out_ALIASES_H */
#define CY_PINS_Aux2Out_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define Aux2Out_0			(Aux2Out__0__PC)
#define Aux2Out_0_INTR	((uint16)((uint16)0x0001u << Aux2Out__0__SHIFT))

#define Aux2Out_1			(Aux2Out__1__PC)
#define Aux2Out_1_INTR	((uint16)((uint16)0x0001u << Aux2Out__1__SHIFT))

#define Aux2Out_2			(Aux2Out__2__PC)
#define Aux2Out_2_INTR	((uint16)((uint16)0x0001u << Aux2Out__2__SHIFT))

#define Aux2Out_3			(Aux2Out__3__PC)
#define Aux2Out_3_INTR	((uint16)((uint16)0x0001u << Aux2Out__3__SHIFT))

#define Aux2Out_INTR_ALL	 ((uint16)(Aux2Out_0_INTR| Aux2Out_1_INTR| Aux2Out_2_INTR| Aux2Out_3_INTR))

#endif /* End Pins Aux2Out_ALIASES_H */


/* [] END OF FILE */
