#include <project.h>
#include "Serial.h"
#include "Utilities.h"
#include <stdio.h>

//#define LORA
#define RxBUFFLEN 64
unsigned char rxBuff[RxBUFFLEN];
volatile uint8_t rxHead, rxTail;
extern char8 cmd[RxBUFFLEN];
extern uint8 WAIT;  // traffic flag - if a function is waiting for a response for the display set this flag to hold off display updates

void Serial_Init()
{
    rxHead = 0;
    rxTail = 0;
#ifdef LORA
    LoRaCfg();
#endif
}

unsigned char Serial_Write(unsigned char c)
{
#ifdef LORA    
    LoRaAuxReady();   // pin connected to CTS of UART1 now through an inverter.  Should not need this function for write.
#endif
    //while (WAIT)
      //  CyDelay(1);
    UART1_PutChar(c);  // PSoC API
    return 1;
}

unsigned char Serial_Read()
{
    unsigned char c;   
    
    if (rxTail < rxHead)
    {        
        c = rxBuff[rxTail++];   // extract next char not read yet by functions
        if (rxTail == rxHead)   // if we are caught up, reset buffer
        {
            rxHead = 0;
            rxTail = 0;
        }
    }
    else
    {
        rxHead = 0;     // reset buffer if empy or tail > head for some reason
        rxTail = 0;
        c = -1;         // -1 indicates something wrong, ignore C value
    }
    return c;
}

unsigned char Serial_Available()
{   
    //  Shift to Interrupt routine to fill buffer    
    unsigned char c; 
      
    while ((UART1_GetRxBufferSize()) != 0)
    {       
        c = UART1_ReadRxData();
        rxBuff[rxHead++] = c;  // fill buffer with next char
        if (rxHead > RxBUFFLEN-1)  // prevent overrun
            rxHead = RxBUFFLEN;
        if (rxTail > RxBUFFLEN-1)
            rxTail = RxBUFFLEN;
    } 
    return rxHead - rxTail;
}

unsigned char Serial_ReadBytes(char *buf, unsigned char len)
{
    unsigned char cnt = 0;
    
    Serial_Available();
    if (len < rxHead - rxTail)
    {
        //ArrayCopy(buf, &rxBuff[rxTail], len);
        ClearArray(buf);
        memcpy(buf, &rxBuff[rxTail], len);
        rxTail += len;
        cnt = len;
    }
    else if (len == rxHead - rxTail)
    {
        //ArrayCopy(buf, &rxBuff[rxTail], len);
        ClearArray(buf);
        memcpy(buf, &rxBuff[rxTail], len);
        rxTail = 0;
        rxHead = 0;
        cnt = len;
    }
    else
    {
        //ArrayCopy(buf, &rxBuff[rxTail], rxHead - rxTail);
        ClearArray(buf);
        cnt = rxHead - rxTail;
        if (cnt > strlen(buf)) // On initial power up (not resets) the memecpy was copyung more bytes then the buffer.
            cnt = strlen(buf);  // this appears to prevent that and make for reliable startup
        if (cnt !=0 && rxTail !=0)
            memcpy(buf, &rxBuff[rxTail], cnt);                
        rxTail = 0;
        rxHead = 0;
    }
    return cnt;
}

void Serial_Print(char *scmd )
{
    // using global cmd_data as passing string is not working for some reason, only getting first char of strings.
#ifdef LORA    
    LoRaAuxReady();
#endif
    //while (WAIT)
      //  CyDelay(1);
    UART1_PutString(cmd);
}

#ifdef LORA
uint8 LoRaAuxReady(void)
{
    #define LOW 0
    #define HIGH 1
    #define TIME_OUT_CNT 100
    uint8_t cnt = 0;
    // uint8_t data_buf[100], data_len;

    while(LoRa_Aux_Read()==LOW && (cnt++<TIME_OUT_CNT)) {
        //Serial.print(".");
        CyDelay(2);
    }

    if(cnt==0) 
    {
    } 
    else if(cnt>=TIME_OUT_CNT) 
    {
        //STATUS = RET_TIMEOUT;
        CyDelay(10);
        //Serial.println(" TimeOut");
    } 
    else 
    {
        //Serial.println("");
        CyDelay(2);
    }
    return 1;
}
    
void LoRaCfg(void)
{
    uint8_t Readcnt, idx, buf_len;
    buf_len=6;
    uint8_t Readbuf[10];
    
    // When configuring, uses 9600baud.  Need to figure out how to change UART speed programatically
    //LoRaAuxReady();
    LoRaControl_Write(0x03);   // program mode = 3
    CyDelay(5);
    //UART1_ClearRxBuffer();
    LoRaAuxReady();
    UART1_PutChar(0xC3);   // C1 3x is module info
    UART1_PutChar(0xC3);
    UART1_PutChar(0xC3); 
    CyDelay(4);
    Readcnt = UART1_GetRxBufferSize();
    if (Readcnt == 4) {
        for(idx=0;idx<4;idx++) 
        {
            Readbuf[idx] = UART1_GetChar();
            if (Readbuf[idx] == 0)
                    CyDelay(1); // This is just to suppress compiler unused var warning, may use later
        }
    }
    else
        UART1_ClearRxBuffer();  // Size not match
        
    // default is C0 00 00 1A 17 44
    //LoRaAuxReady();
    LoRaAuxReady();
    UART1_PutChar(0xC0);    // write 6 cfg bytes an save to NVRAM.  USe C2 to not save.
    UART1_PutChar(0x00);   // Address
    UART1_PutChar(0x00);   // Address
    UART1_PutChar(0x1D);   // 25 is 19200 wire and 19200 air speed
                           // 1D is 9600 wire and 19200 air
                           // 1C is 9600 wire 9600 air
                           // 1A is 9600 wire and 2400 air
                           // 24 is 19200 wire and 9600 air
    UART1_PutChar(0x0F);   // 0F is 915MHz. 00-1F is 90 to 931MHz range. Top 3 bits reseved. This is the Channel
    UART1_PutChar(0x46);   // 44 is transparent mode with TX and RX pullups, 250ms wakeup, FEC on.  Bottom 2 bits is power level.  4+0 = 20Bm, 4+2 = 14dBm for 46 total    
    CyDelay(50);
    
    LoRaAuxReady();
    UART1_PutChar(0xC4);   // C4 3x is modulke reset
    UART1_PutChar(0xC4);
    UART1_PutChar(0xC4); 
    CyDelay(1200);
    
    LoRaAuxReady();
    //UART1_ClearRxBuffer();
    UART1_PutChar(0xC3);   // C1 3x is save parms 
    UART1_PutChar(0xC3);
    UART1_PutChar(0xC3); 
    CyDelay(40);
    Readcnt = UART1_GetRxBufferSize();
    if (Readcnt == buf_len) 
    {
        for(idx=0;idx<buf_len;idx++) 
        {
        Readbuf[idx] = UART1_GetChar();
        }
    }
    
    LoRaAuxReady();
    LoRaControl_Write(0x00);   // Operational Mode = 0
    LoRaAuxReady();
    CyDelay(10);
}
#endif
