/*******************************************************************************
* File Name: Nextion_Switch.h  
* Version 1.80
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CONTROL_REG_Nextion_Switch_H) /* CY_CONTROL_REG_Nextion_Switch_H */
#define CY_CONTROL_REG_Nextion_Switch_H

#include "cyfitter.h"

#if ((CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC3) || \
     (CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC4) || \
     (CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC5))
    #include "cytypes.h"
#else
    #include "syslib/cy_syslib.h"
#endif

    
/***************************************
*     Data Struct Definitions
***************************************/

/* Sleep Mode API Support */
typedef struct
{
    uint8 controlState;

} Nextion_Switch_BACKUP_STRUCT;


/***************************************
*         Function Prototypes 
***************************************/

void    Nextion_Switch_Write(uint8 control) ;
uint8   Nextion_Switch_Read(void) ;

void Nextion_Switch_SaveConfig(void) ;
void Nextion_Switch_RestoreConfig(void) ;
void Nextion_Switch_Sleep(void) ; 
void Nextion_Switch_Wakeup(void) ;


/***************************************
*            Registers        
***************************************/

/* Control Register */
#define Nextion_Switch_Control        (* (reg8 *) Nextion_Switch_Sync_ctrl_reg__CONTROL_REG )
#define Nextion_Switch_Control_PTR    (  (reg8 *) Nextion_Switch_Sync_ctrl_reg__CONTROL_REG )

#endif /* End CY_CONTROL_REG_Nextion_Switch_H */


/* [] END OF FILE */
