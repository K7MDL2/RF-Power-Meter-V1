/*******************************************************************************
* File Name: Aux1Out.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Aux1Out_ALIASES_H) /* Pins Aux1Out_ALIASES_H */
#define CY_PINS_Aux1Out_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define Aux1Out_0			(Aux1Out__0__PC)
#define Aux1Out_0_INTR	((uint16)((uint16)0x0001u << Aux1Out__0__SHIFT))

#define Aux1Out_1			(Aux1Out__1__PC)
#define Aux1Out_1_INTR	((uint16)((uint16)0x0001u << Aux1Out__1__SHIFT))

#define Aux1Out_2			(Aux1Out__2__PC)
#define Aux1Out_2_INTR	((uint16)((uint16)0x0001u << Aux1Out__2__SHIFT))

#define Aux1Out_3			(Aux1Out__3__PC)
#define Aux1Out_3_INTR	((uint16)((uint16)0x0001u << Aux1Out__3__SHIFT))

#define Aux1Out_INTR_ALL	 ((uint16)(Aux1Out_0_INTR| Aux1Out_1_INTR| Aux1Out_2_INTR| Aux1Out_3_INTR))

#endif /* End Pins Aux1Out_ALIASES_H */


/* [] END OF FILE */
