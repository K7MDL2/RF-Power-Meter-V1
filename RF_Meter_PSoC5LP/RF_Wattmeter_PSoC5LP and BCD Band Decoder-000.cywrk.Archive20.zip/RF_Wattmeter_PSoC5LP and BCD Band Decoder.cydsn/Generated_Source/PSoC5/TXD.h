/*******************************************************************************
* File Name: TXD.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_TXD_H) /* Pins TXD_H */
#define CY_PINS_TXD_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "TXD_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 TXD__PORT == 15 && ((TXD__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    TXD_Write(uint8 value);
void    TXD_SetDriveMode(uint8 mode);
uint8   TXD_ReadDataReg(void);
uint8   TXD_Read(void);
void    TXD_SetInterruptMode(uint16 position, uint16 mode);
uint8   TXD_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the TXD_SetDriveMode() function.
     *  @{
     */
        #define TXD_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define TXD_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define TXD_DM_RES_UP          PIN_DM_RES_UP
        #define TXD_DM_RES_DWN         PIN_DM_RES_DWN
        #define TXD_DM_OD_LO           PIN_DM_OD_LO
        #define TXD_DM_OD_HI           PIN_DM_OD_HI
        #define TXD_DM_STRONG          PIN_DM_STRONG
        #define TXD_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define TXD_MASK               TXD__MASK
#define TXD_SHIFT              TXD__SHIFT
#define TXD_WIDTH              1u

/* Interrupt constants */
#if defined(TXD__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in TXD_SetInterruptMode() function.
     *  @{
     */
        #define TXD_INTR_NONE      (uint16)(0x0000u)
        #define TXD_INTR_RISING    (uint16)(0x0001u)
        #define TXD_INTR_FALLING   (uint16)(0x0002u)
        #define TXD_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define TXD_INTR_MASK      (0x01u) 
#endif /* (TXD__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define TXD_PS                     (* (reg8 *) TXD__PS)
/* Data Register */
#define TXD_DR                     (* (reg8 *) TXD__DR)
/* Port Number */
#define TXD_PRT_NUM                (* (reg8 *) TXD__PRT) 
/* Connect to Analog Globals */                                                  
#define TXD_AG                     (* (reg8 *) TXD__AG)                       
/* Analog MUX bux enable */
#define TXD_AMUX                   (* (reg8 *) TXD__AMUX) 
/* Bidirectional Enable */                                                        
#define TXD_BIE                    (* (reg8 *) TXD__BIE)
/* Bit-mask for Aliased Register Access */
#define TXD_BIT_MASK               (* (reg8 *) TXD__BIT_MASK)
/* Bypass Enable */
#define TXD_BYP                    (* (reg8 *) TXD__BYP)
/* Port wide control signals */                                                   
#define TXD_CTL                    (* (reg8 *) TXD__CTL)
/* Drive Modes */
#define TXD_DM0                    (* (reg8 *) TXD__DM0) 
#define TXD_DM1                    (* (reg8 *) TXD__DM1)
#define TXD_DM2                    (* (reg8 *) TXD__DM2) 
/* Input Buffer Disable Override */
#define TXD_INP_DIS                (* (reg8 *) TXD__INP_DIS)
/* LCD Common or Segment Drive */
#define TXD_LCD_COM_SEG            (* (reg8 *) TXD__LCD_COM_SEG)
/* Enable Segment LCD */
#define TXD_LCD_EN                 (* (reg8 *) TXD__LCD_EN)
/* Slew Rate Control */
#define TXD_SLW                    (* (reg8 *) TXD__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define TXD_PRTDSI__CAPS_SEL       (* (reg8 *) TXD__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define TXD_PRTDSI__DBL_SYNC_IN    (* (reg8 *) TXD__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define TXD_PRTDSI__OE_SEL0        (* (reg8 *) TXD__PRTDSI__OE_SEL0) 
#define TXD_PRTDSI__OE_SEL1        (* (reg8 *) TXD__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define TXD_PRTDSI__OUT_SEL0       (* (reg8 *) TXD__PRTDSI__OUT_SEL0) 
#define TXD_PRTDSI__OUT_SEL1       (* (reg8 *) TXD__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define TXD_PRTDSI__SYNC_OUT       (* (reg8 *) TXD__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(TXD__SIO_CFG)
    #define TXD_SIO_HYST_EN        (* (reg8 *) TXD__SIO_HYST_EN)
    #define TXD_SIO_REG_HIFREQ     (* (reg8 *) TXD__SIO_REG_HIFREQ)
    #define TXD_SIO_CFG            (* (reg8 *) TXD__SIO_CFG)
    #define TXD_SIO_DIFF           (* (reg8 *) TXD__SIO_DIFF)
#endif /* (TXD__SIO_CFG) */

/* Interrupt Registers */
#if defined(TXD__INTSTAT)
    #define TXD_INTSTAT            (* (reg8 *) TXD__INTSTAT)
    #define TXD_SNAP               (* (reg8 *) TXD__SNAP)
    
	#define TXD_0_INTTYPE_REG 		(* (reg8 *) TXD__0__INTTYPE)
#endif /* (TXD__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_TXD_H */


/* [] END OF FILE */
