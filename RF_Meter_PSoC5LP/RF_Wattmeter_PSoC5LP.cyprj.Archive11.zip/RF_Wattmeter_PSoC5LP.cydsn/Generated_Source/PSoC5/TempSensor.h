/*******************************************************************************
* File Name: TempSensor.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_TempSensor_H) /* Pins TempSensor_H */
#define CY_PINS_TempSensor_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "TempSensor_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 TempSensor__PORT == 15 && ((TempSensor__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    TempSensor_Write(uint8 value);
void    TempSensor_SetDriveMode(uint8 mode);
uint8   TempSensor_ReadDataReg(void);
uint8   TempSensor_Read(void);
void    TempSensor_SetInterruptMode(uint16 position, uint16 mode);
uint8   TempSensor_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the TempSensor_SetDriveMode() function.
     *  @{
     */
        #define TempSensor_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define TempSensor_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define TempSensor_DM_RES_UP          PIN_DM_RES_UP
        #define TempSensor_DM_RES_DWN         PIN_DM_RES_DWN
        #define TempSensor_DM_OD_LO           PIN_DM_OD_LO
        #define TempSensor_DM_OD_HI           PIN_DM_OD_HI
        #define TempSensor_DM_STRONG          PIN_DM_STRONG
        #define TempSensor_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define TempSensor_MASK               TempSensor__MASK
#define TempSensor_SHIFT              TempSensor__SHIFT
#define TempSensor_WIDTH              1u

/* Interrupt constants */
#if defined(TempSensor__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in TempSensor_SetInterruptMode() function.
     *  @{
     */
        #define TempSensor_INTR_NONE      (uint16)(0x0000u)
        #define TempSensor_INTR_RISING    (uint16)(0x0001u)
        #define TempSensor_INTR_FALLING   (uint16)(0x0002u)
        #define TempSensor_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define TempSensor_INTR_MASK      (0x01u) 
#endif /* (TempSensor__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define TempSensor_PS                     (* (reg8 *) TempSensor__PS)
/* Data Register */
#define TempSensor_DR                     (* (reg8 *) TempSensor__DR)
/* Port Number */
#define TempSensor_PRT_NUM                (* (reg8 *) TempSensor__PRT) 
/* Connect to Analog Globals */                                                  
#define TempSensor_AG                     (* (reg8 *) TempSensor__AG)                       
/* Analog MUX bux enable */
#define TempSensor_AMUX                   (* (reg8 *) TempSensor__AMUX) 
/* Bidirectional Enable */                                                        
#define TempSensor_BIE                    (* (reg8 *) TempSensor__BIE)
/* Bit-mask for Aliased Register Access */
#define TempSensor_BIT_MASK               (* (reg8 *) TempSensor__BIT_MASK)
/* Bypass Enable */
#define TempSensor_BYP                    (* (reg8 *) TempSensor__BYP)
/* Port wide control signals */                                                   
#define TempSensor_CTL                    (* (reg8 *) TempSensor__CTL)
/* Drive Modes */
#define TempSensor_DM0                    (* (reg8 *) TempSensor__DM0) 
#define TempSensor_DM1                    (* (reg8 *) TempSensor__DM1)
#define TempSensor_DM2                    (* (reg8 *) TempSensor__DM2) 
/* Input Buffer Disable Override */
#define TempSensor_INP_DIS                (* (reg8 *) TempSensor__INP_DIS)
/* LCD Common or Segment Drive */
#define TempSensor_LCD_COM_SEG            (* (reg8 *) TempSensor__LCD_COM_SEG)
/* Enable Segment LCD */
#define TempSensor_LCD_EN                 (* (reg8 *) TempSensor__LCD_EN)
/* Slew Rate Control */
#define TempSensor_SLW                    (* (reg8 *) TempSensor__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define TempSensor_PRTDSI__CAPS_SEL       (* (reg8 *) TempSensor__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define TempSensor_PRTDSI__DBL_SYNC_IN    (* (reg8 *) TempSensor__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define TempSensor_PRTDSI__OE_SEL0        (* (reg8 *) TempSensor__PRTDSI__OE_SEL0) 
#define TempSensor_PRTDSI__OE_SEL1        (* (reg8 *) TempSensor__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define TempSensor_PRTDSI__OUT_SEL0       (* (reg8 *) TempSensor__PRTDSI__OUT_SEL0) 
#define TempSensor_PRTDSI__OUT_SEL1       (* (reg8 *) TempSensor__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define TempSensor_PRTDSI__SYNC_OUT       (* (reg8 *) TempSensor__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(TempSensor__SIO_CFG)
    #define TempSensor_SIO_HYST_EN        (* (reg8 *) TempSensor__SIO_HYST_EN)
    #define TempSensor_SIO_REG_HIFREQ     (* (reg8 *) TempSensor__SIO_REG_HIFREQ)
    #define TempSensor_SIO_CFG            (* (reg8 *) TempSensor__SIO_CFG)
    #define TempSensor_SIO_DIFF           (* (reg8 *) TempSensor__SIO_DIFF)
#endif /* (TempSensor__SIO_CFG) */

/* Interrupt Registers */
#if defined(TempSensor__INTSTAT)
    #define TempSensor_INTSTAT            (* (reg8 *) TempSensor__INTSTAT)
    #define TempSensor_SNAP               (* (reg8 *) TempSensor__SNAP)
    
	#define TempSensor_0_INTTYPE_REG 		(* (reg8 *) TempSensor__0__INTTYPE)
#endif /* (TempSensor__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_TempSensor_H */


/* [] END OF FILE */
