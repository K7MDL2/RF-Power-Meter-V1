/*******************************************************************************
* File Name: Nex_TXD.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Nex_TXD_H) /* Pins Nex_TXD_H */
#define CY_PINS_Nex_TXD_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Nex_TXD_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Nex_TXD__PORT == 15 && ((Nex_TXD__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Nex_TXD_Write(uint8 value);
void    Nex_TXD_SetDriveMode(uint8 mode);
uint8   Nex_TXD_ReadDataReg(void);
uint8   Nex_TXD_Read(void);
void    Nex_TXD_SetInterruptMode(uint16 position, uint16 mode);
uint8   Nex_TXD_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Nex_TXD_SetDriveMode() function.
     *  @{
     */
        #define Nex_TXD_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Nex_TXD_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Nex_TXD_DM_RES_UP          PIN_DM_RES_UP
        #define Nex_TXD_DM_RES_DWN         PIN_DM_RES_DWN
        #define Nex_TXD_DM_OD_LO           PIN_DM_OD_LO
        #define Nex_TXD_DM_OD_HI           PIN_DM_OD_HI
        #define Nex_TXD_DM_STRONG          PIN_DM_STRONG
        #define Nex_TXD_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Nex_TXD_MASK               Nex_TXD__MASK
#define Nex_TXD_SHIFT              Nex_TXD__SHIFT
#define Nex_TXD_WIDTH              1u

/* Interrupt constants */
#if defined(Nex_TXD__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Nex_TXD_SetInterruptMode() function.
     *  @{
     */
        #define Nex_TXD_INTR_NONE      (uint16)(0x0000u)
        #define Nex_TXD_INTR_RISING    (uint16)(0x0001u)
        #define Nex_TXD_INTR_FALLING   (uint16)(0x0002u)
        #define Nex_TXD_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Nex_TXD_INTR_MASK      (0x01u) 
#endif /* (Nex_TXD__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Nex_TXD_PS                     (* (reg8 *) Nex_TXD__PS)
/* Data Register */
#define Nex_TXD_DR                     (* (reg8 *) Nex_TXD__DR)
/* Port Number */
#define Nex_TXD_PRT_NUM                (* (reg8 *) Nex_TXD__PRT) 
/* Connect to Analog Globals */                                                  
#define Nex_TXD_AG                     (* (reg8 *) Nex_TXD__AG)                       
/* Analog MUX bux enable */
#define Nex_TXD_AMUX                   (* (reg8 *) Nex_TXD__AMUX) 
/* Bidirectional Enable */                                                        
#define Nex_TXD_BIE                    (* (reg8 *) Nex_TXD__BIE)
/* Bit-mask for Aliased Register Access */
#define Nex_TXD_BIT_MASK               (* (reg8 *) Nex_TXD__BIT_MASK)
/* Bypass Enable */
#define Nex_TXD_BYP                    (* (reg8 *) Nex_TXD__BYP)
/* Port wide control signals */                                                   
#define Nex_TXD_CTL                    (* (reg8 *) Nex_TXD__CTL)
/* Drive Modes */
#define Nex_TXD_DM0                    (* (reg8 *) Nex_TXD__DM0) 
#define Nex_TXD_DM1                    (* (reg8 *) Nex_TXD__DM1)
#define Nex_TXD_DM2                    (* (reg8 *) Nex_TXD__DM2) 
/* Input Buffer Disable Override */
#define Nex_TXD_INP_DIS                (* (reg8 *) Nex_TXD__INP_DIS)
/* LCD Common or Segment Drive */
#define Nex_TXD_LCD_COM_SEG            (* (reg8 *) Nex_TXD__LCD_COM_SEG)
/* Enable Segment LCD */
#define Nex_TXD_LCD_EN                 (* (reg8 *) Nex_TXD__LCD_EN)
/* Slew Rate Control */
#define Nex_TXD_SLW                    (* (reg8 *) Nex_TXD__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Nex_TXD_PRTDSI__CAPS_SEL       (* (reg8 *) Nex_TXD__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Nex_TXD_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Nex_TXD__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Nex_TXD_PRTDSI__OE_SEL0        (* (reg8 *) Nex_TXD__PRTDSI__OE_SEL0) 
#define Nex_TXD_PRTDSI__OE_SEL1        (* (reg8 *) Nex_TXD__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Nex_TXD_PRTDSI__OUT_SEL0       (* (reg8 *) Nex_TXD__PRTDSI__OUT_SEL0) 
#define Nex_TXD_PRTDSI__OUT_SEL1       (* (reg8 *) Nex_TXD__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Nex_TXD_PRTDSI__SYNC_OUT       (* (reg8 *) Nex_TXD__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Nex_TXD__SIO_CFG)
    #define Nex_TXD_SIO_HYST_EN        (* (reg8 *) Nex_TXD__SIO_HYST_EN)
    #define Nex_TXD_SIO_REG_HIFREQ     (* (reg8 *) Nex_TXD__SIO_REG_HIFREQ)
    #define Nex_TXD_SIO_CFG            (* (reg8 *) Nex_TXD__SIO_CFG)
    #define Nex_TXD_SIO_DIFF           (* (reg8 *) Nex_TXD__SIO_DIFF)
#endif /* (Nex_TXD__SIO_CFG) */

/* Interrupt Registers */
#if defined(Nex_TXD__INTSTAT)
    #define Nex_TXD_INTSTAT            (* (reg8 *) Nex_TXD__INTSTAT)
    #define Nex_TXD_SNAP               (* (reg8 *) Nex_TXD__SNAP)
    
	#define Nex_TXD_0_INTTYPE_REG 		(* (reg8 *) Nex_TXD__0__INTTYPE)
#endif /* (Nex_TXD__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Nex_TXD_H */


/* [] END OF FILE */
