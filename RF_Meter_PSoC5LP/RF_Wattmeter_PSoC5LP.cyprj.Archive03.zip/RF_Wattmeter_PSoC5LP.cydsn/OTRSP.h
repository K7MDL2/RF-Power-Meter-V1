/* ========================================
 *   OTRSP.h
*/
#include <project.h>

void Clear_buf(void);
void OTRSP_setup(void);
uint8_t OTRSP(void);
uint8_t Translate_Band(uint8_t);
/* [] END OF FILE */
