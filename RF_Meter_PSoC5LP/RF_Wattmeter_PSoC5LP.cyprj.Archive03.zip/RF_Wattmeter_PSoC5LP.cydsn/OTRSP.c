/* ========================================
 *  OTRSP parsing
 *  Parses serial port commands from N1MM Logging program to control antennas and transverter via BCD or parallel GPIO port pins.
 *  Uses UART2 via calls to Serial2.c
 *  Only using the Aux commands not the whole SO2R list of commands so ot hte whole So@R list of p[ossible commands and queries
 *  Created by K7MDL July 27, 2020 for RF Wattmeter
 * ========================================
*/

//------------------------------------------------------------------
#include <project.h>
#include "Utilities.h"
#include "Serial.h"
#include "OTRSP.h"
//#include <stdio.h>
#include <stdlib.h>

//-------------------------------------------------------------------

#define FALSE 0
#define TRUE 1

// for general Constants
char CmdMsg[20];
char AuxCmd1[4];
uint8_t AuxCmd2;
uint8_t	Valid_Cmd;

void OTRSP_setup() 
{
    Serial_Init2();   // 9600,n.8.1 in UART2 settings
    Clear_buf();
	CmdMsg[0] = '\0' ;
	Valid_Cmd = FALSE ;
}

void Clear_buf(void) 
{
    uint8_t c;
    uint8_t i;
    
	if (Serial_Available2() > 0) 
    {
		for ( i = 0 ; i < Serial_Available2() ; i++)
        {
			c = (uint8_t) Serial_Read2() ;
		}
	}		
    for ( c = 0; c < 20; c++) 
	    CmdMsg[c] = '\0' ;
}

/*
Convert AUX command from N1MM to 4 bit BCD
Command format is AUXxnn fixed width. x is the radio number, usually 1.   Example is AUX103 for command 03 for BCD output of 0x03.
*/
uint8_t OTRSP()
{       
	//if ( Received )
    //{
	while (Serial_Available2() > 0 )     // get char(s) if any
    { 
		char c =Serial_Read2() ;  // get next char
		if (strlen(CmdMsg) > 7 ) // Checking Received Command Lengths 
        {  
			Clear_buf();
			Valid_Cmd = FALSE ;
			break ;
		}
		if (c == 0x0d)
        {				// When received a CR code, start to analyze received commnads.
			Valid_Cmd = TRUE ;
			break ;
		}
        strncat(CmdMsg,&c,1);
    }    

    if ( Valid_Cmd && strstr(CmdMsg,"AUX")) 
    {
        // extract the BCD number from bits 4-6
        //AuxCmd[0] = AuxStatus[3];  // Radio Number
        AuxCmd1[0] = CmdMsg[4];
        AuxCmd1[1] = CmdMsg[5];	
        AuxCmd1[2] = '\0';   // terminate string.   Now have an ascii string for 0-15
        AuxCmd2 = atoi(AuxCmd1);   // Convert 0-15 ASCII to int
        Aux1_Write(AuxCmd2);  // write out to the Control register which in turn writes to the GPIO ports assigned.
    	Clear_buf();
    	Valid_Cmd = FALSE ;
        AuxCmd2 = Translate_Band(AuxCmd2);
        return(AuxCmd2);  // AuxCmd2 now has a translated value - return for band change at meter
	}
    return 255;   // nothing processed 0 is a valid band number so using 255.
}

uint8_t Translate_Band(uint8_t band)
{
    uint8_t b;
    b = 0;
    band = band + b;   // change b to add or subtract if any correction required for BCD output top your device
    return band;
}

/* [] END OF FILE */
