/* ========================================
 *  OTRSP parsing
 *  Parses serial port commands from N1MM Logging program to control antennas and transverter via BCD or parallel GPIO port pins.
 *  Uses UART2 via calls to Serial2.c
 *  Only using the Aux commands not the whole SO2R list of commands so ot hte whole So@R list of p[ossible commands and queries
 *  Created by K7MDL July 27, 2020 for RF Wattmeter
 * ========================================
*/

//------------------------------------------------------------------
#include <project.h>
#include "Utilities.h"
#include "Serial.h"
#include "OTRSP.h"
//#include <stdio.h>
#include <stdlib.h>

//-------------------------------------------------------------------

#define FALSE 0
#define TRUE 1
#define AUXCMDLEN 4

// for general Constants
char AuxCmd0[64];
char AuxCmd1[AUXCMDLEN];
uint8_t AuxCmd2;
uint8_t RadioNum;
uint8_t ValidMsg;


/*
Convert AUX command from N1MM to 4 bit BCD
Command format is AUXxnn fixed width. x is the radio number, usually 1.   Example is AUX103 for command 03 for BCD output of 0x03.
*/
uint8_t OTRSP()
{     
    char c;
    int i;
    
    AuxCmd2 = 0;
    if (UART2_GetRxBufferSize() > 6)
    {
        c = UART2_GetChar();
        if (c == 'A')
        {            
            i = 0;
            AuxCmd0[i++] = c;
            while (UART2_GetRxBufferSize() != 0 && i < 7)
            {
                c = UART2_GetChar();
                AuxCmd0[i++] = c;                
            }
            if (AuxCmd0[6] == '\r')
            {
                ValidMsg = TRUE;
                if (strncmp(AuxCmd0,"AUX1",4) == 0)
                {
                    AuxCmd1[0] = AuxCmd0[4];
                    AuxCmd1[1] = AuxCmd0[5];
                    AuxCmd1[2] = '\0';
                    AuxCmd2 = atoi(AuxCmd1);   // Convert 0-15 ASCII to int
                    Aux1_Write(AuxCmd2);  // write out to the Control register which in turn writes to the GPIO ports assigned.                    	
                    AuxCmd2 = Translate_Band(AuxCmd2);
                    ValidMsg = FALSE;
                    AuxCmd0[0] = '\0' ;
                    RadioNum = 0;
                    return(AuxCmd2);  // AuxCmd2 now has a translated value - return for band change at meter
                }
            }
        }
    }
    ValidMsg = FALSE;
    return 255;   // nothing processed 0 is a valid band number so using 255.
}

uint8_t Translate_Band(uint8_t band)
{
    uint8_t b;
    b = 0;
    band = band + b;   // change b to add or subtract if any correction required for BCD output top your device
    return band;
}

/* [] END OF FILE */
