#include <project.h>
#include "Serial.h"
#include "Utilities.h"
#include <stdio.h>
#include "OTRSP.h"


#define RxBUFFLEN 64
volatile unsigned char rxBuff2[RxBUFFLEN];
volatile uint8_t rxHead2, rxTail2;
extern char8 cmd2[RxBUFFLEN];

void Serial_Init2()
{
    rxHead2 = 0;
    rxTail2 = 0;
}

unsigned char Serial_Write2(unsigned char c)
{
    UART2_PutChar(c);  // PSoC API
    return 1;
}

unsigned char Serial_Read2()
{
    unsigned char c;   
    
    if (rxTail2 < rxHead2)
    {        
        c = rxBuff2[rxTail2++];   // extract next char not read yet by functions
        if (rxTail2 == rxHead2)   // if we are caught up, reset buffer
        {
            rxHead2 = 0;
            rxTail2 = 0;
        }
    }
    else
    {
        rxHead2 = 0;     // reset buffer if empy or tail > head for some reason
        rxTail2 = 0;
        c = -1;         // -1 indicates something wrong, ignore C value
    }
    return c;
}

unsigned char Serial_Available2()
{
    unsigned char c;     
     
    while ( UART2_GetRxBufferSize() != 0)
    {
        c = UART2_ReadRxData();
        rxBuff2[rxHead2++] = c;  // fill buffer with next char
        if (rxHead2 > RxBUFFLEN-1)  // prevent overrun
            rxHead2 = RxBUFFLEN;
        if (rxTail2 > RxBUFFLEN-1)
            rxTail2 = RxBUFFLEN;
    }   
    return rxHead2 - rxTail2;
}

unsigned char Serial_ReadBytes2(char *buf, unsigned char len)
{
    unsigned char cnt = 0;
    
    Serial_Available();
    if (len < rxHead2 - rxTail2)
    {
        //ArrayCopy(buf, &rxBuff2[rxTail2], len);
        ClearArray(buf);
        memcpy(buf, &rxBuff2[rxTail2], len);
        rxTail2 += len;
        cnt = len;
    }
    else if (len == rxHead2 - rxTail2)
    {
        //ArrayCopy(buf, &rxBuff2[rxTail2], len);
        ClearArray(buf);
        memcpy(buf, &rxBuff2[rxTail2], len);
        rxTail2 = 0;
        rxHead2 = 0;
        cnt = len;
    }
    else
    {
        //ArrayCopy(buf, &rxBuff[rxTail], rxHead - rxTail);
        ClearArray(buf);
        cnt = rxHead2 - rxTail2;
        if (cnt > strlen(buf)) // On initial power up (not resets) the memecpy was copyung more bytes then the buffer.
            cnt = strlen(buf);  // this appears to prevent that and make for reliable startup
        if (cnt !=0 && rxTail2 !=0)
            memcpy(buf, &rxBuff2[rxTail2], cnt);                
        rxTail2 = 0;
        rxHead2 = 0;
    }
    return cnt;
}

void Serial_Print2(char *scmd )
{
    // using global cmd_data as passing string is not working for some reason, only getting first char of strings.
    UART2_PutString(cmd2);
}