/*******************************************************************************
* File Name: clock_10KHz.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_clock_10KHz_H)
#define CY_CLOCK_clock_10KHz_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
* Conditional Compilation Parameters
***************************************/

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component cy_clock_v2_20 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */


/***************************************
*        Function Prototypes
***************************************/

void clock_10KHz_Start(void) ;
void clock_10KHz_Stop(void) ;

#if(CY_PSOC3 || CY_PSOC5LP)
void clock_10KHz_StopBlock(void) ;
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

void clock_10KHz_StandbyPower(uint8 state) ;
void clock_10KHz_SetDividerRegister(uint16 clkDivider, uint8 restart) 
                                ;
uint16 clock_10KHz_GetDividerRegister(void) ;
void clock_10KHz_SetModeRegister(uint8 modeBitMask) ;
void clock_10KHz_ClearModeRegister(uint8 modeBitMask) ;
uint8 clock_10KHz_GetModeRegister(void) ;
void clock_10KHz_SetSourceRegister(uint8 clkSource) ;
uint8 clock_10KHz_GetSourceRegister(void) ;
#if defined(clock_10KHz__CFG3)
void clock_10KHz_SetPhaseRegister(uint8 clkPhase) ;
uint8 clock_10KHz_GetPhaseRegister(void) ;
#endif /* defined(clock_10KHz__CFG3) */

#define clock_10KHz_Enable()                       clock_10KHz_Start()
#define clock_10KHz_Disable()                      clock_10KHz_Stop()
#define clock_10KHz_SetDivider(clkDivider)         clock_10KHz_SetDividerRegister(clkDivider, 1u)
#define clock_10KHz_SetDividerValue(clkDivider)    clock_10KHz_SetDividerRegister((clkDivider) - 1u, 1u)
#define clock_10KHz_SetMode(clkMode)               clock_10KHz_SetModeRegister(clkMode)
#define clock_10KHz_SetSource(clkSource)           clock_10KHz_SetSourceRegister(clkSource)
#if defined(clock_10KHz__CFG3)
#define clock_10KHz_SetPhase(clkPhase)             clock_10KHz_SetPhaseRegister(clkPhase)
#define clock_10KHz_SetPhaseValue(clkPhase)        clock_10KHz_SetPhaseRegister((clkPhase) + 1u)
#endif /* defined(clock_10KHz__CFG3) */


/***************************************
*             Registers
***************************************/

/* Register to enable or disable the clock */
#define clock_10KHz_CLKEN              (* (reg8 *) clock_10KHz__PM_ACT_CFG)
#define clock_10KHz_CLKEN_PTR          ((reg8 *) clock_10KHz__PM_ACT_CFG)

/* Register to enable or disable the clock */
#define clock_10KHz_CLKSTBY            (* (reg8 *) clock_10KHz__PM_STBY_CFG)
#define clock_10KHz_CLKSTBY_PTR        ((reg8 *) clock_10KHz__PM_STBY_CFG)

/* Clock LSB divider configuration register. */
#define clock_10KHz_DIV_LSB            (* (reg8 *) clock_10KHz__CFG0)
#define clock_10KHz_DIV_LSB_PTR        ((reg8 *) clock_10KHz__CFG0)
#define clock_10KHz_DIV_PTR            ((reg16 *) clock_10KHz__CFG0)

/* Clock MSB divider configuration register. */
#define clock_10KHz_DIV_MSB            (* (reg8 *) clock_10KHz__CFG1)
#define clock_10KHz_DIV_MSB_PTR        ((reg8 *) clock_10KHz__CFG1)

/* Mode and source configuration register */
#define clock_10KHz_MOD_SRC            (* (reg8 *) clock_10KHz__CFG2)
#define clock_10KHz_MOD_SRC_PTR        ((reg8 *) clock_10KHz__CFG2)

#if defined(clock_10KHz__CFG3)
/* Analog clock phase configuration register */
#define clock_10KHz_PHASE              (* (reg8 *) clock_10KHz__CFG3)
#define clock_10KHz_PHASE_PTR          ((reg8 *) clock_10KHz__CFG3)
#endif /* defined(clock_10KHz__CFG3) */


/**************************************
*       Register Constants
**************************************/

/* Power manager register masks */
#define clock_10KHz_CLKEN_MASK         clock_10KHz__PM_ACT_MSK
#define clock_10KHz_CLKSTBY_MASK       clock_10KHz__PM_STBY_MSK

/* CFG2 field masks */
#define clock_10KHz_SRC_SEL_MSK        clock_10KHz__CFG2_SRC_SEL_MASK
#define clock_10KHz_MODE_MASK          (~(clock_10KHz_SRC_SEL_MSK))

#if defined(clock_10KHz__CFG3)
/* CFG3 phase mask */
#define clock_10KHz_PHASE_MASK         clock_10KHz__CFG3_PHASE_DLY_MASK
#endif /* defined(clock_10KHz__CFG3) */

#endif /* CY_CLOCK_clock_10KHz_H */


/* [] END OF FILE */
