#ifndef __NEXPAGE_H__
#define __NEXPAGE_H__
#include "NexTouch.h"
#include "NexHardware.h"
#include "Utilities.h"

uint8_t NexPage_show(struct NexObject *);

#endif /* #ifndef __NEXPAGE_H__ */
