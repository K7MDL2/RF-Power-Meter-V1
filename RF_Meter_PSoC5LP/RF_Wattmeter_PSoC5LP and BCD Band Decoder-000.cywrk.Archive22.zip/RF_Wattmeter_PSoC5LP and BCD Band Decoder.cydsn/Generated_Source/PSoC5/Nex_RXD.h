/*******************************************************************************
* File Name: Nex_RXD.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Nex_RXD_H) /* Pins Nex_RXD_H */
#define CY_PINS_Nex_RXD_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Nex_RXD_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Nex_RXD__PORT == 15 && ((Nex_RXD__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Nex_RXD_Write(uint8 value);
void    Nex_RXD_SetDriveMode(uint8 mode);
uint8   Nex_RXD_ReadDataReg(void);
uint8   Nex_RXD_Read(void);
void    Nex_RXD_SetInterruptMode(uint16 position, uint16 mode);
uint8   Nex_RXD_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Nex_RXD_SetDriveMode() function.
     *  @{
     */
        #define Nex_RXD_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Nex_RXD_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Nex_RXD_DM_RES_UP          PIN_DM_RES_UP
        #define Nex_RXD_DM_RES_DWN         PIN_DM_RES_DWN
        #define Nex_RXD_DM_OD_LO           PIN_DM_OD_LO
        #define Nex_RXD_DM_OD_HI           PIN_DM_OD_HI
        #define Nex_RXD_DM_STRONG          PIN_DM_STRONG
        #define Nex_RXD_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Nex_RXD_MASK               Nex_RXD__MASK
#define Nex_RXD_SHIFT              Nex_RXD__SHIFT
#define Nex_RXD_WIDTH              1u

/* Interrupt constants */
#if defined(Nex_RXD__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Nex_RXD_SetInterruptMode() function.
     *  @{
     */
        #define Nex_RXD_INTR_NONE      (uint16)(0x0000u)
        #define Nex_RXD_INTR_RISING    (uint16)(0x0001u)
        #define Nex_RXD_INTR_FALLING   (uint16)(0x0002u)
        #define Nex_RXD_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Nex_RXD_INTR_MASK      (0x01u) 
#endif /* (Nex_RXD__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Nex_RXD_PS                     (* (reg8 *) Nex_RXD__PS)
/* Data Register */
#define Nex_RXD_DR                     (* (reg8 *) Nex_RXD__DR)
/* Port Number */
#define Nex_RXD_PRT_NUM                (* (reg8 *) Nex_RXD__PRT) 
/* Connect to Analog Globals */                                                  
#define Nex_RXD_AG                     (* (reg8 *) Nex_RXD__AG)                       
/* Analog MUX bux enable */
#define Nex_RXD_AMUX                   (* (reg8 *) Nex_RXD__AMUX) 
/* Bidirectional Enable */                                                        
#define Nex_RXD_BIE                    (* (reg8 *) Nex_RXD__BIE)
/* Bit-mask for Aliased Register Access */
#define Nex_RXD_BIT_MASK               (* (reg8 *) Nex_RXD__BIT_MASK)
/* Bypass Enable */
#define Nex_RXD_BYP                    (* (reg8 *) Nex_RXD__BYP)
/* Port wide control signals */                                                   
#define Nex_RXD_CTL                    (* (reg8 *) Nex_RXD__CTL)
/* Drive Modes */
#define Nex_RXD_DM0                    (* (reg8 *) Nex_RXD__DM0) 
#define Nex_RXD_DM1                    (* (reg8 *) Nex_RXD__DM1)
#define Nex_RXD_DM2                    (* (reg8 *) Nex_RXD__DM2) 
/* Input Buffer Disable Override */
#define Nex_RXD_INP_DIS                (* (reg8 *) Nex_RXD__INP_DIS)
/* LCD Common or Segment Drive */
#define Nex_RXD_LCD_COM_SEG            (* (reg8 *) Nex_RXD__LCD_COM_SEG)
/* Enable Segment LCD */
#define Nex_RXD_LCD_EN                 (* (reg8 *) Nex_RXD__LCD_EN)
/* Slew Rate Control */
#define Nex_RXD_SLW                    (* (reg8 *) Nex_RXD__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Nex_RXD_PRTDSI__CAPS_SEL       (* (reg8 *) Nex_RXD__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Nex_RXD_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Nex_RXD__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Nex_RXD_PRTDSI__OE_SEL0        (* (reg8 *) Nex_RXD__PRTDSI__OE_SEL0) 
#define Nex_RXD_PRTDSI__OE_SEL1        (* (reg8 *) Nex_RXD__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Nex_RXD_PRTDSI__OUT_SEL0       (* (reg8 *) Nex_RXD__PRTDSI__OUT_SEL0) 
#define Nex_RXD_PRTDSI__OUT_SEL1       (* (reg8 *) Nex_RXD__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Nex_RXD_PRTDSI__SYNC_OUT       (* (reg8 *) Nex_RXD__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Nex_RXD__SIO_CFG)
    #define Nex_RXD_SIO_HYST_EN        (* (reg8 *) Nex_RXD__SIO_HYST_EN)
    #define Nex_RXD_SIO_REG_HIFREQ     (* (reg8 *) Nex_RXD__SIO_REG_HIFREQ)
    #define Nex_RXD_SIO_CFG            (* (reg8 *) Nex_RXD__SIO_CFG)
    #define Nex_RXD_SIO_DIFF           (* (reg8 *) Nex_RXD__SIO_DIFF)
#endif /* (Nex_RXD__SIO_CFG) */

/* Interrupt Registers */
#if defined(Nex_RXD__INTSTAT)
    #define Nex_RXD_INTSTAT            (* (reg8 *) Nex_RXD__INTSTAT)
    #define Nex_RXD_SNAP               (* (reg8 *) Nex_RXD__SNAP)
    
	#define Nex_RXD_0_INTTYPE_REG 		(* (reg8 *) Nex_RXD__0__INTTYPE)
#endif /* (Nex_RXD__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Nex_RXD_H */


/* [] END OF FILE */
