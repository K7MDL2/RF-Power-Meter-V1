/*******************************************************************************
* File Name: LoRa_Aux.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_LoRa_Aux_H) /* Pins LoRa_Aux_H */
#define CY_PINS_LoRa_Aux_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "LoRa_Aux_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 LoRa_Aux__PORT == 15 && ((LoRa_Aux__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    LoRa_Aux_Write(uint8 value);
void    LoRa_Aux_SetDriveMode(uint8 mode);
uint8   LoRa_Aux_ReadDataReg(void);
uint8   LoRa_Aux_Read(void);
void    LoRa_Aux_SetInterruptMode(uint16 position, uint16 mode);
uint8   LoRa_Aux_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the LoRa_Aux_SetDriveMode() function.
     *  @{
     */
        #define LoRa_Aux_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define LoRa_Aux_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define LoRa_Aux_DM_RES_UP          PIN_DM_RES_UP
        #define LoRa_Aux_DM_RES_DWN         PIN_DM_RES_DWN
        #define LoRa_Aux_DM_OD_LO           PIN_DM_OD_LO
        #define LoRa_Aux_DM_OD_HI           PIN_DM_OD_HI
        #define LoRa_Aux_DM_STRONG          PIN_DM_STRONG
        #define LoRa_Aux_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define LoRa_Aux_MASK               LoRa_Aux__MASK
#define LoRa_Aux_SHIFT              LoRa_Aux__SHIFT
#define LoRa_Aux_WIDTH              1u

/* Interrupt constants */
#if defined(LoRa_Aux__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in LoRa_Aux_SetInterruptMode() function.
     *  @{
     */
        #define LoRa_Aux_INTR_NONE      (uint16)(0x0000u)
        #define LoRa_Aux_INTR_RISING    (uint16)(0x0001u)
        #define LoRa_Aux_INTR_FALLING   (uint16)(0x0002u)
        #define LoRa_Aux_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define LoRa_Aux_INTR_MASK      (0x01u) 
#endif /* (LoRa_Aux__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define LoRa_Aux_PS                     (* (reg8 *) LoRa_Aux__PS)
/* Data Register */
#define LoRa_Aux_DR                     (* (reg8 *) LoRa_Aux__DR)
/* Port Number */
#define LoRa_Aux_PRT_NUM                (* (reg8 *) LoRa_Aux__PRT) 
/* Connect to Analog Globals */                                                  
#define LoRa_Aux_AG                     (* (reg8 *) LoRa_Aux__AG)                       
/* Analog MUX bux enable */
#define LoRa_Aux_AMUX                   (* (reg8 *) LoRa_Aux__AMUX) 
/* Bidirectional Enable */                                                        
#define LoRa_Aux_BIE                    (* (reg8 *) LoRa_Aux__BIE)
/* Bit-mask for Aliased Register Access */
#define LoRa_Aux_BIT_MASK               (* (reg8 *) LoRa_Aux__BIT_MASK)
/* Bypass Enable */
#define LoRa_Aux_BYP                    (* (reg8 *) LoRa_Aux__BYP)
/* Port wide control signals */                                                   
#define LoRa_Aux_CTL                    (* (reg8 *) LoRa_Aux__CTL)
/* Drive Modes */
#define LoRa_Aux_DM0                    (* (reg8 *) LoRa_Aux__DM0) 
#define LoRa_Aux_DM1                    (* (reg8 *) LoRa_Aux__DM1)
#define LoRa_Aux_DM2                    (* (reg8 *) LoRa_Aux__DM2) 
/* Input Buffer Disable Override */
#define LoRa_Aux_INP_DIS                (* (reg8 *) LoRa_Aux__INP_DIS)
/* LCD Common or Segment Drive */
#define LoRa_Aux_LCD_COM_SEG            (* (reg8 *) LoRa_Aux__LCD_COM_SEG)
/* Enable Segment LCD */
#define LoRa_Aux_LCD_EN                 (* (reg8 *) LoRa_Aux__LCD_EN)
/* Slew Rate Control */
#define LoRa_Aux_SLW                    (* (reg8 *) LoRa_Aux__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define LoRa_Aux_PRTDSI__CAPS_SEL       (* (reg8 *) LoRa_Aux__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define LoRa_Aux_PRTDSI__DBL_SYNC_IN    (* (reg8 *) LoRa_Aux__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define LoRa_Aux_PRTDSI__OE_SEL0        (* (reg8 *) LoRa_Aux__PRTDSI__OE_SEL0) 
#define LoRa_Aux_PRTDSI__OE_SEL1        (* (reg8 *) LoRa_Aux__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define LoRa_Aux_PRTDSI__OUT_SEL0       (* (reg8 *) LoRa_Aux__PRTDSI__OUT_SEL0) 
#define LoRa_Aux_PRTDSI__OUT_SEL1       (* (reg8 *) LoRa_Aux__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define LoRa_Aux_PRTDSI__SYNC_OUT       (* (reg8 *) LoRa_Aux__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(LoRa_Aux__SIO_CFG)
    #define LoRa_Aux_SIO_HYST_EN        (* (reg8 *) LoRa_Aux__SIO_HYST_EN)
    #define LoRa_Aux_SIO_REG_HIFREQ     (* (reg8 *) LoRa_Aux__SIO_REG_HIFREQ)
    #define LoRa_Aux_SIO_CFG            (* (reg8 *) LoRa_Aux__SIO_CFG)
    #define LoRa_Aux_SIO_DIFF           (* (reg8 *) LoRa_Aux__SIO_DIFF)
#endif /* (LoRa_Aux__SIO_CFG) */

/* Interrupt Registers */
#if defined(LoRa_Aux__INTSTAT)
    #define LoRa_Aux_INTSTAT            (* (reg8 *) LoRa_Aux__INTSTAT)
    #define LoRa_Aux_SNAP               (* (reg8 *) LoRa_Aux__SNAP)
    
	#define LoRa_Aux_0_INTTYPE_REG 		(* (reg8 *) LoRa_Aux__0__INTTYPE)
#endif /* (LoRa_Aux__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_LoRa_Aux_H */


/* [] END OF FILE */
