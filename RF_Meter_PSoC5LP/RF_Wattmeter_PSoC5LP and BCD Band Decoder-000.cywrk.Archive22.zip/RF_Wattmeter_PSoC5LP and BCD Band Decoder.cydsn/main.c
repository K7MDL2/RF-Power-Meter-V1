/* ========================================
 *
 * Copyright K7MDL, 2020
 * All Rights Reserved
 * Distribution allowed per MIT License
 *
 * ========================================
*/
/*  TODO:
    Vendor ID – This is a 16-bit number used to uniquely identify USB devices belonging to a 
    specific vendor/manufacturer to a USB host. Vendor IDs are assigned by the USB Implementers 
    Forum (USB-IF). The following link in the USB-IF webpage explains the method to obtain a
    vendor ID for your company:      
    http://www.usb.org/developers/vendor/ 
    Note Vendor ID 0x4B4 is a Cypress-only VID and may be used for development purposes only. 
    Products cannot be released using this VID; you must obtain your own VID. 
*/
    
/*
 *
 * RF Wattmeter_PSoc5LP by K7MDL 11/11/2020   - PSoc5LP version (Nextion, OLED, or headless) With Band Decoder for 50-1296 5 band transverter and amps

*  11/16/2020 - Added cal alues for voltage readings for desktop meter.  Added new serial message type for voltages (171) and output it with the normal power message type (170).  
                Need to add ability to accept command to set cal on voltage, temp and current ADC readings.  Today it is hard coded.  Alarm thresholds are set by Touchscreen however.

*  11/13/2020 - Bug Fix. While in RX, gettign random SWR = 10 values, fixed logic to better filter out random RX level calcuations. Calibration 
                can result in Ref power being slightly greater than Fwd power causing really high SWR values even at RX (no signal).  Set RX threshold to 0.2W FWD.

*  11/11/2020 - Bug fix. Moved code around and created a recursive call to asdread during hi SWR scenario.  Used a goto label to reread the adc values for power and put a retry count in
                to limit retries to 2.  Just want to wait out a transient scenario during RX and TX swtiching before moving on.

*  11/5/2020  - Minor update to the OLED display code section to actually display 28V, 14V, current (future), and ADL5519 board temp for the compact KitProg
                version mounted to a new 1296 60W amp front panel with OLED display.  Of course fwd and Ref power and SWR caculated.  The ADL5519 OutP is run
                to the W6PQL amplifier control board Load Fail input for hi SWR shutdown. - Update - OutP wont work for Load Fail sig becaue at no signal (RX) the votlage jumps to 1.7V.
                When in TX the votlage drops to .9V and then varies with SWR.    Can either pass though the OutP signal through a AMux and cut it off in RX (Gate it with PTT on chip) or 
                use a DAC to create a positive slope 0V to 1 to 4V equivalent fo SWR or Refelcted power.  The ADL5519 is a negative slope output with an offset of 0.5V.  P12_5 is free on
                the KitPRog and used for optional LoRa on full size boards so can use that pin.  Can also use PTT to control a transistor which gates OutP sig.  
                
                For now I reassigned P3_5 to be a DAC Voltage output rather than the planned current input since I do not have a current measure device yet.  The 
                DAC is buggered with a PGA set to unity gain (Gain =1) to better drive the Amp control board input uiong a 0-4V range.
                On a full size board this could be assigned to P3_7 but on a KitProg that pin has no trace, soldering to it is tough.  P12_5 is spare but not an analog pin.
                A new #define for SWR_ANALOG is added to remove this function for non Amplifier type use.   Need to reassign the P3_5 as required.
                
                Fixed SWR value calc to limit value to 0-10 and eliminated negative values such as when transmitting into open cable.
                Was supposed to limit at 10 but when Ref was greater than Fwd, was getting negative number.  Was getting occasinal False high SWR at end of TX due to timing of
                Ref vs Fwd reads since this is so fast.  So if SWR > 2 now call adRead() again and then issue value to DAC.  One retry seems to be enough.
 * 
*  10/18/2020 - Added ports and minor code to Serial.c and Main.c to support 915Mhz LoRa E32-915T20D wireless serial link between the Nextion and the CPU.
                This could also be applied to the USB serial to the host PC but requires a bit more work as it is a USB serial port.
                Found Arduino Mega config program source on Github, made it work on a Teensy 4.1 to program the transceivers baud rate and air data rates 
                then tried to slip it in between the Nextion and PSoC. It sort of worked but the link was very slow due to teh amount of traffic since the 
                communication design assumed a hardwired high speed link.  The library also assumes it won't miss a response so some means of recovery is needed.
                I reduced the traffic somewhat by slowing the refresh rate for page 0 data and only sending updates when a data element changes value.  
                
                Further I added an Arduino CPU to the Nextion side to buffer and do flow control to the LoRa.  What is really needed is a redesign of the comm protocol
                to send data (when changed) to global variables that use object names and isolate object IDs from being needed on the CPU side.   For example
                a touch event should jsut havethe object name only, same for updating a field.  Knowledge of the current page can optinally be used to 
                reduce traffic, better yet a timer in the display can request a refresh for a specific page.  Today you have to capture the page change event and
                the page number.  This info is available but testing over wireless the page number function as written returns odd results and has been unreliable.
                
                When the CPU is scheduling updates it has to constantly ask what page number to prevent sending updates to teh wrong page causing error values to be
                returned causng missed evnets because the routing waiting for the page number assumes it is the next one in teh queue and returns failed.  The CPU can attempt
                to keep track of state (current page) but 1 missed event and things get off track quickly.  Easier if the display asks for a specific page update.
                Further protocol improvments would have the parser queue message types.  Today certain message trigger a callback by a parser watching the serial queue.  
                
                These do not always happen as expected. This could be partially caused by the CPU sending updates while touch events are arriving resulting in 
                missed responses such as page number requests.  One answer is to have strict queue management that waits for an item to be pulled off before unveiling the next.
                The CPU must deal with out of order recovery or prevent such situation, hard to do with a user randonmy creating touch events while the CPU is waiting for a page number
                so interruption handling is required.  Better is a queue manger that stacks each message and deletes it after the CPU finds it.  This will likely grow 
                in size over time as certain messages are abandoned due to changes like touch event.  In that case maybe event like change page will delete all prior message
                essentially starting fresh.  Also old meesages should age out.
                
                Another approach involves writing to global variables on a single page only. The display requests updates to groups of them.  CPU simply follows.
                This could be simpler for the case where the display is the driver of the scenario.
                                                              
                To enter programming mode 2 pins must be changed from 0 to 1 each, and for transmissions, flow control may be needed by watching the Aux pin on
                the Xcvr.  Aux Low is busy or buffer full. Right now the updates to the Nextion on the main page 0 are many and that slows things down for
                the responses and it is dropping stuff making retries on band changes or very slow updates. The PSoC side is doing flow control, but not
                the Nextion side yet. Running the baud rate and air data rate at 19,200bps but need to reduce the total traffic on the CPU send side by
                filtering out updates for values that have not changed (largely done now but some optimization stil lrequired).  This should allow faster response message time
                for overall faster feel and fewer missed events.  These are simplex transcievers so if one side is transmitting constantly it leaves little time for a response to
                be sent back and hold the other sender off while receiving. 
                It may be possible to program the Nextion to program the parameters of the Xcvr with the optional Nextion 8 port IO expander PCB wired to
                the AUX, M0 and M1 pins of the Xcvr and do flow control like on the PSoC side.  Otherwise put a small CPU like Arduino Nano or PSoC Kitprog
                as a buffer/flow controller next to the Nextion.  This I have now done which along with traffic reduction and careful placement of delays (or removing delays)
                in the Serial.c, NexHardware.c and main program reshresh internval I have made it usable with few missed events.  The band change lable update mechanism is still 
                too slow but the page 0 band label can be updated in the touch event callback rather than waiting for the next screen refresh.

 * 10/7/2020 -  Version 2.3
                Added several input and output ports for BCD in to decode to parallel out, also pass though the BCD to the 5 band transverter or other
                hardware. The input supports 6 wires in case non BCD usage is needed. With BCD mode, the BCD inut #5 is not used. The BCD is decoded to 
                to 6 parallel output pins which typically control a buffer or relay board which in turn selects band related things such as a watt meter
                sensor and remote ampifier enable (remote power-on signal). In this example I use diodes from the remote amp power relay outputs to
                select certain watt meter sensors for each band (some are used on multiple bands) for the peak reading Bird wattmeter.  
                Additional pins are used for antenna relay selection.  In my example I have 3 SPDT high power Coax relays switch amog 4 amps to put them
                on a common coax to the 144-1296 LPDA antenna.  IN my example here I hacve 1296 dedicated to it's own higher gain antenna and power sensor.
                50 MHz is Band 0 and is treated like the other bands with an amplifier and dedicated power sensor and antenna.  
                6M drive comes from the radio direct vs a transverter in this example.  One coudl leave out the 6M amp and go direct to antenna.

 * 7/28/2020 -  Version 2.2
                OTRSP protocol support added so that N1MM+ logger program can control antennas and transverters via a serial port command.
                GPIO pins are brought out to optional driver chips for either parallel port or BCD format band decoding.  
                Useful for radios that do not have BCD band decoders or need to operate SP6T coax relays as an examnple.
                Many radios do not support transverters in any way so transverter switching is helped with this. 
                N1MM and the Wattmeter know about every band and can display it.
 * 
 * 7/25/2020 -  Version 2.1                
                Added new Calibrate ADC page to Nextion screen that operates the same as the Desktop Config Screen.  Provide hi and low power levels
                and hit measure button to capture.  Then hit cal for fwd or ref pwr as appropriate.                  
                
                Changed Main Nextion screen Band text box to a Button.  Pressing this now jumps to new page with Band buttons.
                Preesing any one of these will return back to main page and also set parms for the main loop to change to the new band.  
                This is the same process used by the remote command 254.  
                Desktop will still set it back to the radio;s band if WSJTX or manual desktop command given. 
                This is used when there is no connection or WSJTX is not running with the Desktop app.               
                
                This is done only for the 2.4" Nextion screen for today. Need to make the changes to the 3.5" screen.  No changes to the 
                desktop app or headless or OLED configs.
                
                Made the band changes faster.  Instead of saving all config to EEPROMN, it now only saves state vars like op mode, band.  
                Several screens have a Save Config button which commits everything to EEPROM.  The Desktop app config page has a Factory Reset if needed. 
                There are also 2 hotspots, one in each upper corner of the Coupler Screen, the when pressed right side then left side will also do a factory reset. 
                
                On power up the CPU was hanging in a Nextion serial port related array memcpy.  There was no bounds checking.  
                Contrained the max memcpy size to the RxBuff size, Added defensive bufer length checking in other areas nearby.
                In the couorse of doing that testing it seemed like to many touch events were missed.  Ended up reworking the quick fix for serial
                port char collection made on the initial port to the PSoC to be truer to the original coding.  Seems to work better now.
                
                Relocated the Nextion source files into the Wattmeter project folder at same level as Wattmeter.
 *
 * 7/1/2020 -   Version 2.0 released.  Contains support for 3.5" Nextion screen, headless, or OLED option.
                has Auto Calibration by providing a carrier at 2 power levels and send those levels o teh host CPU to calculate slope and
                intercept (Offset).  Aupports ADS8318 pair or beter yet, the similar dual channel 10Ghz version the ADL5519 (SV1AFN.com)
 *              Matches up to the optional desktop Python app "pyRFWattMter.py".  It has a calibration GUI included that sends the right commands
                The Nextion screens can do manual so far.  The Nextion has a new spage for Voltage setpioints and for graphing power and SWR.
                Performance with the ADL5519 is very good, numbers match the spec sheet well on 50Mhz through 1296MHz Ham bands that I tested with.
                I also tested with a ADS1100 external 16bit ADC.  The similar 4 port version is the ADS1115.  These connect via I2C bus and are good
                options for Arduinos with lower resolution noisy internal ADCs. The PSoC5LP has a very clean Vref and ADC and high isolation Amux hardware
                components. There are several ADC options onboard. This is using a single Delta Sigma ADC block with 20bit resolution.

 * 6/9/2020 -   Major work on setting up main and 2 config pages for the Nextion
 *              Created workaround for buffer overflow on a pointer to a char string passed between functions in separate files.  
 *              Pointer was at correct start but debugger only showed 1 byte in string. Found in 2 places, NexText and Serial cmd send sections
 *              In use the strcpy never saw a NULL byte and copyed the string endlessly until there was no more memory left.
 *              Added more EEPROM stored items for max current, temp, HV DC and 14VDC since larger displays like the desktop and Nextion can 
 *              configure and display them, alerting with color changes.
 *              For the Nextion created slider based coupler cal and max setpoints controls and event handling
 *              The Nextion handles most all the UI work for fast updates, minimal CPU interaction required.
 *              Do need to be careful about changing a band's coupling cal numbers while the band could change under it.
 *              It would result in saving the wrong set of numbers to the new current coupling cal table.
                3rd page was added to configure alarm setpoints for HV DC, 14 VDC, Temp and Current, also can manually set band and Meter ID.  
                Use the Save Config buttons on each config page to commit change to EEPROM.  
                Changes will stick if a band change occurs, otherwise need to manually save when done (design choice).
                Expanded NUM_SETS to 11 bands to add HF, previously combined with 50MHz.  Some radios band decoders will not differentiate between
                50MHz and HF using 4 BCD lines. If a 5th is used (like the K3 DIGOUT1).  
                Remapped the command table to run from 240 to 250.  
                Moved the dump cal table command to 252. Changed the button logic in the Python app to match.
                Added #ifdef around all Nextion and all SSD1306O_LED display code.
                This allows for cleanly adding new display types and sizes or no display and not carry the extra code baggage.
                Some displays may reuse parts like different sizes Nextion or sizes of OLED with a slight controller change.
                Updated EEPROM to save the setpoints. meterID and band info with Save Config button and remote reset to defaults.
                Can edit one band at a time by changing bands manually on 3rd page or remotely.
                Added 100 second hardware interrupt driven timer to control display update rates and serial output rates.
                
 * 6/6/2020 -   0.96" OLED up and running.  Nextion 2.4" LCD graphihcs screen up and running. 
 *              Reassigned IO pins to match the available poins on a KitProg board
 *              Made a Bootloader for the KitProg board and using it on a proto board to driv the OLED ont eh back of a front panel of a RF amplifier
 *              Both use the identical code except the Kitprog has the bootloader component on it.  No code changes required.
 *
 * 6/1/2020 -   Added timeout to USB write to remove hang when USB is down.  
 *              Now operates when the USB is disconnected which is useful when a display is attached for local data display
 *              Set up OLED formatting function for Fwd Power, Reflected power, and SWR and placeholders for temp and current.
 *
 * 5/31/2020 -  Added SSD1306 display controller code to support OLED display test on I2C bus.   Fixed EEPRONM read problem.  
 *              Changing a cal value now updates for use immediately.
 *
 * 5/27/2020 -  Headless port from Arduino Nano to PSoC5LP CY8CKIT-059 dev module now fully working.
                EEPROM work much differently and using USB serial port.
 *
 * 5/10/2020 -  Headless Nano CPU version. 
 *              Stripped out physical button tests.  
 *              Removed rest of M5/ESP32 dependencies,
 *              Using standard Arduino functions (vs original M5Stack/esp32).  
 *              Added CPU reset and default EEPROM commands. 
 *              Trying out read_vcc() to measure VCC folowing each AD read to increase accuracy since
 *                  the Default is bus power (from USB or external).  Internal Vref is too low at 1.1V to use
 *                  Without adding an external voltage divider.
 *
 * 5/8/2020 - Added Remote commands to support dumping the cal table and writing to individual coupling
 *    factor cal values and saving to EEPROM.  Switch from a one byte command to a string with similar structure
 *    as the power level out.  Changed sequence number to msg_type fo future expansion and to help validate the 
 *    incoming message better from random data/noise/CPU status messages.
 *    There is still some screen drawing mostly in the cal area yet to be removed.  Considering leaving the digital
 *    values screen writing in for adaption to a 2x16/4x20 LCD or small graphics OLED embedded in an RFampifier as
 *    the main meter with SWR shutdowna nd other feature (including remote monitoring).
 *    One concern for getting Wi-Fi to work is the possibility the ESP32 in the M5stack I am using may take over ADC2 pins 
 *    which would be a problem.  Also the internal noise coudl be improved using an external I2C connected A/D.
 *
 Has user edited Calibration sets. Have 10 "bands" for frequency correction used with values that can be edited via the UI ---

 In this code example I use a RLC .05-1000MHz coupler and created 10 cal bands toi cover 50M to 10G.
 A value for each dual directional coupler port combines the coupler facxtor, added attenuators, and any cal correction fudge factor.
 The values are edited via the device UI and stored in EEPROM.
*/
#include <project.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include "RF_Wattmeter.h"

//#define RESET_EEPROM

void setup(void) {

#ifdef SSD1306_OLED
    I2COLED_Start(); 
    display_init(DISPLAY_ADDRESS); // This line will initialize your display using the address you specified before.
    //gfx_setRotation(1);
    display_clear();    
    display_update();
#endif
    
    UART1_Start();   // for Nextion display
    UART2_Start();   // for N1MM interface using OTRSP protocol

    CyGlobalIntEnable; /* Enable global interrupts. */    
   
    /* Enable the Interrupt component connected to Timer interrupt */
    Timer_X00ms_ISR_StartEx(Timer_X00ms_InterruptHandler);
    Timer_X00ms_Start();
    
    /* Start USBFS operation with 5-V operation. */
    Serial_USB_Start(Serial_USB_DEVICE, Serial_USB_5V_OPERATION);  
    write_Cal_Table_from_Default();  // Copy default values into memory in case EEPROM not yet initialized
    ADC_RF_Power_Start();
    ADC_RF_Power_AMux_Start();
    ADC_RF_Power_StartConvert();
    #ifdef SWR_ANALOG // if using in a RF amplifier for HI SWR fail control.
        SWR_Fail_Analog_Output_Start();
        PGA_1_Start();
    #endif
    EEPROM_Start(); /*  Start the EEPROM storage System             */
    CyDelay(7);     /* wait at least 5ms to power up EEPROM       */
   
    /*   initialize EEPROM storage if not done before - will overwrite default memory table values from EEPROM if EEPROM was written to before */    
    
    #ifdef RESET_EEPROM
    EE_PGM_Failed = EEPROM_Init(EE_SAVE_YES);
    #else 
    EE_PGM_Failed = EEPROM_Init(0);
    #endif
    Cal_Table();   // Load current Band values from Table

    // initialize all the readings to 0:  Used to smooth AD values
        for (int thisReading = 0; thisReading < NUMREADINGS; thisReading++) {
        readings_Fwd[thisReading] = 0;
        readings_Ref[thisReading] = 0;
    }
        
    // ensure the band index is in proper range in case of bad input or memory operation
    if (CouplerSetNum < 0)   // constrain newBand
        CouplerSetNum = 0;   // something wrong if you end up here
    if (CouplerSetNum >= NUM_SETS)
        CouplerSetNum = NUM_SETS-1; // something wrong if you end up here
    NewBand = CouplerSetNum;
    
#ifdef NEXTION
    
    // Set up objects to monitor touch controls from Nextion Display
    CreateNexObject(savecfg_btn_1, page1_ID, savecfg_btn_1_ID, "savecfg_btn_1");
    CreateNexObject(savecfg_btn_2, page2_ID, savecfg_btn_2_ID, "savecfg_btn_2");
    CreateNexObject(savecfg_btn_4, page4_ID, savecfg_btn_4_ID, "savecfg_btn_4");
    CreateNexObject(fwd_cal, page1_ID, fwd_cal_ID, "fwd_cal");
    CreateNexObject(ref_cal, page1_ID, ref_cal_ID, "ref_cal");
    CreateNexObject(fwd_cal_num, page1_ID, fwd_cal_num_ID, "fwd_cal_num");  // slider
    CreateNexObject(ref_cal_num, page1_ID, ref_cal_num_ID, "ref_cal_num");  // slider
    CreateNexObject(f_att_minus, page1_ID, f_att_minus_ID, "f_att_minus");
    CreateNexObject(f_att_plus, page1_ID, f_att_plus_ID, "f_att_plus");
    CreateNexObject(r_att_minus, page1_ID, r_att_minus_ID, "r_att_minus");
    CreateNexObject(r_att_plus, page1_ID, r_att_plus_ID, "r_att_plus");
    CreateNexObject(toConfig, page0_ID, toConfig_ID, "toConfig");
    CreateNexObject(toSet1, page1_ID, toSet1_ID, "toSet1");
    CreateNexObject(toPwrGraph, page2_ID, toPwrGraph_ID, "toPwrGraph");
    CreateNexObject(toPowerCal, page3_ID, toPowerCal_ID, "toPowerCal");
    CreateNexObject(toMain, page4_ID, toMain_ID, "toMain");
    CreateNexObject(Main, page0_ID, Main_ID, "Main");
    CreateNexObject(Coupler, page1_ID, Coupler_ID, "Coupler");
    CreateNexObject(Set1, page2_ID, Set1_ID, "Set1");
    CreateNexObject(PwrGraph, page3_ID,PwrGraph_ID, "PwrGraph");
    CreateNexObject(PowerCal, page4_ID,PowerCal_ID, "PowerCal");
    CreateNexObject(FactoryRst1, page1_ID, FactoryRst1_ID, "FactoryRst1");
    CreateNexObject(FactoryRst2, page1_ID, FactoryRst2_ID, "FactoryRst2");
    CreateNexObject(Set1_Bandvar,page2_ID,Set1_Bandvar_ID,"Set1.Bandvar");
    CreateNexObject(hv_adj,page2_ID,hv_adj_ID,"hv_adj");  // slider
    CreateNexObject(v14_adj,page2_ID,v14_adj_ID,"v14_adj"); // slider
    CreateNexObject(curr_adj,page2_ID,curr_adj_ID,"curr_adj"); // slider
    CreateNexObject(temp_adj,page2_ID,temp_adj_ID,"temp_adj"); // slider
    CreateNexObject(hv_max,page2_ID,hv_max_ID,"hv_max");  
    CreateNexObject(v14_max,page2_ID,v14_max_ID,"v14_max"); 
    CreateNexObject(curr_max,page2_ID,curr_max_ID,"curr_max"); 
    CreateNexObject(temp_max,page2_ID,temp_max_ID,"temp_max");
    CreateNexObject(meterID,page2_ID,meterID_ID,"meterID"); 
    CreateNexObject(meterID_adj,page2_ID,meterID_adj_ID,"meterID_adj"); // slider
    CreateNexObject(band_set,page2_ID,band_set_ID,"band_set"); 
    CreateNexObject(band_set_adj,page2_ID,band_set_adj_ID,"band_set_adj"); // slider
    CreateNexObject(band, page0_ID, band_ID, "band");
    CreateNexObject(band_cal,page1_ID,band_cal_ID,"band_cal"); 
    CreateNexObject(fPwrGraph,page3_ID,fPwrGraph_ID,"fPwrGraph"); 
    CreateNexObject(fPwr_scale,page3_ID,fPwr_scale_ID,"fPwr_scale"); 
    CreateNexObject(fscale,page3_ID,fscale_ID,"fscale"); 
    CreateNexObject(rscale,page3_ID,rscale_ID,"rscale"); 
    CreateNexObject(fPwrNum,page3_ID,fPwrNum_ID,"fPwrNum"); 
    CreateNexObject(rPwrNum,page3_ID,rPwrNum_ID,"rPwrNum"); 
    CreateNexObject(swrNum,page3_ID,swrNum_ID,"swrNum");
    CreateNexObject(Graph_Timer,page3_ID,Graph_Timer_ID,"Graph_Timer");
    CreateNexObject(HPPwrTarget, page4_ID, HPPwrTarget_ID,"HPPwrTarget");
    CreateNexObject(LPPwrTarget, page4_ID, LPPwrTarget_ID,"LPPwrTarget");
    CreateNexObject(HP_F_VDC, page4_ID, HP_F_VDC_ID,"HP_F_VDC");
    CreateNexObject(HP_R_VDC, page4_ID, HP_R_VDC_ID,"HP_R_VDC");
    CreateNexObject(LP_F_VDC, page4_ID, LP_F_VDC_ID,"LP_F_VDC");
    CreateNexObject(LP_R_VDC, page4_ID, LP_R_VDC_ID,"LP_R_VDC");
    CreateNexObject(Measure_hi, page4_ID, Measure_hi_ID,"Measure_hi");
    CreateNexObject(Measure_lo, page4_ID, Measure_lo_ID,"Measure_lo");
    CreateNexObject(Units, page4_ID, Units_ID,"Units");
    CreateNexObject(CalcFwd, page4_ID, CalcFwd_ID,"CalcFwd");
    CreateNexObject(CalcRef, page4_ID, CalcRef_ID,"CalcRef");
    CreateNexObject(B_HF, page5_ID, B_HF_ID,"B_HF");
    CreateNexObject(B_50, page5_ID, B_50_ID,"B_50");
    CreateNexObject(B_144, page5_ID, B_144_ID,"B_144");
    CreateNexObject(B_222, page5_ID, B_222_ID,"B_222");
    CreateNexObject(B_432, page5_ID, B_432_ID,"B_432");
    CreateNexObject(B_902, page5_ID, B_902_ID,"B_902");
    CreateNexObject(B_1296, page5_ID, B_1296_ID,"B_1296");
    CreateNexObject(B_2_3G, page5_ID, B_2_3G_ID,"B_2_3G");
    CreateNexObject(B_3_4G, page5_ID, B_3_4G_ID,"B_3_4G");
    CreateNexObject(B_5_7G, page5_ID, B_5_7G_ID,"B_5_7G");
    CreateNexObject(B_10G, page5_ID, B_10G_ID,"B_10G");
    CreateNexObject(BandSel, page5_ID, BandSel_ID,"BandSel");
    CreateNexObject(toMain1, page5_ID, toMain1_ID, "toMain1");
    CreateNexObject(Aux1, page0_ID, Aux1_ID,"Aux1");
    CreateNexObject(Aux2, page0_ID, Aux2_ID,"Aux2");
    CreateNexObject(PTT_CW, page0_ID, PTT_CW_ID,"PTT_CW");
    
    // Set up Callback mappings
    NexTouch_attachPop(&savecfg_btn_1, savecfg_btn_1_pop_Callback, 0);   // all 3 page save cfg buttons do the same thing
    NexTouch_attachPush(&savecfg_btn_1, savecfg_btn_1_push_Callback, 0);  // so call the same functions
    NexTouch_attachPop(&savecfg_btn_2, savecfg_btn_1_pop_Callback, 0);
    NexTouch_attachPush(&savecfg_btn_2, savecfg_btn_1_push_Callback, 0);
    NexTouch_attachPop(&savecfg_btn_4, savecfg_btn_1_pop_Callback, 0);
    NexTouch_attachPush(&savecfg_btn_4, savecfg_btn_1_push_Callback, 0);
    NexTouch_attachPop(&fwd_cal, fwd_cal_pop_Callback, 0);
    NexTouch_attachPop(&ref_cal, ref_cal_pop_Callback, 0);
    NexTouch_attachPop(&toMain, toMain_push_Callback, 0);
    NexTouch_attachPop(&toMain1, toMain_push_Callback, 0);
    NexTouch_attachPop(&toConfig, toConfig_pop_Callback, 0);
    NexTouch_attachPop(&toSet1, Set1_Callback, 0); 
    NexTouch_attachPop(&toPwrGraph, toPwrGraph_Callback, 0); 
    NexTouch_attachPop(&f_att_minus, f_att_minus_pop_Callback, 0);
    NexTouch_attachPop(&f_att_plus, f_att_plus_pop_Callback, 0);
    NexTouch_attachPop(&r_att_minus, r_att_minus_pop_Callback, 0);
    NexTouch_attachPop(&r_att_plus, r_att_plus_pop_Callback, 0);
    NexTouch_attachPop(&FactoryRst1, FactoryRst1_pop_Callback, 0);
    NexTouch_attachPop(&FactoryRst2, FactoryRst2_pop_Callback, 0);
    NexTouch_attachPop(&meterID_adj, meterID_adj_pop_Callback, 0);
    NexTouch_attachPop(&band_set_adj, band_set_adj_pop_Callback, 0);
    //NexTouch_attachPop(&band, band_pop_Callback, 0);
    NexTouch_attachPop(&hv_adj, hv_adj_pop_Callback, 0);
    NexTouch_attachPop(&v14_adj, v14_adj_pop_Callback, 0);
    NexTouch_attachPop(&curr_adj, curr_adj_pop_Callback, 0);
    NexTouch_attachPop(&temp_adj, temp_adj_pop_Callback, 0);
    NexTouch_attachPop(&Measure_hi, Measure_hi_pop_Callback, 0);
    NexTouch_attachPop(&Measure_lo, Measure_lo_pop_Callback, 0);
    NexTouch_attachPop(&CalcFwd, CalcFwd_pop_Callback, 0);
    NexTouch_attachPop(&CalcRef, CalcRef_pop_Callback, 0);
    NexTouch_attachPop(&B_HF, BandSelect_HF_pop_Callback, 0);
    NexTouch_attachPop(&B_50, BandSelect_50_pop_Callback, 0);
    NexTouch_attachPop(&B_144, BandSelect_144_pop_Callback, 0);
    NexTouch_attachPop(&B_222, BandSelect_222_pop_Callback, 0);
    NexTouch_attachPop(&B_432, BandSelect_432_pop_Callback, 0);
    NexTouch_attachPop(&B_902, BandSelect_902_pop_Callback, 0);
    NexTouch_attachPop(&B_1296, BandSelect_1296_pop_Callback, 0);
    NexTouch_attachPop(&B_2_3G, BandSelect_2_3G_pop_Callback, 0);
    NexTouch_attachPop(&B_3_4G, BandSelect_3_4G_pop_Callback, 0);
    NexTouch_attachPop(&B_5_7G, BandSelect_5_7G_pop_Callback, 0);
    NexTouch_attachPop(&B_10G, BandSelect_10G_pop_Callback, 0);
    
    Nextion_Switch_Write(0);   // Switches the Nextion display serial port between the CPU and the USB converter (For display uploads via USB)
    // Ensure we are on Page 0 in cas we start and the display is already running such as during dev and test
    UART1_ClearRxBuffer();
    pg=0;
    nexInit();
    NexPage_show(&Main);
    strcpy(cmd,Band_Cal_Table[CouplerSetNum].BandName);
    NexText_setText(&Set1_Bandvar);    // Update Nextion display for new values
    NexButton_setText(&band, Band_Cal_Table[CouplerSetNum].BandName);
    sprintf(cmd, " ");  // Clear the RX/TX/CW satus field until we get a valid OTRSP command otherwise
    NexText_setText(&PTT_CW);  // Get PTT first.  If CW present then next line will overwrite
    NexText_Set_font_color_pco(&PTT_CW, 2016);  // Set text to LT Green for RX
    NexText_Set_background_color_bco(&PTT_CW, 0);  // Set background color to black for RX
    NexSlider_setMaxval(&band_set_adj, (uint32_t) NUM_SETS);  // Ensure the control know the same num bands the host does.
    Set1_Callback(0);  // initialize our setpoints and meter id so it does not get read back as 0 values later.
    NexPage_show(&Main);
    NexNumber_setValue(&Graph_Timer, 500);   // 300msec for graph update rate.  300 set in display, can override here.

                                // 0 = CPU, 1 = USB converter
#endif // end Nextion setup section 
   
    // Flash some lights to show we are a go
    LED_Write(1);
    LED_1_Write(1);
    CyDelay(1000);
    LED_Write(0);
    LED_1_Write(0);
    adRead(); //get and calculate power + SWR values and display them        
}

int main(void)
{   
    uint8_t ret1;

    setup();
    
    while (1) 
    {
        // Listen for remote computer commands                
        serial_usb_read();  // fetch latest data in buffer                                      
        if (rx_count!=0)
            get_remote_cmd();       // scan buffer for command strings
            
        if (Button_A == YES) {   // Do a press and hold to display reflected power on analog meter. 
            Button_A = NO; //reset flag
            if (op_mode != PWR) {
                // coming from some other op_mode, redraw the screen for PWR op_mode
                op_mode = PWR;  
            }                  
            // Save to EEPROM             
            EE_Save_State();            
        }
        if (Button_B == YES) {      // Select Cal Band
            //++CouplerSetNum;   // increment for manual button pushes
            if (NewBand < 0)   // constrain newBand            
            {
                NewBand = 0;   // something wrong if you end up here                        
                CyDelay(1);
            }
            if (NewBand >= NUM_SETS)
                NewBand = NUM_SETS-1; // something wrong if you end up here
            CouplerSetNum = NewBand;    // set to commanded band.  If a Button B remote cmd, NewBand wil lbe incremented before here                            
            if (CouplerSetNum > NUM_SETS)
                CouplerSetNum = 0;                      
            Button_B = NO; //reset flag
            Cal_Table();  
            
#ifdef NEXTION
            strcpy(cmd,Band_Cal_Table[CouplerSetNum].BandName);
            NexText_setText(&Set1_Bandvar);    // Update Nextion display for new values            
            toConfig_pop_Callback(0);  // when on the Config pages will update them
            Set1_Callback(0);   
            update_Nextion(1);                        
#endif       

            EE_Save_State();
        }
        if (Button_C == YES) 
        {
            Button_C = NO; //reset flag
            if (op_mode != SWR)  {
                op_mode = SWR;              
                EE_Save_State();
            }
        }
        
        adRead(); //get and calculate power + SWR values and display them        
        
#ifdef SSD1306_OLED
        // Process OLED Display if used
        OLED();  // Update display for all params
#endif 
        
#ifdef NEXTION
        // Process Nextion Display events
        //Serial_PullMsg(0);                  
        //if (EVT_FLAG) 
        if (Serial_Available()) 
            nexLoop(nex_listen_list);  // Process Nextion Display  
        if (NewBand != CouplerSetNum)
            update_Nextion(1);
        else if (!WAIT)   // skip if waiting for response from a diaplsy query to reduce traffic
            update_Nextion(0);    
#endif

        uint16 ret16;
        // N1MM CW and PTT and AUX message handling
        ret16 = Serial_USB_GetLineControl();    // look for DTR and RTS for N1MM control of CW and PTT. 
                                                // Can only happen on USB serial since the external USB UART has only TX and RX lines connected to CPU
        // Check state of USB Serial Port DTR register for N1MM CW keying state
        if ((uint8_t)ret16 & Serial_USB_LINE_CONTROL_DTR)                    
            CW_Key_Out_Write(1);          
        else
            CW_Key_Out_Write(0);                       
        // Check state of USB Serial Port RTS register for N1MM PTT state
        if ((uint8_t)ret16 & Serial_USB_LINE_CONTROL_RTS)     
            PTT_Out_Write(1);        
        else
            PTT_Out_Write(0);       
  
        ret1 = OTRSP();   // set Aux output pins and change bands to match
        if (ret1)
        {
            Button_B = YES;  // Process any N1M Aux port commands on UART2
            NewBand = AuxNum1;
        }                
        // Process any radio band decoder changes
        Band_Decoder();
        
    }   // end of while
}

void Band_Decoder(void)
{     
    // Convert BCD to binary and update the (non-BCD) binary Port for amps and meter selection
    uint8 decoder_band;
    uint8 decoder_band_binary;

    decoder_band = Band_BCD_In_Reg_Read();   // Get current radio band value
    if (decoder_band != decoder_band_last)
    {
        decoder_band_last = decoder_band;
        if (decoder_band == 0) // if 0 it is HF
        {
            Band_Decode_Control_Write(0);  // Deselect the amps and antennas if possible and avold divide by zero
            Antenna_Select_Write(0);
        }   
        else
        {   // not zero (not HF) pick a VHF band now
            decoder_band = BCDToDecimal(decoder_band);   
            if (decoder_band > 6)
                decoder_band = 6;
            decoder_band_binary = (1 << (decoder_band-1));
            Band_Decode_Control_Write(decoder_band_binary);   // Convert BCD to parallel    
            // Based on band selected, also send out teh antenna select pattern. 
            // This is hard coded today for 3 SPDT relays to select one of 4 RF sources to connect to an antenna 
            switch(decoder_band)
            {   // writing a 1 will cause a ground (logic 0) to be applied to the latching relay board to move it to position 2.
                case 0: Antenna_Select_Write(0); 
                    break;        // HF  - move all switches to position #1
                case 1: Antenna_Select_Write(0); 
                    break;        // 50  - move all switches to position #1
                case 2: Antenna_Select_Write(0); 
                    break;        // 144 - move pair A to #1, B to #1
                case 3: Antenna_Select_Write(1); 
                    break;        // 222 - move pair A to #2, B to #1
                case 4: Antenna_Select_Write(2); 
                    break;        // 432 - move pair A to #1, B to #2
                case 5: Antenna_Select_Write(3); 
                    break;        // 903 - move pair A to #2, B to #2
                case 6: Antenna_Select_Write(0); 
                    break;        // 1296 - move all switches to position #1
                default: Antenna_Select_Write(0);
                    break;                
            }
        }
    }
}   
        
uint8 BCDToDecimal(uint8 BCD)
{
   return (((BCD>>4)*10) + (BCD & 0xF));
}

#ifdef NEXTION
    
void hv_adj_pop_Callback(void *ptr)
{
    uint32_t number;    
    ptr += 1; // get rid of compiler error about unused ptr    
    NexSlider_getValue(&hv_adj, &number);
    // Change meter ID with this info
    set_hv_max = number;
    set_hv_max /= 10.0;
    NexSlider_setValue(&hv_adj, (uint16_t) (set_hv_max*10));
}

void v14_adj_pop_Callback(void *ptr)
{
    uint32_t number;
    ptr += 1; // get rid of compiler error about unused ptr    
    NexSlider_getValue(&v14_adj, &number);
    // Change meter ID with this info
    set_v14_max = number;
    set_v14_max /= 10.0;
    NexSlider_setValue(&v14_adj, (uint16_t) (set_v14_max*10));
}

void curr_adj_pop_Callback(void *ptr)
{
    uint32_t number;    
    ptr += 1; // get rid of compiler error about unused ptr    
    NexSlider_getValue(&curr_adj, &number);
    // Change meter ID with this info
    set_curr_max = number;
    set_curr_max /= 10;
    NexSlider_setValue(&curr_adj, (uint16_t) (set_curr_max*10));

}  

void temp_adj_pop_Callback(void *ptr)
{
    uint32_t number;    
    
    ptr += 1; // get rid of compiler error about unused ptr    
    NexSlider_getValue(&temp_adj, &number);
    // Change meter ID with this info
    set_temp_max = (uint8_t)number;
    NexSlider_setValue(&temp_adj, (uint8_t) (set_temp_max));
}  
  
void band_set_adj_pop_Callback(void *ptr)
{
    uint32_t number;    
    ptr += 1; // get rid of compiler error about unused ptr    
    NexSlider_getValue(&band_set_adj, &number); 
    NewBand = (uint8_t) number;   // get input for new band from Set1 page
    Button_B = YES; // set flag for main loop to process band change request.  
    // If there is a connection to radio (via serial or wireless) then it will override this at each update.                                                               
}

void band_pop_Callback(void *ptr) 
{
    char buf[32];    
    ptr += 1; // get rid of compiler error about unused ptr        
    //CouplerSetNum = constrain(CouplerSetNum, 0, NUM_SETS);  
    //NewBand = CouplerSetNum +1;    // Update Newband to current value.  Will be incrmented in button function                          
    //if (NewBand >= NUM_SETS) 
   //     NewBand = 0;  // cycle back to lowest band
    //Button_B = YES; // set flag for main loop to process band change request.  
    // If there is a connection to radio (via serial or wireless) then it will override this at each update.   
    NexButton_setText(&band, itoa(CouplerSetNum, buf, 10)); 
    pg=5;
}

void BandSelect_HF_pop_Callback(void *ptr)   // Get var BandSel assigned by each band button to set NewBand var
{
    ptr += 1; // get rid of compiler error about unused ptr 
    BandSelect(0);
}

void BandSelect_50_pop_Callback(void *ptr)   // Get var BandSel assigned by each band button to set NewBand var
{
    ptr += 1; // get rid of compiler error about unused ptr     
    BandSelect(1);
}

void BandSelect_144_pop_Callback(void *ptr)   // Get var BandSel assigned by each band button to set NewBand var
{
    ptr += 1; // get rid of compiler error about unused ptr     
    BandSelect(2);
}

void BandSelect_222_pop_Callback(void *ptr)   // Get var BandSel assigned by each band button to set NewBand var
{
    ptr += 1; // get rid of compiler error about unused ptr     
    BandSelect(3);
}

void BandSelect_432_pop_Callback(void *ptr)   // Get var BandSel assigned by each band button to set NewBand var
{
    ptr += 1; // get rid of compiler error about unused ptr     
    BandSelect(4);
}

void BandSelect_902_pop_Callback(void *ptr)   // Get var BandSel assigned by each band button to set NewBand var
{
    ptr += 1; // get rid of compiler error about unused ptr     
    BandSelect(5);
}

void BandSelect_1296_pop_Callback(void *ptr)   // Get var BandSel assigned by each band button to set NewBand var
{
    ptr += 1; // get rid of compiler error about unused ptr     
    BandSelect(6);
}

void BandSelect_2_3G_pop_Callback(void *ptr)   // Get var BandSel assigned by each band button to set NewBand var
{
    ptr += 1; // get rid of compiler error about unused ptr     
    BandSelect(7);
}

void BandSelect_3_4G_pop_Callback(void *ptr)   // Get var BandSel assigned by each band button to set NewBand var
{
    ptr += 1; // get rid of compiler error about unused ptr     
    BandSelect(8);
}

void BandSelect_5_7G_pop_Callback(void *ptr)   // Get var BandSel assigned by each band button to set NewBand var
{
    ptr += 1; // get rid of compiler error about unused ptr     
    BandSelect(9);
}

void BandSelect_10G_pop_Callback(void *ptr)   // Get var BandSel assigned by each band button to set NewBand var
{
    ptr += 1; // get rid of compiler error about unused ptr 
    BandSelect(10);
}

void BandSelect(uint8_t sband)   // Get var BandSel assigned by each band button to set NewBand var
{
    //uint32_t number;
    char buf[32];
    //NexNumber_getValue(&BandSel,&number);        
    NewBand = sband;    // Update Newband to current value.  Will be incremented in button function
    if (NewBand >= NUM_SETS) 
        NewBand = 0;  // cycle back to lowest band
    Button_B = YES; // set flag for main loop to process band change request.  
    // If there is a connection to radio (via serial or wireless) then it will override this at each update.   
    NexButton_setText(&band, itoa(NewBand, buf, 10));
    pg=0;
    update_Nextion(1);
}

void Measure_hi_pop_Callback(void *ptr)
{   
    uint32_t number; 
    ptr += 1; // get rid of compiler error about unused ptr
    //NexButton_setText(&savecfg_button, "Saved Config");
    NexNumber_getValue(&HPPwrTarget, &number);
    Pwr_hi = number;
    NexNumber_getValue(&Units, &number);
    if (number==0)  // convert to dBm if in Watts (0 value)
    {
        // Get target lo power level from user in Watts, convert to dBm then measure and save ADC                                
           Pwr_hi = 10 * log10(1000*(Pwr_hi/1));
    }  
    // Now value is in dBm proceed
    adRead();  // update our high power readings for forward and reflected power for the current band
    FwdVal_hi = FwdVal; // save for calc     
    NexNumber_setValue(&HP_F_VDC, (int)(FwdVal_hi*100000));  // display ADC raw voltage on screen
    RefVal_hi = RefVal;  // save for calc    
    NexNumber_setValue(&HP_R_VDC, (int)(RefVal_hi*100000));
    print_Cal_Table_progress(1);  // end of loop   
}

void Measure_lo_pop_Callback(void *ptr)
{   
    uint32_t number;  
    ptr += 1; // get rid of compiler error about unused ptr
    //NexButton_setText(&savecfg_button, "Saved Config");
    NexNumber_getValue(&LPPwrTarget, &number);
    Pwr_lo = number;        
    NexNumber_getValue(&Units, &number);
    if (number==0)
    {
        // Get target lo power level from user in Watts, convert to dBm then measure and save ADC                                
           Pwr_lo = 10 * log10(1000*(Pwr_lo/1));
    }
    // Now value is in dBm proceed
    adRead();  // update our high power readings for foprward and reflected power for the current band
    FwdVal_lo = FwdVal; // save for calc  
    NexNumber_setValue(&LP_F_VDC, (int)(FwdVal_lo*100000));
    RefVal_lo = RefVal;  // save for calc    
    NexNumber_setValue(&LP_R_VDC, (int)(RefVal_lo*100000));
    print_Cal_Table_progress(1);  // end of loop
}

void CalcFwd_pop_Callback(void *ptr)
{
    ptr += 1; // get rid of compiler error about unused ptr 
    if (Pwr_hi != 0) // ensure we have a valid high power number before calculating.
    {                      
        // Calculate Slope and Offset
        Slope_F = (FwdVal_hi - FwdVal_lo)/(Pwr_hi - Pwr_lo);
        Offset_F = FwdVal_hi + ((CouplingFactor_Fwd - Pwr_hi) * Slope_F);
        Cal_Table_write();
        Cal_Table();  // read back to be sure it save correctly                                
        print_Cal_Table_progress(0);  // end of loop
    }
}

void CalcRef_pop_Callback(void *ptr)
{
    ptr += 1; // get rid of compiler error about unused ptr 
    if (Pwr_hi != 0) // ensure we have a valid high power number before calculating.
    {                             
        // Calculate Slope and Offset
        Slope_R = (RefVal_hi - RefVal_lo)/(Pwr_hi - Pwr_lo);
        Offset_R = RefVal_hi + ((CouplingFactor_Ref - Pwr_hi) * Slope_R);
        Cal_Table_write();
        Cal_Table();  // read back to be sure it save correctly
        print_Cal_Table_progress(0);  // end of loop
    }
}

void meterID_adj_pop_Callback(void *ptr)
{
    uint32_t number;    
    ptr += 1; // get rid of compiler error about unused ptr    
    NexSlider_getValue(&meterID, &number);
    // Change meter ID with this info
    METERID = number;
}   
    
void FactoryRst1_pop_Callback(void *ptr)
{    
    ptr += 1; // get rid of compiler error about unused ptr    
    // Sequenctionally pressing thse adn Rst2 hotspot areas is the same as 2 button reset of M5Stack or remote commands 193+195
    Reset_Flag = 1;
}

void FactoryRst2_pop_Callback(void *ptr)
{
    ptr += 1; // get rid of compiler error about unused ptr
    if (Reset_Flag == 1) 
        reset_EEPROM();
        CyDelay(1000);
        toConfig_pop_Callback(0);
        update_Nextion(1);
    Reset_Flag = 0;
}

void savecfg_btn_1_push_Callback(void *ptr)
{    
    ptr += 1; // get rid of compiler error about unused ptr
    //NexButton_setText(&savecfg_button, "Saving");
    LED_Write(0);
    LED_1_Write(0);
    CyDelay(200);
    LED_Write(1);
    LED_1_Write(1);
    EE_Save_State();  // push the button to commit the cal changes - Watch LED to see how long the EEPROM really takes.
    // There is 2 seconds total delay on the Nextion save config button to allow time for the CPU to finish loaded.    
    LED_Write(0);    // write to both ports for KitProg and Main Board onboard LEDs
    LED_1_Write(0);
}

void savecfg_btn_1_pop_Callback(void *ptr)
{   
    ptr += 1; // get rid of compiler error about unused ptr
    //NexButton_setText(&savecfg_button, "Saved Config");
    LED_Write(1);    // write to both ports for KitProg and Main Board onboard LEDs
    LED_1_Write(1);
}

void fwd_cal_pop_Callback(void *ptr) // Slider for Fwd Coupler Cal Value
{      
    ptr += 1; // get rid of compiler error about unused ptr   
    // Read value of slider sent in event and set in Cal table then echo it back to textbox
    NexSlider_getValue(&fwd_cal, &rcv_num); ;
    Band_Cal_Table[CouplerSetNum].Cpl_Fwd = rcv_num;
    sprintf(cmd, "%.1fdB%c", Band_Cal_Table[CouplerSetNum].Cpl_Fwd, '\0');  // Update lable with decimal value text
    NexText_setText(&fwd_cal_num);    
    Cal_Table();
    toConfig_pop_Callback(0);
}

void ref_cal_pop_Callback(void *ptr) // Slider for Ref Coupler Cal Value
{
    ptr += 1; // get rid of compiler error about unused ptr
    // Read value of slider sent in event and set in Cal table then echo it back to textbox
    NexSlider_getValue(&ref_cal, &rcv_num);  
    Band_Cal_Table[CouplerSetNum].Cpl_Ref = rcv_num;    
    sprintf(cmd, "%.1fdB%c", Band_Cal_Table[CouplerSetNum].Cpl_Ref, '\0');  // Update lable with decimal value text
    NexText_setText(&ref_cal_num);    
    Cal_Table();
    toConfig_pop_Callback(0);
}

void f_att_minus_pop_Callback(void *ptr) // fine tune slider by 0.1dB
{
    ptr += 1; // get rid of compiler error about unused ptr
    Band_Cal_Table[CouplerSetNum].Cpl_Fwd -= 0.1;
    sprintf(cmd, "%.1fdB%c", Band_Cal_Table[CouplerSetNum].Cpl_Fwd, '\0');  // Update lable with decimal value text
    NexText_setText(&fwd_cal_num);     
    Cal_Table();
}

void f_att_plus_pop_Callback(void *ptr)
{    
    ptr += 1; // get rid of compiler error about unused ptr          
    Band_Cal_Table[CouplerSetNum].Cpl_Fwd += 0.1;    
    sprintf(cmd, "%.1fdB%c", Band_Cal_Table[CouplerSetNum].Cpl_Fwd, '\0');  // Update lable with decimal value text
    NexText_setText(&fwd_cal_num);    
    Cal_Table();
}

void r_att_minus_pop_Callback(void *ptr)
{      
    ptr += 1; // get rid of compiler error about unused ptr    
    Band_Cal_Table[CouplerSetNum].Cpl_Ref -= 0.1;
    sprintf(cmd, "%.1fdB%c", Band_Cal_Table[CouplerSetNum].Cpl_Ref, '\0');  // Update lable with decimal value text
    NexText_setText(&ref_cal_num); 
    Cal_Table();
}

void r_att_plus_pop_Callback(void *ptr)
{
    ptr += 1; // get rid of compiler error about unused ptr   
    Band_Cal_Table[CouplerSetNum].Cpl_Ref += 0.1;    
    sprintf(cmd, "%.1fdB%c", Band_Cal_Table[CouplerSetNum].Cpl_Ref, '\0');  // Update lable with decimal value text
    NexText_setText(&ref_cal_num); 
    Cal_Table();
}

void toMain_push_Callback(void *ptr)
{
    ptr += 1; // get rid of compiler error about unused ptr
    pg = 0;   // flag Update function to only update when page is active 
    update_Nextion(1);
    //NexPage_show(&page0);
}

void toConfig_pop_Callback(void *ptr)   // Got event to change to Config Page from somewhere
{
    //uint8_t number;
    //uint8_t ret1;    
    ptr += 1; // get rid of compiler error about unused ptr
    
    // Update the sliders to current values. SLider callbacks wil update after here.
    //strcpy(cmd, "sendme");
    //sendCommand(cmd);
    //CyDelay(2);
    //ret1 = recvPageNumber(&number);    
    //if ((ret1 == 1) && (number = 1))  // ensure we are on the correct page)
    if (1 == 1)  // force to true, should only be in this fucntion if a page event sent us to here
    {       
        rcv_num = (uint32_t)(Band_Cal_Table[CouplerSetNum].Cpl_Fwd);
        NexSlider_setValue(&fwd_cal, rcv_num);  // Update slider knob position  0-100
         
        snprintf(cmd, 21, "%.1fdB%c", Band_Cal_Table[CouplerSetNum].Cpl_Fwd, '\0');  // Update label with decimal value text
        NexText_setText(&fwd_cal_num);
      
        // Initialize the sliders to the current band value for Reflected
        rcv_num = Band_Cal_Table[CouplerSetNum].Cpl_Ref;
        NexSlider_setValue(&ref_cal, rcv_num);
        
        snprintf(cmd, 20, "%.1fdB%c", Band_Cal_Table[CouplerSetNum].Cpl_Ref, '\0');  // Update label with decimal value text
        NexText_setText(&ref_cal_num);       
    }
}

/*
 *      Setpoints page on graphics display where alarm levels for things like voltage and temp are set.  
 *      These are globals so in theory do nto have to be on teh page to write to them
 *      Includes the unused *ptr so this can be used as a callback function if needed.
*/
void Set1_Callback(void *ptr)
{   
    //uint8_t number;
    ptr += 1; // get rid of compiler error about unused ptr
    
    /*
    if (pg != 1)
    {
        strcpy(cmd, "sendme");
        sendCommand(cmd);    
        //CyDelay(10);
        if (!recvPageNumber(&number))
            return;
    }
    */
    //if (number == 2 || pg == 2) // only send this group of data while on page 2
    if (pg == 1)  // should only be here because a touch event called us.
    {
        //NexPage_show(&Set1);
        CyDelay(25);
        ptr += 1; // get rid of compiler error about unused ptr
        // The XYZ_max fields are considered the source for the slider to get its initial data from through the     
        //    the display's "Setpoints" page (page2) preinitialization section. After that the slider sends changes real time to the display
        //    not bothering the CPU until movement stops when an event is sent to the CPU where the slider callback will 
        //    get the XYZ_max value and store it in EEPROM.
        // For xfloat type object in Nextion, multiply the float x10 to get an integer it can use with teh slider
        // The display will format it with decimal point according to its config (num places to left and right of decimal point)
        NexSlider_setValue(&hv_adj, (uint16_t) (set_hv_max*10));
        NexNumber_setValue(&hv_max, (uint16_t) (set_hv_max*10));

        NexSlider_setValue(&v14_adj, (uint16_t) (set_v14_max*10));
        NexNumber_setValue(&v14_max, (uint16_t) (set_v14_max*10));

        NexSlider_setValue(&curr_adj, (uint16_t) (set_curr_max*10));
        NexNumber_setValue(&curr_max, (uint16_t) (set_curr_max*10));

        NexSlider_setValue(&temp_adj, (uint16_t) set_temp_max);
        NexNumber_setValue(&temp_max, (uint16_t) set_temp_max);
       
        NexSlider_setValue(&meterID_adj, METERID);
        NexNumber_setValue(&meterID, (uint16_t) METERID);
        
        // fix up initial position of slider knob for Band Slider
        NexSlider_setValue(&band_set_adj, CouplerSetNum);
        strcpy(cmd, Band_Cal_Table[CouplerSetNum].BandName);
        NexText_setText(&band_set);    
        strcpy(cmd, Band_Cal_Table[CouplerSetNum].BandName);
        NexText_setText(&band_cal);    
    }
}

void toPwrGraph_Callback(void *ptr)
{
    ptr += 1; // get rid of compiler error about unused ptr
    pg=3;
    return;
}

uint8_t update_Nextion(uint8 force_update)
{
    static float32 d;
    uint8_t temp_value_old = 0, set_temp_max_old = 0;
    float value;
    uint32_t number32;
    //uint8 ret;
    static float32 FwdPwr_old, RefPwr_old, SWRVal_old, hv_value_old, V14_value_old, curr_value_old, Fwd_dBm_old, Ref_dBm_old;
    static uint8_t AuxNum1_old, AuxNum2_old, NewBand_old;
    static float32 set_curr_max_old, set_hv_max_old, set_v14_max_old;
      
    if (!force_update)
    {
        // throttle update rate
        if (DLY < 5)
            d = 5;
        else 
            d= DLY/5;
        if ((Timer_X00ms_InterruptCnt - Timer_X00ms_Last_Nex) < d)
           return 0;   // skip out until greater than 100ms since our last visit here
        Timer_X00ms_Last_Nex = Timer_X00ms_InterruptCnt;
  /*      if (pg != number)
        {
            strcpy(cmd, "sendme");
            sendCommand(cmd);
        
            CyDelay(5);
            ret = recvPageNumber(&number);
            if (ret == 1)  // good page num returned
                pg = number;    // else just skip this and use the pg value
        }
        */
    }
    else
    {
        // force all status tracking variables to 0 forcing them to update on this pass.
        //FwdPwr_old=RefPwr_old=SWRVal_old=hv_value_old=V14_value_old=temp_value_old=curr_value_old=NewBand_old=0;
    }
    
    // use page number to refresh each applicable page
    if (force_update || pg == 0) // only send this group of data while on page 0 every 250 ms at most
    { 
        // only send these Page 0 commands if we are on page 0 else we will get invalid data return messages
        // Update float fields on display        
        if (round(FwdPwr*16) != round(FwdPwr_old*16) && !WAIT)
        {
            FwdPwr_old = FwdPwr;
            if (FwdPwr > 9999.99)
                sprintf(cmd, "fwdpwr.txt=\"OVER\"");
            else if (FwdPwr > 99.99)
                sprintf(cmd, "fwdpwr.txt=\"%.0fW\"", FwdPwr);
            else
                sprintf(cmd, "fwdpwr.txt=\"%.1fW\"", FwdPwr);
            //NexText_setText(FwdPwr, cmd);   // alternative way to update val;ue using the library commands
            sendCommand(cmd);
        }
        if (round(RefPwr*16) != round(RefPwr_old*16) && !WAIT)
        {   
            RefPwr_old = RefPwr;
            if (RefPwr > 999.99)
                sprintf(cmd, "refpwr.txt=\"OVER\"");
            else if (RefPwr > 99.9)
                sprintf(cmd, "refpwr.txt=\"%.0fW\"", RefPwr);
            else
                sprintf(cmd, "refpwr.txt=\"%.1fW\"", RefPwr);
            sendCommand(cmd);
        }    
        
        if (round(Fwd_dBm*16) != round(Fwd_dBm_old*16) && !WAIT)
        {   
            Fwd_dBm_old = Fwd_dBm;
            sprintf(cmd, "FdBm.txt=\"%.2fdBm\"", Fwd_dBm);
            sendCommand(cmd);
        }
        
        if (round(Ref_dBm*16) != round(Ref_dBm_old*16) && !WAIT)
        {   
            Ref_dBm_old = Ref_dBm;
            sprintf(cmd, "RdBm.txt=\"%.2fdBm\"", Ref_dBm);
            sendCommand(cmd);        
        }
        
        if  (SWRVal != SWRVal_old && !WAIT)
        {
            SWRVal_old = SWRVal;
            value = SWRVal;
            if (value > 99.9)      // Display Overrange
            {
                sprintf(cmd, "SWR.txt=\"%s\"", "OVR");
                sendCommand(cmd);
                sprintf(cmd, "SWR.pco=63488");   // Red Text
                sendCommand(cmd);
            }
            else if (value > 2.0)      // Display Overrange
            {
                sprintf(cmd, "SWR.txt=\"%.1f\"", value);
                sendCommand(cmd);
                sprintf(cmd, "SWR.pco=63488");   // Red Text
                sendCommand(cmd);
            }
            else if (value < 0.002)    // Display greyed out NA
            {
                sprintf(cmd, "SWR.txt=\"%s\"", "NA");
                sendCommand(cmd);
                sprintf(cmd, "SWR.pco=50712");   // Flip value to grey
                sendCommand(cmd);
            }   
            else   // Display normal value
            {
                sprintf(cmd, "SWR.txt=\"%.1f\"", value);
                sendCommand(cmd);
                sprintf(cmd, "SWR.pco=65504");   // Flip value to normal yellow    
                sendCommand(cmd);  
            }
        }

        value = hv_read();   // convert to full ADC read function - this is temp for now.        
        if ((round(value*16) != round(hv_value_old*16) || set_hv_max_old != set_hv_max) && !WAIT)
        {
            hv_value_old = value;
            set_hv_max_old = set_hv_max;      
            if (value > set_hv_max)       
            {
                sprintf(cmd, "hv.pco=63488");   // Flip value to Red for high alert            
                sendCommand(cmd);        
            }
            else
            {
                sprintf(cmd, "hv.pco=2016");   // Flip value to normal yellow
                sendCommand(cmd);
            }
            sprintf(cmd, "hv.txt=\"%.1fV\"", value);
            sendCommand(cmd); 
        }
        
        value = v14_read();        
        if ((round(value*16) != round(V14_value_old*16) || set_v14_max_old != set_v14_max) && !WAIT)
        {
            V14_value_old = value;
            set_v14_max_old = set_v14_max;
            if (value > set_v14_max)
            {
                sprintf(cmd, "v14.pco=63488");   // Flip value to Red for high alert            
                sendCommand(cmd);
            }
            else
            {
                sprintf(cmd, "v14.pco=2016");   // Flip value to normal Yellow #65504                  
                sendCommand(cmd);
            }
            sprintf(cmd, "v14.txt=\"%.1fV\"", value);        
            sendCommand(cmd);
        }
           
        value = curr_read();    
        if  ((round(value*16) != round(curr_value_old*16) || set_curr_max_old != set_curr_max) && !WAIT)
        {
            curr_value_old = value;
            set_curr_max_old = set_curr_max;
            if (value > set_curr_max)
            {        
                sprintf(cmd, "curr.pco=63488");   // Flip value to Red for high alert            
                sendCommand(cmd); 
            } 
            else
            {
                sprintf(cmd, "curr.pco=2016");   // Flip value to normal Yellow #65504                  
                sendCommand(cmd); 
            }
            sprintf(cmd, "curr.txt=\"%.1fA\"", value);
            sendCommand(cmd); 
        }
        
        value = temp_read();
        if  ((round(value*16) != round(temp_value_old*16) || set_temp_max_old != set_temp_max) && !WAIT)
        {
            temp_value_old = value;
            set_temp_max_old = set_temp_max;
            if (value > set_temp_max)
            {        
                sprintf(cmd, "temp.pco=63488");   // Flip value to Red for high alert            
                sendCommand(cmd); 
            } 
            else
            {
                sprintf(cmd, "temp.pco=2016");   // Flip value to normal Yellow #65504                  
                sendCommand(cmd); 
            }
            sprintf(cmd, "temp.txt=\"%.1fF\"", value);
            sendCommand(cmd); 
        }              
             
        if (force_update == 1)
        {
            sprintf(cmd, "band.txt=\"%s\"", Band_Cal_Table[NewBand].BandName);
            sendCommand(cmd); 
            
            strcpy(cmd,Band_Cal_Table[NewBand].BandName);
            NexText_setText(&Set1_Bandvar);      
        }
        else
        {
            sprintf(cmd, "band.txt=\"%s\"", Band_Cal_Table[CouplerSetNum].BandName);
            sendCommand(cmd); 
            
            strcpy(cmd,Band_Cal_Table[CouplerSetNum].BandName);
            NexText_setText(&Set1_Bandvar);      
        }
        
        if (NewBand_old != CouplerSetNum || force_update == 1)
        {
            NewBand_old = CouplerSetNum;            
            sprintf(cmd, "band.pco=65535");   // Flip value white
            sendCommand(cmd);            
            sprintf(cmd, "band.bco=20");   // Flip value to dark blue = background
            sendCommand(cmd);
            if (CouplerSetNum == 0)
                CyDelay(1);
        }
        
        // Update Display for state of AUX 1 and 2 ports
        if ((AuxNum1 != AuxNum1_old || force_update == 1) && !WAIT)
        {
            AuxNum1_old = AuxNum1;
            number32 = (uint32_t) AuxNum1;
            NexNumber_setValue(&Aux1, number32);
        }
        if ((AuxNum2 != AuxNum2_old || force_update == 1) && !WAIT)
        {
            AuxNum2_old = AuxNum2;    
            number32 = (uint32_t) AuxNum2;
            NexNumber_setValue(&Aux2, number32);
        } 
        
        // Update display for state of PTT and CW IO lines
        uint8 state;
        state = Serial_USB_IsLineChanged();              /* Check for Line settings changed */
        if(state != 0u)
        {  
            if(state & Serial_USB_LINE_CONTROL_CHANGED)  /* Show new settings */
            {   
                state = Serial_USB_GetLineControl();
                if (((state & Serial_USB_LINE_CONTROL_RTS) == 2) && ((state & Serial_USB_LINE_CONTROL_DTR) == 0)) // PTT on and CW off
                {
                    sprintf(cmd, "TX");
                    NexText_setText(&PTT_CW);  // Get PTT first.  If CW present then next line will overwrite
                    NexText_Set_font_color_pco(&PTT_CW, 65504);  // Set text to Yellow for tx                    
                    NexText_Set_background_color_bco(&PTT_CW, 63488);  // Set bkgnd to RED for tx                    
                }
                else if (((state & Serial_USB_LINE_CONTROL_RTS) == 0) && ((state & Serial_USB_LINE_CONTROL_DTR) == 0)) // PTT on and CW off
                {
                    sprintf(cmd, "RX");
                    NexText_setText(&PTT_CW);  // Get PTT first.  If CW present then next line will overwrite
                    NexText_Set_font_color_pco(&PTT_CW, 2016);  // Set text to LT Green for RX
                    NexText_Set_background_color_bco(&PTT_CW, 0);  // Set background color to black for RX
                }                                        
                if (((state & Serial_USB_LINE_CONTROL_RTS) == 2) && ((state & Serial_USB_LINE_CONTROL_DTR) == 1)) // PTT on and CW off
                {
                    sprintf(cmd, "CW");
                    NexText_setText(&PTT_CW);  // Get PTT first.  If CW present then next line will overwrite
                    NexText_Set_font_color_pco(&PTT_CW, 2047);  // Set text to RED for tx  
                    NexText_Set_background_color_bco(&PTT_CW, 63488);  // Set background color to black for RX                  
                }
                else if (((state & Serial_USB_LINE_CONTROL_RTS) == 0) && ((state & Serial_USB_LINE_CONTROL_DTR) == 1)) // PTT on and CW off
                {
                    sprintf(cmd, "CW");
                    NexText_setText(&PTT_CW);  // Get PTT first.  If CW present then next line will overwrite
                    NexText_Set_font_color_pco(&PTT_CW, 2047);  // Set text to REd for TX.  Then check PTT again for RX state
                    NexText_Set_background_color_bco(&PTT_CW, 0);  // Set background color to black for RX
                }
            }
        }  
        return 1;
    }
    else if (pg == 3) // only send this group of data while on page 3
    {   // Page 3 is the Graphing page
        // Post up power and SWR values.  Display will read the values on a timer and update teh graph.  
        // It will also read the scale and cap the values to the scale max and scale the graph with its own math        
        
        if (FwdPwr > 1999.9)        
        {                                 
            NexNumber_setValue(&fPwrNum,1999); 
        }
        else
            NexNumber_setValue(&fPwrNum,FwdPwr);
            
        if (RefPwr > 999.9)        
        {   // graphing only accepts integer betwen 0 and 255. using 1000W max                    
            NexNumber_setValue(&rPwrNum,999); 
        }
        else
            NexNumber_setValue(&rPwrNum,RefPwr);             
                   
        // Just post up the value, the display will handle the math and graphing in a timer
        NexNumber_setValue(&swrNum,SWRVal*10); // uses xfloat so mult by 10 to shift decimal point      
    }    
    else if (pg == 4) // only send this group of data while on page 4
    {   
        // Page 4 is ADC calibration 
        if (!recvRetNumber(&number32))
            return 0;
        else
            return 1;
    }
    else if (pg == 5) // only send this group of data while on page 5
    {   
        // Page 5 is Quick Band Select
        if (!recvRetNumber(&number32))
            return 0;
        else
            return 1;
    }
    else if (pg == 1)  // on the Config Page #1
    {   
        // should not be here.
        return 0;
    }    
   return 1;
}
#endif  // end Nextion section

#ifdef SSD1306_OLED
/*                    
    Print to to 128x64 OLED graphics screen.  SSD1306 I2C type.
*/        
void OLED(void)
{ 
    char s[24]; 
    float32 value;
        
    display_clear();    
    gfx_drawRect( 0, 17, 127, 47, WHITE);
    
    // Top row is Yellow with Power in Watts, size 2 font
    gfx_setTextColor(WHITE);
    snprintf(s, 12, "  %*.1fW%c", 6, FwdPwr, '\0');
    gfx_setTextSize(2);    
    gfx_setCursor(4,0);
    gfx_println(s);
    
    //sprintf(s,"  Fwd    Ref    SWR");    
    gfx_setTextSize(1);    
    gfx_setCursor(16,20);
    gfx_println("Fwd");
    gfx_setCursor(58,20);
    gfx_println("Ref");
    gfx_setCursor(95,20);
    gfx_println("SWR");
    
    if (FwdPwr <= 0.1)
        sprintf(s, " %*.1f%*.1f%*s%c", 5, 0.0, 7, 0.0, 5, "NA", '\0'); 
    else
        sprintf(s, " %*.1f%*.1f%*.1f%c", 5, Fwd_dBm, 7, Ref_dBm, 6, SWRVal, '\0');    
    gfx_setTextSize(1);
    gfx_setCursor(1,30);
    gfx_println(s);
    
    value = temp_read();
    sprintf(s,"%*.0fF%c", 3, value, '\0');   // temp from the ADL5519 board (not the PA heat sink, maybe later from amp control board)
    gfx_setTextSize(1);
    gfx_setCursor(5,49);
    gfx_println(s);
        
    value = v14_read();
    sprintf(s,"%*.1fVDC%c", 4, value, '\0');   // 28V via Voltage divider
    gfx_setTextSize(1);
    gfx_setCursor(33,49);
    gfx_println(s);
    
    value = hv_read();
    sprintf(s,"%*.1fVDC%c", 4, value, '\0');   // 28V via Voltage divider
    gfx_setTextSize(1);
    gfx_setCursor(81,49);
    gfx_println(s);

    
    display_update();    // NOTE: You should remember to update the display in order to see the results on the oled. 
}
#endif // end SSD1306_OLED section

/*******************************************************************************
* Function Name: serial_usb_read
********************************************************************************
*
* Summary:
*  The main function performs the following actions:
*   1. Waits until VBUS becomes valid and starts the USBFS component which is
*      enumerated as virtual Com port.
*   2. Waits until the device is enumerated by the host.
*   3. Waits for data coming from the hyper terminal and sends it back.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
uint16 serial_usb_read(void)
{
    if (0u != Serial_USB_IsConfigurationChanged())    /* Host can send double SET_INTERFACE request. */
    {
        if (0u != Serial_USB_GetConfiguration())         /* Initialize IN endpoints when device is configured. */
        {            
            Serial_USB_CDC_Init(); /* Enumeration is done, enable OUT endpoint to receive data from host. */
        }
    }
    
    rx_count = 0;    
    if (0u != Serial_USB_GetConfiguration())      /* Service USB CDC when device is configured. */
    {        
        if (0u != Serial_USB_DataIsReady()) /* Check for input data from host. */
        {   
            rx_count = Serial_USB_GetAll(rx_buffer);    /* Read received data and re-enable OUT endpoint. */     
        }   
        if (rx_count != 0){         // initially p1 = p2.  parser will move p1 up to p2 and when they are equal, buffer is empty, parser will reset p1 and p2 back to start of sData
            memcpy(pSdata2 , rx_buffer, rx_count);   // append the new buffer data to current end marked by pointer 2
            pSdata2 += (rx_count);   // Update the end pointer position. The function processing chars wil lupdate teh p1 and p2 pointers
            //*(pSdata2) = '\0';
            rx_count = pSdata2 - pSdata1;  // update count for total unread chars.
        }
    }
    return rx_count;
}

/*******************************************************************************
* Function Name: serial_usb_write
********************************************************************************
*
* Summary:
*  The main function performs the following actions:
*   1. send 1 character ou thte usb virtual comm port.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void serial_usb_write(void)
{   
    uint32_t exit_Count;
    #define EXIT_CTR 2500
    
    tx_count = strlen((char *) tx_buffer);
    
    if (0u != tx_count)
    {
        exit_Count = 0;
        /* Wait until component is ready to send data to host. */
        while (0u == Serial_USB_CDCIsReady() && exit_Count < EXIT_CTR) 
        {
            ++exit_Count; 
            if (exit_Count > EXIT_CTR - 2)  // emergency escape plan to prevent a hang
                return;
        }
        Serial_USB_PutData(tx_buffer, tx_count);         /* Send data back to host. */

        /* If the last sent packet is exactly the maximum packet 
        *  size, it is followed by a zero-length packet to assure
        *  that the end of the segment is properly identified by 
        *  the terminal.
        */
        if (Serial_USB_BUFFER_SIZE == tx_count)
        {
            exit_Count = 0;
            
            while (0u == Serial_USB_CDCIsReady() && exit_Count < EXIT_CTR)            /* Wait until component is ready to send data to PC. */
            {
                ++exit_Count; 
                if (exit_Count > EXIT_CTR - 2)  // emergency escape plan to prevent a hang
                    return;
            }
            Serial_USB_PutData(NULL, 0u);            /* Send zero-length packet to PC. */
        }
    }
}

float32 hv_read(void)
{
    float32 tmp;
    uint32 ad_counts=0;
    
    // Read voltage by ADC via MUX (If connected)
    AMux_RF_Power_FastSelect(MUX_HV);  // 2 is mux port connected to the temperature IO pin.
    CyDelayUs(5);
    ad_counts = ADC_RF_Power_Read32();  // single read but has locked up with N1MM commands
    //ad_counts = ADC_RF_Power_GetResult32();  // continuous conversion      
    tmp = ADC_RF_Power_CountsTo_Volts(ad_counts);      // store the detector temp reading for cal optimization if desired.  For now jsut display it on the screen  
    tmp *= 8.18569892473; // adjust for voltage divider.  28.6V / 3.15V on ADC.
#ifdef AMP1296
    value *= 8.49; // adjust for voltage divider.  28.6V / 3.15V on ADC.
#endif
    return tmp;
}

float32 v14_read(void)
{
    float32 tmp;
    uint32 ad_counts=0;
    
    // Read voltage by ADC via MUX (If connected)
    AMux_RF_Power_FastSelect(MUX_14V);  // 2 is mux port connected to the temperature IO pin.
    CyDelayUs(5);
    ad_counts = ADC_RF_Power_Read32();  // single read but has locked up with N1MM commands
    //ad_counts = ADC_RF_Power_GetResult32();  // continuous conversion      
    tmp = ADC_RF_Power_CountsTo_Volts(ad_counts);      // store the detector temp reading for cal optimization if desired.  For now jsut display it on the screen  
    tmp *= 5.283031186243; // adjust for voltage divider.  12.95 / 4.39 =  on ADC.
#ifdef AMP1296
    tmp *= 2.94; // adjust for voltage divider.  12.95 / 4.39 =  on ADC.
#endif
    return tmp;
}

float32 curr_read(void)
{
    float32 tmp;
    uint32 ad_counts=0;
    
    // Read ADC via MUX (If connected)
    AMux_RF_Power_FastSelect(MUX_CURR);  // 2 is mux port connected to the temperature IO pin.
    CyDelayUs(5);
    ad_counts = ADC_RF_Power_Read32();  // single read but has locked up with N1MM commands
    //ad_counts = ADC_RF_Power_GetResult32();  // continuous conversion      
    tmp = ADC_RF_Power_CountsTo_Volts(ad_counts);      // store the detector temp reading for cal optimization if desired.  For now jsut display it on the screen  
    tmp *= 1;  // use for testing only until connected for real - set input pin to hi impedance
#ifdef AMP1296
    tmp *= 1;  // use for testing only until connected for real - set input pin to hi impedance
#endif
    return tmp;
}

float32 temp_read(void)
{
    float32 tmp;
    uint32 ad_counts=0;
  
#ifdef DETECTOR_TEMP_CONNECTED
    // Read detector temperature (If connected)
    AMux_RF_Power_FastSelect(MUX_TEMP);  // 2 is mux port connected to the temperature IO pin.
    CyDelayUs(5);
    ad_counts = ADC_RF_Power_Read32();  // single read but has locked up with N1MM commands
    //ad_counts = ADC_RF_Power_GetResult32();  // continuous conversion      
    tmp = ADC_RF_Power_CountsTo_Volts(ad_counts);      // store the detector temp reading for cal optimization if desired.  For now jsut display it on the screen
    tmp -= 1.36;   // ADL5519 is 4.48mV/C at 27C which is typically 1.36VDC.  Convert to F.  
    tmp /= 0.00448;   // mV/C
    tmp += 27;   //1.36V at 27C (80.6F)
    tmp *= 9;
    tmp /= 5;    // convert to F
    tmp += 32;    
    TempVal = tmp;  
    return TempVal;
#endif 
    return 0;   // if not temp connected just return 0;
}

void adRead(void)   // A/D converter read function.  Normalize the AD output to 100%.
{
    float32 a;
    float32 b;
    uint16 c;
    float32 tmp, retry=0;
    uint32 ad_counts=0;

    // Throttle the time the CPU spends here.   Offset the timing os teh data acquired is just before it is sent out
    if (Timer_X00ms_InterruptCnt == Timer_X00ms_Last_AD)   // will use our own timestamp.
        return;   // skip out until greater than 100ms since our last visit here
    Timer_X00ms_Last_AD = Timer_X00ms_InterruptCnt;  // time stamp our visit here.  Do not want to come back too soon.  

__reread:   // jump label to reread values in case of odd result or hi SWR
    
    // Get Reflected Power     
        total_Ref -= readings_Ref[readIndex_Ref];// subtract the last reading:    
    c = 1; // read from the sensor:
    a = 0;
    for (int i = 0; i < c; ++i)  {
        // ADC_RF_Power_SetGain(1);  // can be used to tweak in the ADC                
        AMux_RF_Power_FastSelect(MUX_REF);
        CyDelayUs(5);        
        ad_counts = ADC_RF_Power_Read32();  // single read but has locked up with N1MM commands at times
        //ad_counts = ADC_RF_Power_GetResult32();  // continuous conversion                
        RefVal = ADC_RF_Power_CountsTo_Volts(ad_counts);
        a += RefVal;
    }
    a /= c; // calculate the average then use result in a running average
    readings_Ref[readIndex_Ref] = a;   // get from the latest average above and track in this runnign average
    total_Ref += readings_Ref[readIndex_Ref];// add the reading to the total:
    readIndex_Ref += 1;       // advance to the next position in the array:
    //if (NUMREADINGS >1)  // Average less than the Fwd readings to minimize chance of ref being higher than Fwd on transient downward.
    //{
    //    if (readIndex_Ref >= NUMREADINGS-1)  // if we're at the end of the array...        
    //        readIndex_Ref = 0;// ...wrap around to the beginning:
    //}
    //else 
    //{
        if (readIndex_Ref >= NUMREADINGS)  // if we're at the end of the array...        
            readIndex_Ref = 0;// ...wrap around to the beginning:
    //}
    // caclulate dB value for digital display section
    b = total_Ref / NUMREADINGS;// calculate the average:        
    b -= Offset_R;   // adjust to 0V reference point
    b /= Slope_R;   // will be negative for detectors like AD8318
    b += CouplingFactor_Ref;
    b += 0.0; // fudge factor for frequency independent factors like cabling
    
    Ref_dBm = b;
    // 0dBm is max. = 1W fullscale on 1W scale.
    RefPwr = pow(10.0,(b-30.0)/10.0);    // convert to linear value for meter using 1KW @ 0dBm as reference 
    if (RefPwr > 999.9) 
        RefPwr = 999.9999;

    // subtract the last reading for Fwd Power
    total_Fwd -= readings_Fwd[readIndex_Fwd];
    // read from the sensor:
    c = 1;   // short term smaples that feed into running average
    a = 0;
    for (int i = 0; i < c; ++i) {                   
        // ADC_RF_Power_SetGain(1);  // can be used to tweak in the ADC
        AMux_RF_Power_FastSelect(MUX_FWD);  
        CyDelayUs(5);
        ad_counts = ADC_RF_Power_Read32();  // single read but has locked up with N1MM commands
        //ad_counts = ADC_RF_Power_GetResult32();  // continuous conversion        
        FwdVal = ADC_RF_Power_CountsTo_Volts(ad_counts);    
        a += FwdVal;
    }
    a /= c; // calculate the average then use result in a running average
    readings_Fwd[readIndex_Fwd] = a;   // get from the latest average above and track in this runnign average
    total_Fwd += readings_Fwd[readIndex_Fwd];    // add the reading to the total: 
    readIndex_Fwd += 1;     // advance to the next position in the array:
    if (readIndex_Fwd >= NUMREADINGS) {     // if we're at the end of the array...      
        readIndex_Fwd = 0;  // ...wrap around to the beginning:
    }     
    b = total_Fwd / NUMREADINGS;    // calculate the average:
    // caclulate dB value for digital display section
    b -= Offset_F;   // adjusts to 0V reference point - calculated during cal
    b /= Slope_F;   // will be negative for detectors like AD8318 - calculated during cal
    b += CouplingFactor_Fwd;
    b += 0.0; // Fudge factor for frequency independent factors like cabling
    Fwd_dBm = b;    // Now have calibrated Forward Value in dBm.
    // 0dBm is max. = 1W fullscale on 1W scale for example
    FwdPwr =  pow(10.0,(b-30.0)/10.0);    // convert to linear value for meter using 1KW @ 0dBm as reference. Multiply by scale value.
    if (FwdPwr > 9999.9)
        FwdPwr = 9999.9999;    
    
    if (RefPwr < FwdPwr) 
        tmp = sqrt(RefPwr/FwdPwr);
    else 
        tmp = sqrt(FwdPwr-0.1/FwdPwr);
        //tmp = .99999;   // if Ref > Fwd, then SWR is sky high, limit number range < 99
        
    SWRVal = ((1 + tmp) / (1 - tmp));  // now have SWR in range of 1.0 to infinity.  
    if (RefPwr > FwdPwr && FwdPwr < 0.2) // Remove false SWR values if no Fwd Pwr such as TX turns off and Fwd goes to 0 before Ref.
        SWRVal = 0;
    else if (RefPwr <= 0.00001 || FwdPwr <= 0.2)
        SWRVal = 0;   // remove misleading SWR numbers when input are floating around in RX mode.
    else if (SWRVal > 9.9)
        SWRVal = 10;
    else if(SWRVal < 0)
        SWRVal = 0;

    if (retry < 2 && SWRVal > 2.0) // if SWR is high re read to verify.  Getting occasional false trips when Ref is Higher than Fwd on TX turning off.
    {
        retry++;  // prevent endless loop in hi SWR scenario - we just want to wait out any transient such as transition for RX to TX and TX to RX.
        CyDelay(10);
        //adRead();
        goto __reread;        
    }
    retry = 0;
    
#ifdef SWR_ANALOG  // Update SWR Analog output for Amplifier protection when using KitProg board in an amplifier
    float32 SWR_val_temp = 0;
    uint8 SWR_analog_value = 0;
    
    // DAC is configured for 0-4.0VDC output.  Amp board will be adjusted to suit this.
    // SWR_Val should be 0-100 type of number.  We care about 0 to 5 since the amp trip point will be about 3.0/
    SWR_val_temp = SWRVal;   // bounds check uing like size/type vars
    if (SWR_val_temp < 0.0)
        SWR_val_temp = 0.0;
    if (SWR_val_temp > 5.0)
        SWR_val_temp = 5.0;       
    // Actual trip point is set by pot on Amp Control board reading DAC voltage
    SWR_analog_value = SWR_val_temp * (255/5);  // Convert to 0-4.0 range (DAC value 0-255).
    if (SWR_analog_value < 0)
        SWR_analog_value = 0;
    if (SWR_analog_value > 255)
        SWR_analog_value = 255;                
    SWR_Fail_Analog_Output_SetValue(SWR_analog_value);     
#endif
    
    SWR_Serial_Val = SWRVal;
    FwdPwr_last = FwdPwr;  // update memory to minimize screen update and flicker on digital number
    sendSerialData();   // send this data to the serial port for remote monitoring
}

/*
 *   Send out dBm, Watts, and SWR values to data channel - serial, WiFi, or Bluetooth
*/
void sendSerialData()
{
    //if (Timer_X00ms_InterruptCnt != Timer_X00ms_Last)
    //{
        Timer_X00ms_Last_USB = Timer_X00ms_InterruptCnt;       
        sprintf((char *) tx_buffer,"%d,%s,%s,%.2f,%.2f,%.1f,%.1f,%.1f\r\n%c", METERID, "170", Band_Cal_Table[CouplerSetNum].BandName, Fwd_dBm, Ref_dBm, FwdPwr, RefPwr, SWR_Serial_Val, '\0');       
        serial_usb_write();
        sprintf((char *) tx_buffer,"%d,%s,%.1f,%.1f,%.1f,%.1f\r\n%c", METERID, "171", hv_read(), v14_read(), curr_read(), temp_read(), '\0');       
        serial_usb_write();   
    //}
}

void get_remote_cmd()
{
    uint8 cmd1;
    float32 cmd2;
    uint8 cmd_str_len;
    uint8 i = 0; 
    uint8 j = 0;
    char cmd_str[BUF_LEN] = {};
    
    
    if (rx_count !=0) {
        pSdata = strchr(pSdata1, '\n');   // find string terminator position
        if (pSdata) { 
            *pSdata = '\0';
            cmd_str_len = pSdata - pSdata1;
            strncpy(cmd_str, pSdata1, cmd_str_len);   // copy chars between p1 and the terminator
            pSdata1 += (cmd_str_len+1);  // reset ch pointer back to stat of string for char parsing
             
            if (pSdata1 >= pSdata2 || cmd_str_len > BUF_LEN)  // if we have caught up to the end p2 then reset to beginning of buffer position.
                pSdata1 = pSdata2 = sdata; 
        
            if (strlen(sdata) >= BUF_LEN-1) {
                //pSdata = sdata;
                sdata[0] = '\0';
                //printf("BUFFER OVERRRUN\n");
                //Serial_ClearRxBuffer();            
                return;
            }
            // filter out unwanted characters             
            // Now we have a full comma delimited command string - validate and break it down           
            j = 0;
            for (i=0; (sdata[i] != ',') && (i <= cmd_str_len); i++) {
                if (isalnum(sdata[i]))
                    cmd_str[j++] = (sdata[i]);                 
            }
            cmd_str[j] = '\0';  
            printf(" Meter ID  ");
            printf("%s\n",cmd_str);

            if (atoi(cmd_str) == METERID) {
                if (i < cmd_str_len) {
                    j = 0;
                    // Look for Msg_Type now
                    for (i +=1; (sdata[i] != ',') && (i <= cmd_str_len); i++) {   // i+1 to skip over the comma the var 'i' was left pointing at
                        cmd_str[j++] = sdata[i];                 
                    }
                    cmd_str[j] = '\0';
                    printf(" Msg Type:  ");
                    printf("%s",cmd_str);
                  
                    if (atoi(cmd_str) == 120)  {   // Vaidate this message type for commands.  120 = coammand, 170 is data output                              
                        j = 0;
                        if (i < cmd_str_len) {                               
                            for (i += 1; (sdata[i] != ',') && (i <= cmd_str_len); i++) {
                                cmd_str[j++] = sdata[i];
                            }  
                            cmd_str[j] = '\0';
                            printf(" CMD1:  ");
                            printf("%s",cmd_str);
                            cmd1 = atoi(cmd_str);
                        }
                        else 
                            cmd1 = 0;
                        
                        j = 0;
                        if (i < cmd_str_len) {                                                
                            for (i += 1; (sdata[i] != ',') && (i <= cmd_str_len); i++) {
                                cmd_str[j++] = sdata[i];                          
                            }
                            cmd_str[j] = '\0';
                            printf(" CMD2:  ");
                            printf("%s",cmd_str);
                            cmd2 = atof(cmd_str);
                        }
                        else 
                            cmd2 = 0.0;
                  
                        // Now do the commands     
                        // add code to limit variables received to allowed range
                        if (cmd1 == 255) Button_A = YES;   // switch scale - not really useful if you cannot see the meter face, data is not changed
                        if (cmd1 == 254) {
                            Button_B = YES;   // switch bands
                            //CouplerSetNum = constrain(CouplerSetNum, 0, NUM_SETS);  
                            NewBand = CouplerSetNum +1;    // Update Newband to current value.  Will be incrmented in button function                          
                            if (NewBand > NUM_SETS) 
                                NewBand = 0;  // cycle back to lowest band
                        }
                        if (cmd1 == 253) Button_C = YES;   // Switch op_modes betweem SWR and PWR - same as scale, not useful lif you cannot seethe meter face.
                        if (cmd1 == 252) print_cal_table();  //Speed up or slow down the Serial line output info rate
                        if (cmd1 == 251) NULL;  // Not Used yet
                        if (cmd1 == 250) {   // dump current cal table to remote  (Was Scale GUI button)
                            Button_B = YES;
                            NewBand = 10;  
                        }   
                        if (cmd1 == 249) {     // Jump to Band 5.7G
                            Button_B = YES;
                            NewBand = 9;  
                        }
                        if (cmd1 == 248) {     // Jump to Band 3.4G
                            Button_B = YES;
                            NewBand = 8;  
                        }
                        if (cmd1 == 247) {     // Jump to Band 2.3G
                            Button_B = YES;
                            NewBand = 7;  
                        }
                        if (cmd1 == 246) {     // Jump to Band 1296
                            Button_B = YES;
                            NewBand = 6;  
                        }
                        if (cmd1 == 245) {     // Jump to Band 902
                            Button_B = YES;
                            NewBand = 5;  
                        }
                        if (cmd1 == 244) {     // Jump to Band 432
                            Button_B = YES;
                            NewBand = 4;  
                        }
                        if (cmd1 == 243) {     // Jump to Band 222
                            Button_B = YES;
                            NewBand = 3;  
                        }
                        if (cmd1 == 242) {     // Jump to Band 144
                            Button_B = YES;
                            NewBand = 2;  
                        }
                        if (cmd1 == 241) {     // Jump to Band 50
                            Button_B = YES;
                            NewBand = 1;  
                        }
                        if (cmd1 == 240) {     // Jump to Band HF
                            Button_B = YES;
                            NewBand = 0;  
                        }
                        if (cmd1 == 239) {     // Toggle Serial power data outpout.  Other serial functions remain available.
                            toggle_ser_data_output();
                        }
                        if (cmd1 == 193) {    // Set up for potential EEPROM Reset if followed by 5 second press on Button C
                            Reset_Flag = 1;
                            print_Cmd_Progress(1);   // Use when there is a start and stop with delay the remote needs to know about
                        }
                        if (cmd1 == 194) {     // Set Reset EEPROM flag.  Will repopulate after CPU reset
                            if (Reset_Flag == 1) 
                                reset_EEPROM();
                            Reset_Flag = 0;   
                            print_Cmd_Progress(0);
                        }
                        if (cmd1 == 195) {    // Save to EEPROM - Usually following cal changes from Remote meter appp that are not committed yet                          
                            Cal_Table_write();
                            EEPROM_Init_Write();    // save to eeprom on changes.  
                            EEPROM_Init_Read();     // load the values into memory to check them
                            Cal_Table();  // read back to be sure it save correctly                          
                           // Probably use a sw wd to do a software remote reset for PSoC5.
                        }                            
                        // Handle remote command to change stored coupling factor to support headless ops.
                        // TODO: Need to write into EEPROM, either here or by changing bands.                          
                        if (cmd1 >= 100 && cmd1 < 120) {     // Change Fwd coupling factor for Port X
                            int index;
                            index = cmd1 - 100;
                            Band_Cal_Table[index].Cpl_Fwd = cmd2;       // cmd2 is second byte in 2 byte payload.                              
                            EEPROM_Init_Write();    // save to eeprom
                            EEPROM_Init_Read();     // load the values into memory
                            Cal_Table();
                        }
                        if (cmd1 >= 120 && cmd1 < 140) {     // Change Ref coupling factor for Port X
                            int index;
                            index = cmd1 - 120;
                            Band_Cal_Table[index].Cpl_Ref = cmd2;       // cmd2 is second byte in 2 byte payload.                              
                            EEPROM_Init_Write();    // save to eeprom on changes.  
                            EEPROM_Init_Read();     // load the values into memory
                            Cal_Table();
                        }  
                        if (cmd1 >= 140 && cmd1 < 160) {     // Change Ref coupling factor for Port X by + cmd2 value
                            int index;
                            index = cmd1 - 140;
                            Band_Cal_Table[index].Cpl_Ref = Band_Cal_Table[index].Cpl_Ref + cmd2;       // cmd2 is second byte in 2 byte payload.                              
                            EEPROM_Init_Write();    // save to eeprom on changes.  
                            EEPROM_Init_Read();     // load the values into memory
                            Cal_Table();
                        }                                                                                                  
                        if (cmd1 >= 160 && cmd1 < 180) {     // Change Ref coupling factor for Port X by - cmd2 value
                            int index;
                            index = cmd1 - 160;
                            Band_Cal_Table[index].Cpl_Ref = Band_Cal_Table[index].Cpl_Ref - cmd2;       // cmd2 is second byte in 2 byte payload.                              
                            EEPROM_Init_Write();    // save to eeprom on changes.  
                            EEPROM_Init_Read();     // load the values into memory
                            Cal_Table();
                        }
                        if (cmd1 == 96) {     // Jump to Band HF
                           Nextion_Switch_Write(1);    // Switch serial from display to USB UART converter                                                                      
                        }
                        if (cmd1 == 95) {     // Jump to Band HF
                           Nextion_Switch_Write(0);    // Switch serial from display to CPU                                                        
                        }
                        if (cmd1 == 94) {    // This is cal routine. cmd is target Fwd value.  uses Attenuaor value adjustment to set cal.  Depricated.
                            //if higher than cmd 2 decrement, do adread(), check and adj again until a near match.
                            // Challenge might be impossible to get an exact match, so need close enough decision logic.
                            for (i = 0; i< 100; i++)   // put a limit on to ensure we do not have an endless loop if we cannot get a match within the window
                            {
                                if (FwdPwr > cmd2+4.0 && FwdPwr > 10.0) // Coarse tune
                                {
                                    // decrement 
                                    CouplingFactor_Fwd -= 0.5;
                                    adRead();  // get new values                                
                                    print_Cal_Table_progress(1);
                                }
                                else if (FwdPwr > cmd2+0.1) // coarse tune range
                                {
                                    // decrement 
                                    CouplingFactor_Fwd -= 0.01;
                                    adRead();  // get new values                                
                                    print_Cal_Table_progress(1);
                                }
                                else if (FwdPwr < cmd2-4.0 && FwdPwr > 10.0)
                                {
                                    // increment
                                    CouplingFactor_Fwd += 0.5;
                                    adRead();  // get new values                                
                                    print_Cal_Table_progress(1);
                                }  
                                else if (FwdPwr < cmd2-0.1)
                                {
                                    // increment
                                    CouplingFactor_Fwd += 0.01;
                                    adRead();  // get new values                                
                                    print_Cal_Table_progress(1);
                                }  
                                else    
                                {
                                    i=100;   // exit the loop                                 
                                    // if neither of the above then assume we are close enough and move on using the current value
                                    //Cal_Table();   // update the current band values for adRead to use 
                                    print_Cal_Table_progress(0);
                                    sprintf((char *) tx_buffer,"*** FwdPwr=%.2f   Loop count =%d ***\r\n", FwdPwr, i);   // debug message to Serial USB
                                    serial_usb_write();
                                    Cal_Table_write(); 
                                    //EEPROM_Init_Write();    // save to eeprom
                                    //EEPROM_Init_Read();     // load the values into memory
                                    Cal_Table();  // read it back                                   
                                }  
                                adRead();
                            }
                        }
                        if (cmd1 == 93) {    // This is an alternative auto cal routine changing the attenuation only. cmd is target Ref value.                         
                            for (i = 0; i< 100; i++)   // put a limit on to ensure we do not have an endless loop if we cannot get a match within the window
                            {
                                if (RefPwr > cmd2+1.0) // Fine tune
                                {
                                    // decrement 
                                    CouplingFactor_Ref -= 0.5;
                                    adRead();  // get new values                                                                   
                                    serial_usb_write();
                                    print_Cal_Table_progress(1);
                                }
                                else if (RefPwr > cmd2+0.1) // coarse tune range
                                {
                                    // decrement 
                                    CouplingFactor_Ref -= 0.01;
                                    adRead();  // get new values                                                                    
                                    serial_usb_write();
                                    print_Cal_Table_progress(1);
                                }
                                else if (RefPwr < cmd2-1.0)
                                {
                                    // increment
                                    CouplingFactor_Ref += 0.5;
                                    adRead();  // get new values                                
                                    serial_usb_write();
                                    print_Cal_Table_progress(1);
                                }  
                                else if (RefPwr < cmd2-0.1)
                                {
                                    // increment
                                    CouplingFactor_Ref += 0.01;
                                    adRead();  // get new values                                
                                    serial_usb_write();
                                    print_Cal_Table_progress(1);
                                }  
                                else    
                                {
                                    i=100;   // exit the loop                                 
                                    // if neither of the above then assume we are close enough and move on using the current value
                                    print_Cal_Table_progress(0);  // end of loop
                                    sprintf((char *) tx_buffer,"*** RefPwr=%.2f   Loop count =%d ***\r\n", RefPwr, i);   // debug message to Serial USB                                    
                                    serial_usb_write();
                                    Cal_Table_write(); 
                                    //EEPROM_Init_Write();    // save to eeprom
                                    //EEPROM_Init_Read();     // load the values into memory
                                    Cal_Table();  // read it back                                    
                                }                               
                            }
                        }
                        if (cmd1 == 92) 
                        {    // Get Slope from user (if needed, normally calculated)
                            Slope_F = cmd2;                            
                        }
                        if (cmd1 == 91) 
                        {    // Get Slope from user (if needed, normally calculated)
                            Slope_R = cmd2;                                           
                        }                                                                                     
                        if (cmd1 == 90) 
                        {    // Get Offset from user (if needed, normally calculated)
                            Offset_F = cmd2;                            
                        }
                        if (cmd1 == 89) 
                        {    // Get Offset from user (if needed, normally calculated)
                            Offset_R = cmd2;                                           
                        }  
                        if (cmd1 == 79) 
                        {    // Get target hi power level from user in Watts, convert to dBm then measure and save ADC                            
                            Pwr_hi = cmd2;    
                            Pwr_hi = 10 * log10(1000*(Pwr_hi/1));
                            adRead();  // update our high power readings for foprward and reflected power for the current band
                            FwdVal_hi = FwdVal; // save for calc                            
                            RefVal_hi = RefVal;  // save for calc    
                            print_Cal_Table_progress(1);  // end of loop
                        }
                        if (cmd1 == 78) 
                        {    // Get target hi power level from user in dBm then measure and save ADC                            
                            Pwr_hi = cmd2;                                
                            adRead();  // update our high power readings for foprward and reflected power for the current band
                            FwdVal_hi = FwdVal; // save for calc                            
                            RefVal_hi = RefVal;  // save for calc    
                            print_Cal_Table_progress(1);  // end of loop
                        }
                        if (cmd1 == 77) 
                        {    // Get target lo power level from user in Watts, convert to dBm then measure and save ADC                            
                            Pwr_lo = cmd2;    
                            Pwr_lo = 10 * log10(1000*(Pwr_lo/1));
                            adRead();  // update our high power readings for foprward and reflected power for the current band
                            FwdVal_lo = FwdVal; // save for calc                            
                            RefVal_lo = RefVal;  // save for calc    
                            print_Cal_Table_progress(1);  // end of loop
                        }
                        if (cmd1 == 76) 
                        {    // Get target power lo level from user in dBm then measure and save ADC                            
                            Pwr_lo = cmd2;                            
                            adRead();  // update our high power readings for foprward and reflected power for the current band
                            FwdVal_lo = FwdVal; // save for calc                            
                            RefVal_lo = RefVal;  // save for calc    
                            print_Cal_Table_progress(1);  // end of loop
                        }
                        if (cmd1 == 75) // Fwd Direction Calc
                        {   // Use stored values of Hi and lo power for Fwd direction
                            if (Pwr_hi != 0) // ensure we have a valid high power number before calculating.
                            {                      
                                // Calculate Slope and Offset
                                Slope_F = (FwdVal_hi - FwdVal_lo)/(Pwr_hi - Pwr_lo);
                                Offset_F = FwdVal_hi + ((CouplingFactor_Fwd - Pwr_hi) * Slope_F);
                                Cal_Table_write();
                                //EEPROM_Init_Write();    // save to eeprom on changes.  
                                //EEPROM_Init_Read();     // load the values into memory to check them
                                Cal_Table();  // read back to be sure it save correctly                                
                                print_Cal_Table_progress(0);  // end of loop
                            }
                        }
                        if (cmd1 == 74) //Ref Direction Calc
                        {    // Use stored values of Hi and lo power for Ref direction
                            if (Pwr_hi != 0) // ensure we have a valid high power number before calculating.
                            {                             
                                // Calculate Slope and Offset
                                Slope_R = (RefVal_hi - RefVal_lo)/(Pwr_hi - Pwr_lo);
                                Offset_R = RefVal_hi + ((CouplingFactor_Ref - Pwr_hi) * Slope_R);
                                Cal_Table_write();
                                //EEPROM_Init_Write();    // save to eeprom on changes.  
                                //EEPROM_Init_Read();     // load the values into memory to check them
                                Cal_Table();  // read back to be sure it save correctly
                                print_Cal_Table_progress(0);  // end of loop
                            }
                        }
                    } // end of msg_type 120                                      
                } // end of msg_type length check
            } // end of meter ID OK    
        } // end of \n found
    } //end rx_count not 0
} // end get_remote_cmd function

// Copy hard coded cal data to memory
void write_Cal_Table_from_Default()
{
  uint i;
  
  for (i=0;i<NUM_SETS;i++) {
    // Populate initial database scructure in RAM.  Ultimately it needs to be read from EEPROM once initialized
    strcpy(Band_Cal_Table[i].BandName, Band_Cal_Table_Def[i].BandName);
    Band_Cal_Table[i].Cpl_Fwd = Band_Cal_Table_Def[i].Cpl_Fwd;
    Band_Cal_Table[i].Slope_F = Band_Cal_Table_Def[i].Slope_F;
    Band_Cal_Table[i].Offset_F = Band_Cal_Table_Def[i].Offset_F;
    Band_Cal_Table[i].Cpl_Ref = Band_Cal_Table_Def[i].Cpl_Ref;   
    Band_Cal_Table[i].Slope_R = Band_Cal_Table_Def[i].Slope_R;
    Band_Cal_Table[i].Offset_R = Band_Cal_Table_Def[i].Offset_R;
    
    //printf("Copied default data info Band Cal Table");
    set_hv_max = HV_MAX; // reset the setpoints and mterid and band
    set_v14_max = V14_MAX;      
    set_curr_max = CURR_MAX;
    set_temp_max = TEMP_MAX;
    METERID = default_METERID;
    CouplerSetNum = 0;
  }
}

// Mark EEPROM for overwrite
void reset_EEPROM()
{
    if (Reset_Flag ==1) {
        // erase byte 0 to force init process for testing.  Can also use to "factory" reset data     
        set_hv_max = HV_MAX;
        set_v14_max = V14_MAX;
        set_curr_max = CURR_MAX;
        set_temp_max = TEMP_MAX;
        EEPROM_WriteByte(0,EE_STATE_BASE_ADDR);
        write_Cal_Table_from_Default();
        EEPROM_Init(EE_SAVE_YES);
        //printf("Erased Byte 0");
        EEPROM_Init_Read();     // load the values into m
        Cal_Table();
    }
}

// Toggle USB serial output data
void toggle_ser_data_output()
{
     if (EEPROM_ReadByte(EE_STATE_BASE_ADDR+SER_DATA_OUT_OFFSET) != 'Y' || ser_data_out == 1){
        EEPROM_WriteByte(EE_STATE_BASE_ADDR+SER_DATA_OUT_OFFSET, 'Y');
        //printf("Enabled Serial Data Output");
        ser_data_out = 0;
     }
     else { 
        EEPROM_WriteByte(EE_STATE_BASE_ADDR+SER_DATA_OUT_OFFSET , 'N');
        //printf("Disabled Serial Data Output");
     }
}

void Cal_Table()
{
    // Each coupler has unique coupling factor. 
    CouplingFactor_Fwd = Band_Cal_Table[CouplerSetNum].Cpl_Fwd;  // value in dB from coupler specs.  
    CouplingFactor_Ref = Band_Cal_Table[CouplerSetNum].Cpl_Ref;
    Slope_F = Band_Cal_Table[CouplerSetNum].Slope_F;
    Offset_F = Band_Cal_Table[CouplerSetNum].Offset_F;
    Slope_R = Band_Cal_Table[CouplerSetNum].Slope_R;
    Offset_R = Band_Cal_Table[CouplerSetNum].Offset_R;
}
    
void Cal_Table_write(void)
{
    Band_Cal_Table[CouplerSetNum].Cpl_Fwd = CouplingFactor_Fwd;  // value in dB from coupler specs.  
    Band_Cal_Table[CouplerSetNum].Cpl_Ref = CouplingFactor_Ref;    
    Band_Cal_Table[CouplerSetNum].Slope_F = Slope_F;
    Band_Cal_Table[CouplerSetNum].Offset_F = Offset_F;
    Band_Cal_Table[CouplerSetNum].Slope_R = Slope_R;
    Band_Cal_Table[CouplerSetNum].Offset_R = Offset_R;
}

void print_cal_table()
{
    uint8   i;

    // example output format : "101,150,TEXT,55.4,35.4,3.3,2.2"
    // #150 for msg_type field to signal this is data dump, not power levels or other type messages.
    // meterid with msg_type = 150 to signal different data set than the normal output. 120 inbound cmd, 170, power out
    for (i=0; i < NUM_SETS; i++) {        
        sprintf((char *) tx_buffer, "%d,%s,%s,%.1f,%.5f,%.5f,%.1f,%.5f,%.5f\r\n", METERID, "150", Band_Cal_Table[i].BandName, Band_Cal_Table[i].Cpl_Fwd, Band_Cal_Table[i].Slope_F, Band_Cal_Table[i].Offset_F, Band_Cal_Table[i].Cpl_Ref, Band_Cal_Table[i].Slope_R, Band_Cal_Table[i].Offset_R);
        tx_count = strlen((char *) tx_buffer);        
        serial_usb_write();   // Output table text to serial port              
    }
}

/*
Start or end of cal message output to serial port.  1 is start, 0 is end.  Message type is 161 and 160.
 used to adjust dBm levels to match watts target using existing slope and offset.
*/
void print_Cal_Table_progress(uint8_t flag)
{   // uses current Offset and slope
    flag +=160;   // translate to start or end of cal procedure message type.   161 start, 160 end
    // example output format : "101,150,TEXT,55.4,35.4,3.3,2.2"
    // #161/160 for msg_type field to signal this is a cal calculation in progress
    //sprintf((char *) tx_buffer, "%d,%d,%s,%.2f,%.4f,%.2f,%.4f\r\n", METERID, flag, Band_Cal_Table[CouplerSetNum].BandName, CouplingFactor_Fwd, FwdVal, CouplingFactor_Ref, RefVal);        
    sprintf((char *) tx_buffer, "%d,%d,%s,%.5f,%.5f,%.5f,%.5f\r\n", METERID, flag, Band_Cal_Table[CouplerSetNum].BandName, FwdVal_hi, FwdVal_lo, RefVal_hi, RefVal_lo);
    tx_count = strlen((char *) tx_buffer);
    serial_usb_write();   // Output table text to serial port                  
}

/*
Start or end of cal message output to serial port.  1 is start, 0 is end.  Message type is 161 and 160.
 used to adjust dBm levels to match watts target using existing slope and offset.
*/
void print_Cmd_Progress(uint8_t flag)
{   // uses current Offset and slope
    flag +=162;   // translate to start or end of cal procedure message type.   163 start, 162 end
    // example output format : "101,162,TEXT"
    // #163/162 for msg_type field to signal this is data dump, not power levels or other type messages.
    // Send out raw ADC voltage readings
    sprintf((char *) tx_buffer, "%d,%d,%s,%.5f,%.5f,%.5f,%.5f\r\n", METERID, flag, Band_Cal_Table[CouplerSetNum].BandName, FwdVal_hi, FwdVal_lo, RefVal_hi, RefVal_lo);        
    tx_count = strlen((char *) tx_buffer);
    serial_usb_write();   // Output table text to serial port                  
}

/*******************************************************************************
* Function Name: EEPROM_Init
********************************************************************************
* Summary:
*   Called for Initialization, Check Byte 0 != G then copy into EEPROM space the needed variables
*   and the Band_Cal_Table structure. There can be other data in the rest of EEPROM.
*   Variables wil be reset to default after an overwrite.  A master reset menu option may be created to do this via the menu system
*  
*    Test Address 0.
*    Values for Address 0 (EEPROM_Cfg_Status)
*        0x00   Uninitialized or Erased
*        'S'  Initialization Started
*        'G'  Initialization Completed
*   
* Parameters:
*   None
*
* Return:
*   0 for success, 1 for FAIL
*
*******************************************************************************/

uint8_t EEPROM_Init(uint8 ee_save)
{
    /*  If we find a 'G' character at the start of EEPROM then skip initialization to prevent user data overwrite */   
    EE_PGM_Status = EEPROM_ReadByte(EE_STATE_BASE_ADDR);    
    if(((EE_PGM_Failed == NO) && EE_PGM_Status != 'G') || ee_save == EE_SAVE_YES)   /*   EEPROM_Init will set byte 0, 'S' or on success 'G' */
    {  /* start writing or overwriting 
        LCD_Position(TOP,0u);
        LCD_PrintString(" EE Write START ");      
        LCD_Position(BOTTOM,0u);
        LCD_PrintString("                ");      
        */
        CyDelay(1000u);  
        if(EEPROM_Init_Write() != 0)    /*  call EEPROM init function and check for success = 0       */
        {   /* 1st Failure. Update display with code and Retry 1 time                                     
            LCD_Position(TOP,0u);
            LCD_PrintString(" EE Write FAIL! ");              
            LCD_Position(BOTTOM,0u);
            LCD_PrintString("#1 Fail Code:   ");
            LCD_Position(BOTTOM,13u); 
            */
            EE_PGM_Status = EEPROM_ReadByte(EE_STATE_BASE_ADDR);
            if(EE_PGM_Status <48 || EE_PGM_Status != 'G')  /* filter out G to prevent false code, convert any non printable chars */                       
            {   
                //LCD_PutChar(EE_PGM_Status+48);   /*  Should be S for started or 0x00 */
            }
            else 
            {   
                //LCD_PutChar(EE_PGM_Status);   /*  Should be S for started or 0x00 */
            }          
            CyDelay(5000u);   /*  give time to see the screen eror  */
            //LCD_Position(BOTTOM,0u);
            //LCD_PrintString(" Retrying 1 time");
            CyDelay(1000u);   
            if(EEPROM_Init_Write() != 0) /* Now try 1 more time  */
            {   /*  Retry failed also   */
                /*LCD_Position(BOTTOM,0u);
                LCD_PrintString("#2 Fail Code:   ");
                LCD_Position(BOTTOM,13u); */
                EE_PGM_Status = EEPROM_ReadByte(EE_STATE_BASE_ADDR);
                if(EE_PGM_Status <48 || EE_PGM_Status != 'G')  /* filter out G to prevent false code, convert any non printable chars */                       
                {   
                    // LCD_PutChar(EE_PGM_Status+48);   /*  Should be S for started or 0x00 */
                }
                else 
                {   
                    // LCD_PutChar(EE_PGM_Status);   /*  Should be S for started or 0x00 */
                }
                CyDelay(10000u);    
                EE_PGM_Failed = YES;    /* Set a flag to not retry until program is reset.  Continue with defaults */
                return 1;
            }
        }
        #ifdef DEBUG_EEPROM
        LCD_Position(TOP,0u);
        LCD_PrintString(" EE Write Done! ");
        LCD_Position(BOTTOM,0u);
        LCD_PrintString(" Success! C:   ");
        LCD_Position(BOTTOM,12u);
        EE_PGM_Status = EEPROM_ReadByte(EE_STATE_BASE_ADDR);               
        LCD_PutChar(EE_PGM_Status);   /*  Should be 'G' */
        CyDelay(3000u);   
        #endif 
        EE_PGM_Failed = NO;
        return 0;
    }
    if(!EEPROM_Init_Read())
        return 0;   /*   Already has good EEPROM config data or has write attempts have failed 2 times before since reset so skip out  */  
    else return 1;  /*  FAIL   */
}
/*******************************************************************************
* Function Name: EEPROM_Init_Write
********************************************************************************
* Summary:
*   Copy into EEPROM space the needed variables and the Band_Cal_Table data structure.  
*   There can be other data in the rest of EEPROM and this will overwrite it.
*   Variables wil be reset to default after an overwrite.  A master reset menu option may be created to do this
*   Called by EEPROM_Init. After writing is complete check Byte 0 == 'G'.
*
* Parameters:
*   None
*
* Return:
*   0 for success, 1 for FAIL
*
*******************************************************************************/
uint8_t EEPROM_Init_Write(void)
{
    uint8       ee_row;
    uint8_t     c1_array[16]; /* stores 1 row of 16 bytes for eeprom write and reads */
    uint16      j;    
    uint8_t     eepromArray[NUM_SETS * (sizeof Band_Cal_Table)];  // 396 bytes
    //uint8_t     eepromArray[(NUM_SETS*20)];  // 200 is the array size calculated by the sizeOf function below
    uint16      Arr_Size;
    uint8       result;
    char        setpoint_buf[SETPOINT_LEN+1];
       
    EEPROM_UpdateTemperature();   
    /*  write 'S' to byte 0 to indicate we started writing bytes but not finished    */
    if(!EEPROM_ByteWritePos('S', 0, 0))
    {
        /*  Start writing all of our data to EEPROM now.  
            Everything is 1 byte in size so can serially copy each into EEPROM with no size or type conversion required
            Have structs and some variables to do at the end.  Lets start with the Band_Cal_Table structure               
            Begin with our state variables  in row 1, starting with the 3rd byte.  0 == corrupt flag, 1 = reserved, 3 is first data. 
            2 rows in at byte 33 (32 0-31) will start writing rows of Array data.  It is at the end to avoid having to recomputer where the saved data is relative to the start of EEPROM.
        */          
        c1_array[0] = 'S';   /* what we just wrote, will overwrite as a block of 16 bytes) */
        c1_array[EE_RESERVED_BYTE1] = _NULL;
        c1_array[OP_MODE_OFFSET] = op_mode;  
        c1_array[COUPLERSETNUM_OFFSET] = CouplerSetNum;
        c1_array[SER_DATA_OUT_OFFSET] = ser_data_out;                     
        // Need to test effect of leading 0s or not
        sprintf(setpoint_buf, "%*.1f", SETPOINT_LEN, set_hv_max);                            // convert float to 4 byte ascii
        memcpy(&c1_array[HV_MAX_OFFSET],setpoint_buf, SETPOINT_LEN);
        sprintf(setpoint_buf, "%*.1f",SETPOINT_LEN, set_v14_max);                           // convert float to 4 byte ascii
        memcpy(&c1_array[V14_MAX_OFFSET],setpoint_buf, SETPOINT_LEN);                                                       
        c1_array[TEMP_MAX_OFFSET] = set_temp_max;                              // byte 13 of 0-15
        c1_array[METERID_OFFSET] = METERID;                                     // byte 14 of 15
        c1_array[SPARE0_OFFSET] = '\0';                                        // byte 15 of 15  

        // copy row 0 to EEPROM now     
        ee_row = 0;
        Copy_to_EE(ee_row,c1_array,NO);     /* copy 1 row at a time to EEPROM */               
        
        /*  Now for row 2   */
        memcpy(c1_array,Callsign, CALLSIGN_LEN);   /*  7 bytes */      
        // append any other strings like this example:
        //memcpy(&c1_array[CALLSIGN_LEN],Grid_Square, GRIDSQUARE_LEN); /* 9 bytes */
        
        sprintf(setpoint_buf, "%02.1f", set_curr_max);                           // convert float to 4 byte ascii
        memcpy(&c1_array[CURR_MAX_OFFSET-0x0010],setpoint_buf, SETPOINT_LEN);
                                 
        // bytes 11-15 of 0-15  are spare
        
        // Now copy row 1 to EEPROM
        ee_row = 1;
        Copy_to_EE(ee_row,c1_array,NO);     /* copy 1 row at a time to EEPROM */
        
        // Now copy the cal table structure to EEPROM
        Arr_Size = (sizeof Band_Cal_Table);
        memcpy(eepromArray,Band_Cal_Table,Arr_Size);       /*  copy ARR_SIZE bytes back into the Band_Cal_Table structure (if it is not padded)  */                                 
      
        /*   start at 3rd row 1st byte (row 2) 0x0020)   */
        for(j=0; j<(Arr_Size); j++)  /* if we have t bands then we have 14 rows of EEPROM to read - or BANDS = 7 *32bytes, start at byte address  0x0010  */
        {              
            result = EEPROM_WriteByte(eepromArray[j], CAL_TBL_ARR_OFFSET+j);      /*  start at byte 16 and get ARR_SIZE bytes for whole structure */          
            if (result == CYRET_SUCCESS)
                printf("saved byte, result = %d", result);
            else
                printf("failed to save byte, result = %d", result);
        }            
       
        /*If all went OK set first byte to 'G' and return */
        if(EEPROM_ByteWritePos('G', 0, 0) == 0)
        {
            return 0;   // all good, exit
        }
        else
        {
        /*  return fail (1) and leave the S in place */
            return 1;  /* write to EEPROM completed OK but the writing the marker byte failed  */      
        }        
    }
    else
    {
        return 1;   /* failed to write the 'S' so abandon */
    }
}

/*******************************************************************************
* Function Name: Copy_to_EE
********************************************************************************
* Summary:
*   Takes data in an array of 16 bytes and writes it to the row requested by calling functions
*   EEPROM starts at 16 bit zero for these API functions.  We are reserving row 1 for flags to protect overwrite at startup.
    Writing in rows for now.  Callers have to gather up their data into a 16 byte array and pass that in along with the row.

* Parameters:
*   e_row  index to EEPROM row
*
* Return:
*   0 for success, 1 for FAIL
*
*******************************************************************************/
uint8_t Copy_to_EE(uint8 e_row, uint8_t c_array[16], uint8 print)
{
    uint16      j;
    uint8_t     eepromArray[16];   /* copy of data from eeprom to compare with source for validation.  */
    
    /*  Use e_row to specify the data row */
    
    /*  print the result for validation */
    if(print)
    {
        //LCD_Display_Clear();
        
        //sniprintf(LCD_Display_Row1, 17, "%s     ","DataWrite Row:  ");
        //LCD_Display_Update(TOP);
        //LCD_Position(TOP,15u);
        //LCD_PutChar(e_row+64);
        //  
        //sniprintf(LCD_Display_Row2, 17, "%s     ", c_array);
       // LCD_Display_Update(BOTTOM);       
        CyDelay(300);
    }
    if(!EEPROM_Write(c_array,e_row))
    {                      
        if(print)
        {        
            //LCD_Position(BOTTOM,14u);
            //LCD_PrintString("OK");
            CyDelay(300u);  
        }
    }
    else
    {
        if(print)
        {
            /*   error visits here.  */
            //LCD_Position(BOTTOM,9u);
            //LCD_PrintString(" FAIL! ");
            CyDelay(2000u);  
        }
        return 1;
    };            

    /*  Clear bottom status line for next event */
    if(print)
    {
        //LCD_Display_Clear();
        CyDelay(100);    

        /*sniprintf(LCD_Display_Row1, 17, "%s     ","DataWrite Row:  ");
        LCD_Display_Update(TOP);
        LCD_Position(TOP,15u);
        LCD_PutChar(e_row+64);
        LCD_Position(TOP,15u);
        LCD_PutChar(e_row+64); */
    }
    /*  now read it back from EEPROM  and compare to the data written */
    for(j=0; j<16; j++)
    {              
        eepromArray[j] = EEPROM_ReadByte(j+(e_row*16));               
    }
    if(memcmp(eepromArray,c_array,16))
    {
        if(print)
        {
            //LCD_Position(BOTTOM,9u);
            //LCD_PrintString(" FAIL! ");
            CyDelay(2000u);    
        }
        return 1;  
    }
    else    /* verified!  */
    {
        if(print)
        {            
            /* sniprintf(LCD_Display_Row2, 17, "%-9.9s     ", eepromArray);
            LCD_Display_Update(BOTTOM);
            CyDelay(400);
            LCD_Position(BOTTOM,14u);
            LCD_PrintString("OK");  */
            CyDelay(300u);            
        }
    }
        if(print)
        {
            //LCD_Display_Clear();
            CyDelay(800);
        }
    /*  Now read from EEPROM using CYDEV_EE_BASE for absolute address to start of EEPROM
    CYDEV_EEPROM_ROW_SIZE for row size
    CY_DEV_EE_SIZE for size of EEPROM memory space
    
    Look into how EEPROM is mirror for regular read only access and how to map the structure over it.
    Else read it byte at a time or copy the whole thing to a temp structure and proceed normally.  Writes still have to be some byte by byte.
    
    */
    return 0;
}

/*******************************************************************************
* Function Name: EEPROM_Init_Read
********************************************************************************
* Summary:
*   Transfers the master copy of config settings in EEPROM and copies it intop Band_Cal_Table array structure.
*   EEPROM starts at 16 bit zero for these API functions.  We are reserving row1 for flags to protect overwrite at startup.
*
* Parameters:
*   e_row  index to EEPROM row
*
* Return:
*   0 for success, 1 for FAIL
*
*******************************************************************************/
uint8_t EEPROM_Init_Read(void)
{
    uint16      j;  
    uint8_t     eepromArray[sizeof Band_Cal_Table];
    uint16      Arr_Size;
    char        setpoint_buf[SETPOINT_LEN+1];
    
    EE_PGM_Status = EEPROM_ReadByte(EE_STATE_BASE_ADDR);    
    if(EE_PGM_Status != 'G')   /*   EEPROM_Init will set byte 0, 'S' or on success 'G' */
        return 1;
    else
    {
        /* start reading all of our data to EEPROM now.  
            Everything is 1 byte in size so can serially copy each into EEPROM with no size or type conversion required
        */ 
        /* Get 2 rows of 16 bytes as we did to write this originally */
        for(j=0; j<32; j++)
        {              
            eepromArray[j] = EEPROM_ReadByte(j+EE_STATE_BASE_ADDR);             //  address relative to 0x0000
        }  
        // Now extract into each variable
                                                                                // byte 1 of 0-15 is reserved guard space
        op_mode = eepromArray[OP_MODE_OFFSET];                                  // byte 2 of 0-15
        CouplerSetNum = eepromArray[COUPLERSETNUM_OFFSET];                      // byte 3
        ser_data_out = eepromArray[SER_DATA_OUT_OFFSET];                        // byte 4
        memcpy(setpoint_buf,&eepromArray[HV_MAX_OFFSET],SETPOINT_LEN);          // byte 5-8  
        setpoint_buf[SETPOINT_LEN] = '\0';                                      // null terminate string
        set_hv_max = atof(setpoint_buf);                                        // convert ascii to float
        memcpy(setpoint_buf,&eepromArray[V14_MAX_OFFSET],SETPOINT_LEN);         // byte 9-12       
        setpoint_buf[SETPOINT_LEN] = '\0';
        set_v14_max = atof(setpoint_buf);                                       // convert ascii to float              
        set_temp_max = eepromArray[TEMP_MAX_OFFSET];                            // byte 13 of 0-15
        METERID = eepromArray[METERID_OFFSET];                                  // byte 14 of 15
        //xxx = eepromArray[SPARE0_OFFSET];                                     // byte 15 of 15  

        // start row 1
        memcpy(Callsign,&eepromArray[CALLSIGN_OFFSET],CALLSIGN_LEN);            // byte 0-6 -  first 7 bytes of row 1
        memcpy(setpoint_buf,&eepromArray[CURR_MAX_OFFSET],SETPOINT_LEN);        // byte 7-10 of 0-15
        setpoint_buf[SETPOINT_LEN] = '\0';                                      // null terminaite string
        set_curr_max = atof(setpoint_buf);                                      // convert ascii to float 
        //xxx = eepromArray[SPARE1_OFFSET];                                     // byte 11 of 0-15  
        //xxx = eepromArray[SPARE2_OFFSET];                                     // byte 12 of 0-15  
        //xxx = eepromArray[SPARE3_OFFSET];                                     // byte 13 of 0-15                  
        //xxx = eepromArray[SPARE4_OFFSET];                                     // byte 14 of 0-15                  
        //xxx = eepromArray[SPARE5_OFFSET];                                     // byte 15 of 0-15                                 
        /*  Using Arr_Size since it (likely) accurately returns the byte size of the CfgTblArr structure */          
        Arr_Size = (sizeof Band_Cal_Table);
        /*   start at 3rd row 1st byte (row 2) 0x0020)   */
        for(j=0; j<(Arr_Size); j++)  /* if we have t bands then we have 14 rows of EEPROM to read - or BANDS = 7 *32bytes, start at byte address  0x0010  */
        {              
            eepromArray[j] = EEPROM_ReadByte(CAL_TBL_ARR_OFFSET+j);      /*  start at byte 16 and get ARR_SIZE bytes for whole structure */          
        } 
        memcpy(Band_Cal_Table,eepromArray,Arr_Size);       /*  copy ARR_SIZE bytes back into the Band_Cal_Table structure (if it is not padded)  */                                 
        return 1;
    }
    return 0;   /*  Now have restored user state fully.  Be sure to write updates as they happen */
}

/*******************************************************************************
* Function Name: EE_Save_State
********************************************************************************
* Summary:
*   Saves the state variables required to restore last known state after a power off.
*   Saving all state in one function call since there are only a few and time is not critical for us 
*
* Parameters:
*   None
*
* Return:
*   0 = Success
*   1 = FAIL
*
*******************************************************************************/    
uint8_t EE_Save_State(void) 
{    
    /* Save State to EEPROM   */
    /* Use these to save the state of these state variables when ever you change them */ 
    
    /* These are stored in the first and 2nd rows.  Skipping the first byte though */
    EEPROM_WriteByte(op_mode, EE_STATE_BASE_ADDR+OP_MODE_OFFSET);                
    EEPROM_WriteByte(CouplerSetNum, EE_STATE_BASE_ADDR+COUPLERSETNUM_OFFSET); 
    EEPROM_WriteByte(ser_data_out, EE_STATE_BASE_ADDR+SER_DATA_OUT_OFFSET); 
    
    /* 2nd row variables */
    //for(i=0;i<CALLSIGN_LEN;++i)  /*  offset 16 bytes */
    // {   EEPROM_WriteByte(Callsign[i],EE_STATE_BASE_ADDR+CALLSIGN_OFFSET+i);   /* first 7 bytes of row */
    //}    
    //for(i=0;i<GRIDSQUARE_LEN;++i)  /*  next 9 bytes to finish the 16 byte row */
    //{
    //    EEPROM_WriteByte(Grid_Square[i],EE_STATE_BASE_ADDR+GRIDSQUARE_OFFSET+i); /*  last 9 bytes of block */ 
    //}      
    //EEPROM_Init_Write();    // save to eeprom
    //EEPROM_Init_Read();     // load the values into memory
    Cal_Table();
    
    return 0;
}

/*******************************************************************************
* Define Interrupt service routine and allocate an vector to the Interrupt
********************************************************************************/
CY_ISR(Timer_X00ms_InterruptHandler)
{
	/* Read Status register in order to clear the sticky Terminal Count (TC) bit 
	 * in the status register. Note that the function is not called, but rather 
	 * the status is read directly.
	 */
   	Timer_X00ms_STATUS;
    
	/* Increment the Counter to indicate the keep track of the number of 
     * interrupts received */
    Timer_X00ms_InterruptCnt++;    
    if(Timer_X00ms_InterruptCnt > 65000) 
        Timer_X00ms_InterruptCnt = 0;  /* roll it over */
}

/* [] END OF FILE */
