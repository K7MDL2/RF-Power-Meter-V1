/* ========================================
 *  OTRSP parsing
 *  Parses serial port commands from N1MM Logging program to control antennas and transverter via BCD or parallel GPIO port pins.
 *  Uses UART2 via calls to Serial2.c
 *  Only using the Aux commands not the whole SO2R list of commands so ot hte whole So@R list of p[ossible commands and queries
 *  Created by K7MDL July 27, 2020 for RF Wattmeter
 * ========================================
*/

//------------------------------------------------------------------
#include <project.h>
#include "Utilities.h"
#include "Serial.h"
#include "OTRSP.h"
//#include <stdio.h>
#include <stdlib.h>

//-------------------------------------------------------------------

#define FALSE 0
#define TRUE 1
#define AUXCMDLEN 4

// Function declarations
void Clear_buf(void);
void OTRSP_setup(void);
uint8_t OTRSP(void);
uint8_t Translate_Band(uint8_t);

// Vars
char AuxCmd0[64];
char AuxCmd1[AUXCMDLEN], AuxCmd2[AUXCMDLEN];
uint8_t AuxNum1, AuxNum2;


/*
Convert AUX command from N1MM to 4 bit BCD
Command format is AUXxnn fixed width. x is the radio number, usually 1.   Example is AUX103 for command 03 for BCD output of 0x03.
*/
uint8_t OTRSP()
{     
    char c;
    int i;
    
    AuxNum1 = AuxNum2 = 0;
    if (UART2_GetRxBufferSize() > 6)
    {
        c = UART2_GetChar();
        if (c == 'A')
        {            
            i = 0;
            AuxCmd0[i++] = c;
            while (UART2_GetRxBufferSize() != 0 && i < 7)
            {
                c = UART2_GetChar();
                AuxCmd0[i++] = c;                
            }
            if (AuxCmd0[6] == '\r')
            {  // Now our command string is built and qualified as a command
                if (strncmp(AuxCmd0,"AUX1",4) == 0)   // process AUX1 where 1 is the radio number.  Each radio has a 4 bit BCD value
                {
                    AuxCmd1[0] = AuxCmd0[4];
                    AuxCmd1[1] = AuxCmd0[5];
                    AuxCmd1[2] = '\0';
                    AuxNum1 = atoi(AuxCmd1);   // Convert 0-15 ASCII to int
                    Aux1_Write(AuxNum1);  // write out to the Control register which in turn writes to the GPIO ports assigned.                    	
                    AuxNum1 = Translate_Band(AuxNum1);
                    AuxCmd0[0] = '\0' ;
                    return(AuxNum1);  // AuxCmd2 now has a translated value - return for band change at meter
                }
                if (strncmp(AuxCmd0,"AUX2",4) == 0)   // process AUX comand for radio 2.
                {
                    AuxCmd2[0] = AuxCmd0[4];
                    AuxCmd2[1] = AuxCmd0[5];
                    AuxCmd2[2] = '\0';
                    AuxNum2 = atoi(AuxCmd2);   // Convert 0-15 ASCII to int
                    Aux2_Write(AuxNum2);  // write out to the Control register which in turn writes to the GPIO ports assigned.                    	
                    AuxNum2 = Translate_Band(AuxNum2);
                    AuxCmd0[0] = '\0' ;
                    return(AuxNum2);  // AuxCmd2 now has a translated value - return for band change at meter
                }
            }
        }
    }
    return 255;   // nothing processed 0 is a valid band number so using 255.
}

uint8_t Translate_Band(uint8_t band)
{
    uint8_t b;
    b = 0;
    band = band + b;   // change b to add or subtract if any correction required for BCD output to your device
    return band;
}

/* [] END OF FILE */
