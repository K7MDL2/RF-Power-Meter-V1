/* ========================================
 *  RF_Wattmeter.h
 * For the PSoC5LP version
 * K7MDL June 2020
 *
 * ========================================
*/

#include <project.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>


/******************************************************************************
  User edited values here for Callsign and Meter ID number and Some Setpoints
******************************************************************************/
#define CALLSIGN_LEN            (7u)
char8   Callsign[CALLSIGN_LEN] = "K7MDL\0";
const uint8_t default_METERID = 100; // Set the ID for this meter to permit monitoring more than 1 meter unit on a remote station
// range is 100 to 119 basd on UI input method design limits
// Can be overriden by external commands if stored in EEPROM
const float HV_MAX = 28.5;
const float V14_MAX = 14.6;
const float CURR_MAX = 15.0;
const uint8_t TEMP_MAX = 135;


//#define SSD1306_OLED
#define NEXTION
#define DETECTOR_TEMP_CONNECTED


/*******************************************
Non-user edit section
*********************************************/

#ifdef NEXTION
#include "..\..\Nextion-C-Library-master\nextion\Nextion.h"
#include "..\..\Nextion-C-Library-master\util\Utilities.h"
#endif

#ifdef SSD1306_OLED
#include "ssd1306.h"
#define DISPLAY_ADDRESS 0x3C //  for OLED i2C - 011110+SA0+RW - 0x3C or 0x3D NOTE1
// If you are using a 128x64 OLED screen, the address will be 0x3C or 0x3D, if one does not work try with the other one.
#endif

#ifdef DETECTOR_TEMP_CONNECTED
float32 TempVal = 0.0;    
#endif

#if defined (__GNUC__)
    /* Add an explicit reference to the floating point printf library */
    /* to allow usage of the floating point conversion specifiers. */
    /* This is not linked in by default with the newlib-nano library. */
    asm (".global _printf_float");
#endif

/* Interrupt prototypes */
CY_ISR_PROTO(RESelectIsrHandler);
CY_ISR_PROTO(NestedIsrHandler);
CY_ISR(Timer_X00ms_InterruptHandler);
/* CY_ISR_PROTO(Timer_X00ms_IsrHandler);*/
uint32  Timer_X00ms_InterruptCnt;
uint32  Timer_X00ms_Last;
uint32 Timer_X00ms_Last_AD;
uint32 Timer_X00ms_Last_USB;
uint32 Timer_X00ms_Last_Nex;
uint32 Timer_X00ms_Last_OLED;

// Rest of program...
#define MUX_FWD 0       // These are the Analog Mux input assignments
#define MUX_REF 1
#define MUX_TEMP 2      // temperature from detector for better calibration.  ADL5519 and some AD8318 modules.  This is nto the RF amp heat sink temp!
#define MUX_14V 3
#define MUX_CURR 4
#define MUX_HV 5

#define TEST_EEPROM 0  // change to 1 and reprogram, then set back to 0 to reset EEPROM data to default
#define SWR 2
#define PWR 1
#define MENU 3
#define NO 0
#define YES 1
//#define ADC_COUNTS 1024    // 4096 for ESP32 12bit, 1024 for 10 bit ESP32 and Nano.
//#define ad_Fwd "A1"    // Analog 35 pin for channel 0 - Arduino only
//#define ad_Ref "A2"   // Analog 36 pin for channel 1 - Arduino only
// Edit the Coupler Set data in the Cal_Table function.  Set the max number of sets here, and the default to load at startup
#define NUM_SETS 11 // 11 bands, 0 through 10 for example
#define SETPOINT_LEN            (0x0004)
#define TEMPERATURE_LEN         (0x0001)
#define METERID_LEN             (0x0001)
#define EE_STATE_BASE_ADDR      (0x0000)  // row 0
#define EE_RESERVED_BYTE1       (0x0001)
#define OP_MODE_OFFSET          (0x0002)
#define COUPLERSETNUM_OFFSET    (0x0003)
#define SER_DATA_OUT_OFFSET     (0x0004)  
#define HV_MAX_OFFSET           (0x0005)  // 5, 6, 7, 8 - 4 bytes each neded for ASCII version of floats  ex: 113 degrees or 78.2 dB or 28.6 VDC
#define V14_MAX_OFFSET          (0x0009)  // 9, A, B, C - 4 bytes each neded for ASCII version of floats  ex: 113 degrees or 78.2 dB or 28.6 VDC
#define TEMP_MAX_OFFSET         (0x000D)  // 1 byte - temp is 1 byte ex: 113
#define METERID_OFFSET          (0x000E)  // 1 byte 100-119 range
#define SPARE0_OFFSET           (0x000F)  // byte F spare
/* end row 0, start row 1  */
#define CALLSIGN_OFFSET         (0x0010)  // bytes 10 to 16 in row 1   7 bytes
#define CURR_MAX_OFFSET         (0x0017)  // 17, 18, 19, 1A - 4 bytes each neded for ASCII version of floats  ex: 113 degrees or 78.2 dB or 28.6 VDC
#define SPARE1_OFFSET           (0x001B)  // byte 1B spare
#define SPARE2_OFFSET           (0x001C)  // byte 1C spare
#define SPARE3_OFFSET           (0x001D)  // byte 1D spare
#define SPARE4_OFFSET           (0x001E)  // byte 1E spare
#define SPARE5_OFFSET           (0x001F)  // byte 1F spare

// end row 1 data 

// start row 2 data (whole table)
#define CAL_TBL_ARR_OFFSET      (0x0020)  /* start row 2 and beyond  */
#define EE_SAVE_YES             (65u)
#define TEST_LEN                (14u)
#define CFG_ARR_TEST_STRING     "01234567890123"
#define Serial_USB_DEVICE       (0u)
/* The buffer size is equal to the maximum packet size of the IN and OUT bulk
* endpoints.
*/
#define Serial_USB_BUFFER_SIZE  (64u)
#define LINE_STR_LENGTH         (20u)
#define BUF_LEN  Serial_USB_BUFFER_SIZE

/* Global Variables */
char8* parity[] = {"None", "Odd", "Even", "Mark", "Space"};
char8* stop[]   = {"1", "1.5", "2"};
float32 Vref = 5.0;        // 3.3VDC for Nano and ESP32 (M5stack uses ESP32)  ESP32 also has calibrated Vref curve
uint8_t METERID = 100;    // tracks current Meter ID number   Resets to default_METERID.
uint8_t CouplerSetNum = 0;   // 0 is the default set on power up.  
uint8_t ser_data_out = 0;
uint8_t Reset_Flag = 0;
uint32_t updateTime = 0;       // time for next update
float32 Fwd_dBm = 0;
float32 Ref_dBm = 0;
float32 FwdPwr = 0;
float32 RefPwr = 0;
float32 SWRVal = 0;
float32 SWR_Serial_Val = 0;
float32 FwdVal = 0;
float32 RefVal = 0;
uint8_t Edit_Atten = 0;
uint8_t op_mode = SWR;
uint8_t counter1 = 0;
uint8_t Button_A = 0;
uint8_t Button_B = 0;
uint8_t Button_C = 0;
uint8_t NewBand;
float32 CouplingFactor_Fwd = 0;
float32 CouplingFactor_Ref = 0;
float32 Offset_F = 0.6455;  // AD8318 is 0.5 offset for around +5dBm to +10dBm (nonlinear range) for 0.5V to about 2.2 volts for whole range.  We want to max at 0dBm
float32 Slope_F = 0.02521;  // AD8318 is about 25mV per dB with temp compensation
float32 Offset_R = 0.6455;  
float32 Slope_R = 0.02521;  
float32 FwdPwr_last = 0;
float32 Pwr_hi = 0, Pwr_lo = 0;
float32 FwdVal_hi = 0, FwdVal_lo = 0; // used for auto cal
float32 RefVal_hi = 0, RefVal_lo = 0; // used for auto cal
#define NUMREADINGS 1   // adjust this for longer or shorter smooting period as AD noise requires
float32 readings_Fwd[NUMREADINGS];      // the readings from the analog input
float32 readings_Ref[NUMREADINGS];      // the readings from the analog input
uint8_t readIndex_Fwd = 0;              // the index of the current reading
uint8_t readIndex_Ref = 0;              // the index of the current reading
float32 total_Fwd = 0;                  // the running total
float32 total_Ref = 0;                  // the running total
uint8_t EE_PGM_Status = 0u;
uint8_t EE_PGM_Failed;
uint8_t rx_buffer[Serial_USB_BUFFER_SIZE];
uint8_t tx_buffer[Serial_USB_BUFFER_SIZE];
uint16_t rx_count = 0;
uint16_t tx_count = 0;
float set_hv_max = 28.5;   // max values for VDC, Current and Temp if used in an amplifier wit hthese sensors
float set_v14_max = 14.8;
float set_curr_max = 10;
uint8_t set_temp_max = 132;
static char8 sdata[Serial_USB_BUFFER_SIZE], *pSdata = sdata, *pSdata1=sdata, *pSdata2=sdata;
extern char8 cmd[64];
float value1_last;

// Function declarations
void toggle_ser_data_output(void);
void setup(void);
void adRead(void);
void read_Cal_Table_from_EEPROM(void);
void sendSerialData(void);
void print_cal_table(void);
void print_Cal_Table_progress(uint8_t);
void print_Cmd_Progress(uint8_t);
void Cal_Table();
void Cal_Table_write(void);
void reset_EEPROM();
void write_Cal_Table_to_EEPROM(void);
void save_config_EEPROM(void);
void write_Cal_Table_from_Default(void);
void get_remote_cmd(void);
uint16_t serial_usb_read(void);
void serial_usb_write(void);

#ifdef NEXTION
void savecfg_button_push_Callback(void *);
void savecfg_button_pop_Callback(void *);
void fwd_cal_pop_Callback(void *);
void ref_cal_pop_Callback(void *);
void f_att_minus_pop_Callback(void *);
void f_att_plus_pop_Callback(void *);
void r_att_minus_pop_Callback(void *);
void r_att_plus_pop_Callback(void *);
void toMain_push_Callback(void *);
void toConfig_pop_Callback(void *);
void FactoryRst1_pop_Callback(void *);
void FactoryRst2_pop_Callback(void *);
void Set1_Callback(void *ptr);
void meterID_adj_pop_Callback(void *);
void band_set_adj_pop_Callback(void *);
void hv_adj_pop_Callback(void *ptr);
void v14_adj_pop_Callback(void *ptr);
void curr_adj_pop_Callback(void *ptr);
void temp_adj_pop_Callback(void *ptr);
uint8_t update_Nextion(void);
void UART1interrupt(void);   // get next char from IRQ buffer, if any
#endif

// Mostly EEPROM layout related vars
uint8_t EEPROM_Init(uint8); /* function to initially copy the config table array to EEPROM on first use.  Calls Read or Write */
uint8_t EEPROM_Init_Write(void); /* function to initially copy the config table array TO the EEPROM on first use */
uint8_t EEPROM_Init_Read(void); /* function to initially copy the config table array FROM the EEPROM on first use */
uint8_t Copy_to_EE(uint8 e_row, uint8_t c_array[16],uint8 print);  /*  called by EEPROM_Init_Write */
uint8_t EE_Save_State(void);

struct Band_Cal {
    char8  BandName[12];
    float32 Cpl_Fwd;
    float32 Slope_F;
    float32 Offset_F;
    float32 Cpl_Ref;
    float32 Slope_R;
    float32 Offset_R;
} Band_Cal_Table_Def[NUM_SETS] = {
     {"HF", 72.0, -0.02145, 0.48840, 73.6, -0.02145, 0.48840},
     {"50MHz", 72.6, -0.02145, 0.48840, 74.2, -0.02145, 0.48840},
     {"144MHz", 63.4, -0.02194, 0.48374, 65.0, -0.02194, 0.48374},
     {"222MHz", 60.5, -0.02125, 0.48885, 62.1, -0.02125, 0.48885},
     {"432MHz", 59.6, -0.02167, 0.45472, 61.2, -0.02167, 0.45472},
     {"902MHz", 59.2, -0.02085, 0.45098, 60.8, -0.02085, 0.45098},
     {"1296MHz",72.6, -0.02081, 0.44948, 74.2, -0.02081, 0.44948},
     {"2.3GHz", 60.1, -0.02514, 0.644, 60.1, -0.02514, 0.644},
     {"3.4GHz", 60.2, -0.02514, 0.644, 60.2, -0.02514, 0.644},
     {"5.7GHz", 60.3, -0.02514, 0.644, 60.3, -0.02514, 0.644},
     {"10GHz", 60.4, -0.02514, 0.644, 60.4, -0.02514, 0.644}
    };
struct Band_Cal Band_Cal_Table[NUM_SETS];

#ifdef SSD1306_OLED
    void OLED(void);
#endif 

// For Nextion Display usage on UART_1
#ifdef NEXTION
    uint32_t rcv_num;
    uint8_t pg = 0;  // flag to track page changes to minimize writes to the sliders and other fields

    struct NexObject savecfg_button, fwd_cal, ref_cal, fwd_cal_num,\
                        ref_cal_num, f_att_minus, f_att_plus, r_att_minus, r_att_plus, \
                        toMain, toConfig, toSet1, Main, Coupler, Set1, FactoryRst1, FactoryRst2, \
                        hv_adj, v14_adj, curr_adj, temp_adj, meterID_adj, meterID, \
                        band_set_adj, band_set, Set1_Bandvar, band_cal, Graph_Timer, \
                        hv_max, v14_max, curr_max, temp_max, band_set, FdBm, RdBm, \
                        toPwrGraph, PwrGraph, fPwrGraph, swrGraph, fPwr_scale, fscale, rscale, fPwrNum, rPwrNum, swrNum;
    struct NexObject *nex_listen_list[] = {
        &savecfg_button, &fwd_cal, &ref_cal, &f_att_minus, &f_att_plus, &r_att_minus, \
        &r_att_plus, &toMain, &toConfig, &toSet1, &toPwrGraph, &FactoryRst1, &FactoryRst2, &Main, &Coupler, &Set1, \
        &hv_adj, &v14_adj, &curr_adj, &temp_adj, &band_set_adj, &meterID_adj, &Set1_Bandvar, NULL};

    uint32_t value;

    // Nextion Page ID, not the object ID
    #define page0_ID 0  // Main
    #define page1_ID 1  // Coupler
    #define page2_ID 2  // Set1  -= coudl be more added later so Set2, Set3, so on.
    #define page3_ID 3  // Power graphing page

    // Nextion Main object ID
    #define Main_ID 0
    #define fwdpwr_ID 8
    #define refpwr_ID 9
    #define swr_ID 10
    #define hv_ID 11
    #define v14_ID 12
    #define temp_ID 13
    #define curr_ID 14
    #define band_ID 15
    #define toConfig_ID 16
    #define FdBm_ID 17
    #define RdBm_ID 18

    // Page 1 Coupler object IDs
    #define Coupler_ID 0
    #define savecfg_button_ID 1
    #define fwd_cal_ID 2
    #define ref_cal_ID 3
    #define fwd_cal_num_ID 12
    #define ref_cal_num_ID 13
    #define f_att_minus_ID 7
    #define f_att_plus_ID 8
    #define r_att_minus_ID 10
    #define r_att_plus_ID 9
    #define FactoryRst1_ID 15
    #define FactoryRst2_ID 14
    #define band_cal_ID 16
    #define toSet1_ID 6

    // Page 2 Setpoints object IDs
    #define Set1_ID 0 
    #define hv_adj_ID 12
    #define hv_max_ID 2
    #define v14_adj_ID 15
    #define v14_max_ID 1
    #define curr_adj_ID 16
    #define curr_max_ID 3
    #define temp_adj_ID 17
    #define temp_max_ID 4
    #define meterID_adj_ID 19
    #define meterID_ID 5
    #define band_set_adj_ID 21
    #define band_set_ID 6
    #define toPwrGraph_ID 18
    // global set up in Set1 page
    #define Set1_Bandvar_ID 23    // Set1.Bandvar.txt
    
    // Page 3 PwrGraph object IDs
    #define PwrGraph_ID 0
    #define fPwrGraph_ID 1
    #define swrGraph_ID 15
    #define fPwr_scale_ID 6
    #define fPwrNum_ID 9
    #define rPwrNum_ID 10
    #define swrNum_ID 17  
    #define fscale_ID 7
    #define rscale_ID 8
    #define Graph_Timer_ID 19
    #define toMain_ID 5

#endif   // end this section of NEXTION related var and defines


/* [] END OF FILE */
