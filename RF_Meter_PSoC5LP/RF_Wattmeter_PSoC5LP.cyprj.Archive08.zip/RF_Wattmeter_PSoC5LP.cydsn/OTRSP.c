/* ========================================
 *  OTRSP parsing
 *  Parses serial port commands from N1MM Logging program to control antennas and transverter
 *  via BCD or parallel GPIO port pins.
 *  Uses UART2 which shares the USB UART with the Nextion display if there is one. Desktop app
 *  config page switches between USB com port between the display and UART2 (for N1MM commands)
 *  Only using the Aux commands not the whole SO2R list of commands so not using the whole SO2R
 *  list of possible commands and queries
 *  Created by K7MDL July 27, 2020 for RF Wattmeter to enable antenna switching , transveter
 *  selection, PTT, CW, and band labeling on the LCD, especially for radios with native tranverter support. 
 * ========================================
*/

//------------------------------------------------------------------
#include <project.h>
#include "Utilities.h"
#include "Serial.h"
#include "OTRSP.h"
#include <stdio.h>
#include <stdlib.h>
//#include <string.h>

//-------------------------------------------------------------------

#define FALSE 0
#define TRUE 1
#define AUXCMDLEN 4
#define BANDCMDLEN 12

// Function declarations
void OTRSP_setup(void);
uint8_t OTRSP(void);

// Vars
extern uint8_t AuxNum1, AuxNum2;


/*
Convert AUX command from N1MM to 4 bit BCD
Command format is AUXxnn fixed width. x is the radio number, usually 1.   Example is AUX103 for command 03 for BCD output of 0x03.
*/
uint8_t OTRSP()
{     
    char c;
    int i;
    char AuxCmd0[20];
    char AuxCmd1[AUXCMDLEN], AuxCmd2[AUXCMDLEN];
    char BndCmd1[BANDCMDLEN], BndCmd2[BANDCMDLEN];
    
    //AuxNum1 = AuxNum2 = 0;  // Global values also used to update status on LCD
    if (UART2_GetRxBufferSize() > 6)
    {
        c = UART2_GetChar();
        if (c == 'A' || c == 'B')   // AUXxYYy\r or BANDxYYYYY...\r
        {            
            i = 0;
            AuxCmd0[i++] = c;
            while (UART2_GetRxBufferSize() != 0 && i <= 16 && c != '\r')   // Gather chars up to \r
            {
                c = UART2_GetChar();
                AuxCmd0[i++] = c;                
            }
            if (c == '\r') // Now our command string is built and qualified as a command
            {  
                AuxCmd0[i-1]='\0';  // Terminate the string (no \r)
                // Looking only for 2 commands, BAND and AUX.   
                if (strncmp(AuxCmd0,"AUX1",4) == 0)   // process AUX1 where 1 is the radio number.  Each radio has a 4 bit BCD value
                {
                    AuxCmd1[0] = AuxCmd0[4];
                    AuxCmd1[1] = AuxCmd0[5];
                    AuxCmd1[2] = AuxCmd0[6];
                    AuxCmd1[3] = '\0';                    
                    AuxNum1 = atoi(AuxCmd1);   // Convert text 0-255 ASCII to int
                    Aux1_Write(AuxNum1);  // write out to the Control register which in turn writes to the GPIO ports assigned.                    	
                    for (i=0; i < 20; i++)
                    {
                        AuxCmd0[i] = '\0';
                        CyDelay(1);
                    }
                    return(1);  // 1 signals a change
                }
                else if (strncmp(AuxCmd0,"AUX2",4) == 0)   // process AUX comand for radio 2.
                {
                    AuxCmd2[0] = AuxCmd0[4];
                    AuxCmd2[1] = AuxCmd0[5];
                    AuxCmd1[2] = AuxCmd0[6];
                    AuxCmd2[3] = '\0';
                    AuxNum2 = atoi(AuxCmd2);   // Convert 0-15 ASCII to int
                    Aux2_Write(AuxNum2);  // write out to the Control register which in turn writes to the GPIO ports assigned.                    	                   
                    for (i=0; i< 20; i++)
                        AuxCmd0[i] = '\0' ;
                    return(1);  // AuxCmd2 now has a translated value - return for band change at meter
                } // Look for BAND commands ofmr N1MM - so far have not seen any - these are jsut for catching them, they cause not changes
                else if (strncmp(AuxCmd0,"BAND1",5) == 0)   // process AUX1 where 1 is the radio number.  Each radio has a 4 bit BCD value
                {
                    // This will be the bottom frequency (in MHz) of the current radio band.  ie 3.5MHz for 3875KHz
                    sprintf(BndCmd1,"%s", &AuxCmd0[5]);
                    AuxCmd0[0]='\0';
                    return(0);  // TODO = assing band MHZ to a CouplerNUM  Search Band values
                }
                else if (strncmp(AuxCmd0,"BAND2",5) == 0)   // process AUX comand for radio 2.
                {
                    sprintf(BndCmd2,"%s", &AuxCmd0[5]);
                    AuxCmd0[0] = '\0' ;
                    return(0); 
                }
            }
        }
    }
    return 0;   // nothing processed 0 is a valid band number so using 255.
}

/* [] END OF FILE */
