/*******************************************************************************
* File Name: SWR_Fail_Analog_Output_PM.c  
* Version 1.90
*
* Description:
*  This file provides the power management source code to API for the
*  VDAC8.  
*
* Note:
*  None
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "SWR_Fail_Analog_Output.h"

static SWR_Fail_Analog_Output_backupStruct SWR_Fail_Analog_Output_backup;


/*******************************************************************************
* Function Name: SWR_Fail_Analog_Output_SaveConfig
********************************************************************************
* Summary:
*  Save the current user configuration
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
*******************************************************************************/
void SWR_Fail_Analog_Output_SaveConfig(void) 
{
    if (!((SWR_Fail_Analog_Output_CR1 & SWR_Fail_Analog_Output_SRC_MASK) == SWR_Fail_Analog_Output_SRC_UDB))
    {
        SWR_Fail_Analog_Output_backup.data_value = SWR_Fail_Analog_Output_Data;
    }
}


/*******************************************************************************
* Function Name: SWR_Fail_Analog_Output_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:  
*  void
*
* Return: 
*  void
*
*******************************************************************************/
void SWR_Fail_Analog_Output_RestoreConfig(void) 
{
    if (!((SWR_Fail_Analog_Output_CR1 & SWR_Fail_Analog_Output_SRC_MASK) == SWR_Fail_Analog_Output_SRC_UDB))
    {
        if((SWR_Fail_Analog_Output_Strobe & SWR_Fail_Analog_Output_STRB_MASK) == SWR_Fail_Analog_Output_STRB_EN)
        {
            SWR_Fail_Analog_Output_Strobe &= (uint8)(~SWR_Fail_Analog_Output_STRB_MASK);
            SWR_Fail_Analog_Output_Data = SWR_Fail_Analog_Output_backup.data_value;
            SWR_Fail_Analog_Output_Strobe |= SWR_Fail_Analog_Output_STRB_EN;
        }
        else
        {
            SWR_Fail_Analog_Output_Data = SWR_Fail_Analog_Output_backup.data_value;
        }
    }
}


/*******************************************************************************
* Function Name: SWR_Fail_Analog_Output_Sleep
********************************************************************************
* Summary:
*  Stop and Save the user configuration
*
* Parameters:  
*  void:  
*
* Return: 
*  void
*
* Global variables:
*  SWR_Fail_Analog_Output_backup.enableState:  Is modified depending on the enable 
*  state  of the block before entering sleep mode.
*
*******************************************************************************/
void SWR_Fail_Analog_Output_Sleep(void) 
{
    /* Save VDAC8's enable state */    
    if(SWR_Fail_Analog_Output_ACT_PWR_EN == (SWR_Fail_Analog_Output_PWRMGR & SWR_Fail_Analog_Output_ACT_PWR_EN))
    {
        /* VDAC8 is enabled */
        SWR_Fail_Analog_Output_backup.enableState = 1u;
    }
    else
    {
        /* VDAC8 is disabled */
        SWR_Fail_Analog_Output_backup.enableState = 0u;
    }
    
    SWR_Fail_Analog_Output_Stop();
    SWR_Fail_Analog_Output_SaveConfig();
}


/*******************************************************************************
* Function Name: SWR_Fail_Analog_Output_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  SWR_Fail_Analog_Output_backup.enableState:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void SWR_Fail_Analog_Output_Wakeup(void) 
{
    SWR_Fail_Analog_Output_RestoreConfig();
    
    if(SWR_Fail_Analog_Output_backup.enableState == 1u)
    {
        /* Enable VDAC8's operation */
        SWR_Fail_Analog_Output_Enable();

        /* Restore the data register */
        SWR_Fail_Analog_Output_SetValue(SWR_Fail_Analog_Output_Data);
    } /* Do nothing if VDAC8 was disabled before */    
}


/* [] END OF FILE */
